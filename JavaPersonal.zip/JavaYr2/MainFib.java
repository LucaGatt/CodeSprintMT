class MainFib{
    static void main(){
        FibonacciSequence fib = new FibonacciSequence();
        int x=0;
        x= fib.acreateSequence(1);
        System.out.print(x+"\n");
        
        for (int i=0; i<6; i++){
            System.out.print(fib.createSequence(i));
        }
        System.out.println("\n"+fib.createSequence(1));
    }
}