package Exam;

class Price{
    static void main(){
        float price= 10;
        System.out.println("Wrong: " + 118/100*price);
        System.out.println("Wrong: " +price*118/100*price);
        System.out.println("same as: " +price*118/price);
        System.out.println("Correct: " +price*118/100);
    }
}