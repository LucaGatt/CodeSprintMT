package Exam;
import java.util.Scanner;

class Main{
    static void main(){
        Van van = new Van();
        Scanner sc = new Scanner(System.in);
        float price = sc.nextFloat();
        van.setPrice(price);
        System.out.println(van.getPrice());
    }
}