package my;
class InttoStr{
    public static void intToStr(){
        int a= IO.nextInt();
        
        /*int length = (int) (Math.log10(a) + 1);//since log 1 = 0 and digit must be 1
         * or
         * int length = String.valueOf(number).length();
         */
        
        String aStr = String.valueOf(a);
        //String[] b = aStr.split("");
    }
    public static void strToInt(){
        String a= IO.next();
        
        int b = Integer.parseInt(a);
    }
}