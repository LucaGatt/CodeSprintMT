package ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Vehicle_Main{
    public static Scanner in = new Scanner(System.in);
    public static void main(String args[]){
        do{
            byte option; 
            while(true){
                try{
                    option= menu();
                    if (option<1 || option>10) new InputMismatchException();
                    break;
                }catch (InputMismatchException e){}
            }
            
            switch(option){
                case 1 : option1(); break;
                case 2 : option2(); break;
                case 3 : option3(); break;
                case 4 : option4(); break;
                case 5 : option5(); break;
                case 6 : option6(); break;
                case 7 : option7(); break;
                case 8 : option8(); break;
                case 9 : option9(); break;
                case 10: option10();break;
            }
        }while(true);
    }
    private static byte menu(){
        System.out.println("\fWelcome to Motorcity Garage - Main menu");
            System.out.println("\t1. Add vehicle");
            System.out.println("\t2. List all vehicles in the garage");
            System.out.println("\t3. Search for vehicle (by make)");
            System.out.println("\t4. Edit vehicle details");
            System.out.println("\t5. Delete a vehicle from the garage");
            System.out.println("\t6. Sort vehicles by Engine CC");
            System.out.println("\t7. Sort vehicles by Make");
            System.out.println("\t8. Load data from file");
            System.out.println("\t9. Save data to file");
            System.out.println("\t10.Exit");
            return in.nextByte();
    }
    private static Garage g= new Garage();
    private static void option1(){
        g.addVehicle();
    }
    private static void option2(){ //output
        g.listAllVehicles();
        System.out.print("Enter any character to continue."); in.next();
    }
    private static void option3(){ //search
        g.search();
    }
    private static void option4(){
        g.editVehicle();
    }
    private static void option5(){
        g.deleteVehicle();
    }
    private static void option6(){
        g.sortEngineCC();
    }
    private static void option7(){
        g.sortMake();
    }
    private static void option8(){
        
    }
    private static void option9(){
        
    }
    private static void option10(){
        System.exit(0);
    }
}