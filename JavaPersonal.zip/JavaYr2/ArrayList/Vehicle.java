package ArrayList;

class Vehicle{
    private int chassisNo;
    private String make;
    private String model;
    private String engineCC;
    private byte noOfDoors;
    
    public Vehicle(){
        chassisNo = 0;
        make = null;
        model = null;
        engineCC = null;
        noOfDoors = 0;
    }
    
    public void setMake(String make){
        this.make = make;
    }
    public void setModel(String model){
        this.model = model;
    }
    public void setEngineCC(String engineCC){
        this.engineCC = engineCC;
    }
    public void setNoOfDoors(byte noOfDoors){
        this.noOfDoors = noOfDoors;
    }
    
    public String getMake(){
        return make;
    }
    public String getModel(){
        return model;
    }
    public String getEngineCC(){
        return engineCC;
    }
    public byte getNoOfDoors(){
        return noOfDoors;
    }
    
    public String listVehicle(){
        return "\tMake: "+make+"\tModel: "+model+"\tEngine CC: "+engineCC+"\tNumber of doors: "+String.valueOf(noOfDoors)+"\n";
    }

//Start GetterSetterExtension Source Code

    /**GET Method Propertie chassisNo*/
    public int getChassisNo(){
        return this.chassisNo;
    }//end method getChassisNo

    /**SET Method Propertie chassisNo*/
    public void setChassisNo(int chassisNo){
        this.chassisNo = chassisNo;
    }//end method setChassisNo

//End GetterSetterExtension Source Code


}//End class