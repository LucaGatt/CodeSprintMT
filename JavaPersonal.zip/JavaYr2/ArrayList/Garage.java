package ArrayList;
import java.util.ArrayList;
import java.util.Scanner;

public class Garage{
    ArrayList<Vehicle> vehicles;
    public static Scanner in = new Scanner (System.in);
    public Garage(){
        vehicles = new ArrayList();
    }
    
    public void addVehicle(){
        System.out.print("Enter make: ");
        String make = in.next();
        System.out.print("Enter model: ");
        String model = in.next();
        System.out.print("Enter engineCC: ");
        String engineCC = in.next();
        System.out.print("Enter number of doors: ");
        byte noOfDoors = in.nextByte();
        
        Vehicle vehicle = new Vehicle();
        vehicle.setMake(make);
        vehicle.setModel(model);
        vehicle.setEngineCC(engineCC);
        vehicle.setNoOfDoors(noOfDoors);
        vehicles.add(vehicle);
    }
    
    public void listAllVehicles(){
        String list="";
        for (byte i=0; i<vehicles.size(); i++){
            //Vehicle vehicleTmp= vehicles.get(i);
            //list+="Engine CC: "+vehicleTmp.getEngineCC()+"\t Model: "+vehicleTmp.getModel()+"\n";
            list+=vehicles.get(i).listVehicle();
        }
        System.out.println(list);
    }
    
    public void search(){ // search by make
        System.out.print("Enter make to search for: ");
        String makeInput= in.next();
        boolean vehicleFound=false;
        for (byte i=0; i<vehicles.size(); i++){
            Vehicle vehicleTmp = vehicles.get(i);
            if(vehicleTmp.getMake().equalsIgnoreCase(makeInput)){
                System.out.println(vehicleTmp.listVehicle());
                vehicleFound=true;
            }
        }
        if(!vehicleFound) System.out.print("Vehicle not found");
        pause();
    }
    
    public void editVehicle(){
        listAllVehicles();
        System.out.print("\nWhich vehicle do you want to edit?");
        int chassisEdit = in.nextInt();
        System.out.print("Which field do you want to edit?");
        String fieldToEdit = in.next();
        
        System.out.print("Enter new value to edit: ");
        for (int i=0; i<vehicles.size();i++){
            if (vehicles.get(i).getChassisNo() == chassisEdit){
                Vehicle vehicleTmp= vehicles.get(i);
                if (fieldToEdit.equals("chassis no")) vehicleTmp.setChassisNo(in.nextInt());
                if (fieldToEdit.equals("make")) vehicleTmp.setMake(in.next());
                if (fieldToEdit.equals("model")) vehicleTmp.setModel(in.next());
                if (fieldToEdit.equals("engineCC")) vehicleTmp.setEngineCC(in.next());
                if (fieldToEdit.equals("number of doors")) vehicleTmp.setNoOfDoors(in.nextByte());
                
            }
        }
    }
    
    public void deleteVehicle(){ // by make
        listAllVehicles();
        System.out.print("\nWhich vehicle do you want to delete?");
        String makeDelete = in.next();
        for (short i=0; i<vehicles.size(); i++){
            if(vehicles.get(i).getMake().equalsIgnoreCase(makeDelete))
                vehicles.remove(i);
        }
    }
    
    private void sortAsc(String field){ //bubble sort
        boolean swapped;
        do{
            swapped = false;
            for (byte i=0; i<vehicles.size()-1; i++){
                Vehicle tmpVehicle0 = vehicles.get(i);
                Vehicle tmpVehicle1 = vehicles.get(i+1);
                if(field.equals("engineCC")){
                    String tmp0= tmpVehicle0.getEngineCC();
                    String tmp1= tmpVehicle1.getEngineCC();
                    if (tmp0.toCharArray()[0]>tmp1.toCharArray()[0]){ // swap
                        swap(tmpVehicle0,tmpVehicle1);
                    }
                }else if (field.equals("make")){
                    char[] tmp0= tmpVehicle0.getMake().toCharArray();// on left
                    char[] tmp1= tmpVehicle1.getMake().toCharArray();// on right
                    
                    boolean proceed = true;
                    byte j;
                    for (j=0; j<tmp0.length && j<tmp1.length && !swapped; j++){
                        if (tmp0[0]>tmp1[0]){ // swap
                            swap(tmpVehicle0,tmpVehicle1);
                            swapped = true;
                        }
                    }
                    if (j==tmp1.length){// meaning tmp1 is smaller 
                        swap(tmpVehicle0,tmpVehicle1);
                            swapped = true;
                    }
                }
            }
        }while(swapped);
    }
    private void swap(Vehicle tmpVehicle0,Vehicle tmpVehicle1){
        Object tmp = tmpVehicle0.getChassisNo();
        tmpVehicle0.setChassisNo(tmpVehicle1.getChassisNo());
        tmpVehicle1.setChassisNo((int)tmp);
        
        tmp = tmpVehicle0.getMake();
        tmpVehicle0.setMake(tmpVehicle1.getMake());
        tmpVehicle1.setMake((String)tmp);
        
        tmp = tmpVehicle0.getModel();
        tmpVehicle0.setModel(tmpVehicle1.getModel());
        tmpVehicle1.setModel((String)tmp);
        
        tmp = tmpVehicle0.getEngineCC();
        tmpVehicle0.setEngineCC(tmpVehicle1.getEngineCC());
        tmpVehicle1.setEngineCC((String)tmp);
        
        tmp = tmpVehicle0.getNoOfDoors();
        tmpVehicle0.setNoOfDoors(tmpVehicle1.getNoOfDoors());
        tmpVehicle1.setNoOfDoors((byte)tmp);
    }
    public void sortEngineCC(){
        sortAsc("engineCC");
    }
    public void sortMake(){
        sortAsc("make");
    }
    
    public void pause(){
        System.out.print("Enter any character to continue: "); in.next();
    }
}