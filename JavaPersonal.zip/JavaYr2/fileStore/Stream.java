package fileStore;
import java.io.FileWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.PrintWriter;
import java.io.PrintStream;

final class Stream {//implements Serializable{
    private static FileWriter fw;
    private static ObjectInputStream inObject;
    private static ObjectOutputStream outObject;
    private static FileInputStream inStream;
    private static FileOutputStream outStream;
    private static File file;
    
    static void a() throws IOException,ClassNotFoundException{
        file = new File("abc.txt");
        outStream = new FileOutputStream(file);
        inStream = new FileInputStream(file);
        outObject = new ObjectOutputStream(outStream);
        inObject = new ObjectInputStream(inStream);
        
        B b = new B();
        outObject.writeObject(b);
        Object a = inObject.readObject();
        
        fw = new FileWriter(file);
        PrintWriter pr = new PrintWriter(file);
        pr.println('a'+"");
        PrintStream ps = new PrintStream(outObject);
        ps.println("");
        PrintStream out = System.out;
        out.println("");
        System.out.println(a);
    }
}