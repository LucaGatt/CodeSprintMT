package fileStore;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.Serializable;

class B implements Serializable{

    static File file = new File("abc.txt");
    static FileWriter fw;
    static FileInputStream inFile;
    static Scanner readFile;
    static void m() {

        try{ readFile = new Scanner(file);
             fw = new FileWriter(file);
             Object a = new Object();
            fw.write("abc");
            fw.close();
            inFile = new FileInputStream(file);
            
        }
        catch(Exception e){}
        
        //while(true){
            System.out.print(readFile.next());
            readFile.close();
        //}
    }
}