package java2019SpecimenTask3;

public class Member{
    public Member(){ //parameterless constructor
        membershipNo = null;
        name = null;
        surname = null;
        mobNo = 0;
    }

    public Member(String membershipNo, String name, String surname, int mobNo){ // paramaterised constructor
        this.membershipNo = membershipNo;
        this.name = name;
        this.surname = surname;
        this.mobNo = mobNo;
    }

    //properties
    private String membershipNo, name, surname;
    private int mobNo;

    //Start GetterSetterExtension Source Code
    /**GET Method Propertie membershipNo*/
    public String getMembershipNo(){
        return this.membershipNo;
    }//end method getMembershipNo

    /**SET Method Propertie membershipNo*/
    public void setMembershipNo(String membershipNo){
        this.membershipNo = membershipNo;
    }//end method setMembershipNo

    /**GET Method Propertie name*/
    public String getName(){
        return this.name;
    }//end method getName

    /**SET Method Propertie name*/
    public void setName(String name){
        this.name = name;
    }//end method setName

    /**GET Method Propertie surname*/
    public String getSurname(){
        return this.surname;
    }//end method getSurname

    /**SET Method Propertie surname*/
    public void setSurname(String surname){
        this.surname = surname;
    }//end method setSurname

    /**GET Method Propertie mobNo*/
    public int getMobNo(){
        return this.mobNo;
    }//end method getMobNo

    /**SET Method Propertie mobNo*/
    public void setMobNo(int mobNo){
        this.mobNo = mobNo;
    }//end method setMobNo

    //End GetterSetterExtension Source Code
    
    
    public String toString(){
        return "Membership Number: "+ membershipNo + "\tName: "+ name
            +"\tSurname: "+surname+ "\tMobile Number: "+mobNo;
    }
}//End class