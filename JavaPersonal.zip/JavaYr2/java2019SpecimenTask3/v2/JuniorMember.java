package java2019SpecimenTask3.v2;
import java.util.*;

public class JuniorMember extends Member{
    private String type;

    private Scanner sc = new Scanner(System.in);

    // default constructor
    public JuniorMember(){
        super();
        type=null;
    }
    // parameterised constructor
    public JuniorMember(String memNo, String name, String surname, int mobNo){
        super(memNo, name, surname, mobNo);
        type="Junior";
    }

    //return junior member details
    public String toString(){
        return super.toString() + this.type;
    }

    public ArrayList<JuniorMember> addJuniorMember(ArrayList<JuniorMember> juniors){
        System.out.println("\nEnter Membership Number (id):");
        String memNo = sc.next();
        System.out.println("Enter Name:");
        String name = sc.next();
        System.out.println("Enter Surname:");
        String surname = sc.next();
        System.out.println("Enter Mobile Number:");
        int mobNo = sc.nextInt();

        juniors.add(new JuniorMember(memNo, name, surname, mobNo));

        return juniors;
    }//return updated array

    public void displayJuniorMembers(ArrayList<JuniorMember> juniors){
        System.out.println("\nDisplaying junior members' information: ");
        for (int i=0; i<juniors.size(); i++){
            System.out.println(juniors.get(i).toString());
        }
    } // no return since method performs output

    public ArrayList<JuniorMember> editJuniorMember(ArrayList<JuniorMember> juniors){
        if (juniors.size()==0){
            System.out.println("\nThere are no junior members to edit. Returning to Main menu...");
        }else{
            boolean exit = false;
            do{
                //JuniorMember s = new JuniorMember();

                this.displayJuniorMembers(juniors);

                //ask which member to edit
                boolean found = false;
                String memNoEdit;
                int memberIndexEdit =0;
                do{
                    System.out.println("\nChoose junior member to edit by Membership Number: ");
                    memNoEdit = sc.next();

                    for (int i=0;i<juniors.size() && !found;i++){
                        if (juniors.get(i).getMemNo().equals(memNoEdit)){
                            found = true;
                            memberIndexEdit = i;
                        }
                    }

                    if (!found){ // print error message if membership number not found
                        System.out.println("Membership number not found. Try again.");
                    }
                }while (!found); // loop until membership number input inside is correct

                //ask which detail to edit
                System.out.println(
                    "\nChoose which details do you want to edit:"+
                    "\n\t1. Membership Number"+
                    "\n\t2. Name"+
                    "\n\t3. Surname"+
                    "\n\t4. Mobile Number"+
                    "\n\t5. Return to Main Menu");

                switch(sc.nextByte()){
                    case 1: System.out.println("\nEnter new membership number:");
                        juniors.get(memberIndexEdit).setMemNo(sc.next());
                        break;
                    case 2: System.out.println("Enter new name:");
                        juniors.get(memberIndexEdit).setName(sc.next());
                        break;
                    case 3: System.out.println("Enter new surname:");
                        juniors.get(memberIndexEdit).setSurname(sc.next());
                        break;
                    case 4: System.out.println("Enter new mobile number:");
                        juniors.get(memberIndexEdit).setMobNo(sc.nextInt());
                        break;
                    case 5: exit= true;
                        break;
                    default: System.out.println("Invalid input. Try again.");
                }
            } while(!exit); // loop until user decides to exit and Return to Main Menu
        }
        return juniors;// return updated info
    }
}
