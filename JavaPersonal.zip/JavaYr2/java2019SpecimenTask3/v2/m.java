package java2019SpecimenTask3.v2;
import java.util.Scanner;

class m{
    
    static void m(){
        int mobNo = new Member().mobNo;
    }
}