package java2019SpecimenTask3.v2;

public class Member{
    private String memNo;
    private String name;
    private String surname;
    protected int mobNo;
    
    //default constructor
    public Member(){
        memNo = null;
        name = null;
        surname = null;
        mobNo = 0;
    }
    
    //parameterised constructor
    public Member(String memNo, String name, String surname, int mobNo){
        this.memNo = memNo;
        this.name = name;
        this.surname = surname;
        this.mobNo = mobNo;
    }
    
    //Start GetterSetterExtension Source Code

    /**GET Method Propertie memNo*/
    public String getMemNo(){
        return this.memNo;
    }//end method getMemNo

    /**SET Method Propertie memNo*/
    public void setMemNo(String memNo){
        this.memNo = memNo;
    }//end method setMemNo

    /**GET Method Propertie name*/
    public String getName(){
        return this.name;
    }//end method getName

    /**SET Method Propertie name*/
    public void setName(String name){
        this.name = name;
    }//end method setName

    /**GET Method Propertie surname*/
    public String getSurname(){
        return this.surname;
    }//end method getSurname

    /**SET Method Propertie surname*/
    public void setSurname(String surname){
        this.surname = surname;
    }//end method setSurname

    /**GET Method Propertie mobNo*/
    public int getMobNo(){
        return this.mobNo;
    }//end method getMobNo

    /**SET Method Propertie mobNo*/
    public void setMobNo(int mobNo){
        this.mobNo = mobNo;
    }//end method setMobNo

    //End GetterSetterExtension Source Code

    public String toString(){
        return "Membership Number: "+this.memNo+
        "\tName: "+this.name+
        "\tSurname: "+this.surname+
        "\tMobile Number: "+this.mobNo;
    }
}//End class