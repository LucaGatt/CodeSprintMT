package java2019SpecimenTask3.v2;
import java.util.Scanner;
import java.util.ArrayList;

public class Main_class{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        ArrayList<SeniorMember> seniors = new ArrayList();
        ArrayList juniors = new ArrayList();
        SeniorMember sm = new SeniorMember();
        JuniorMember jm = new JuniorMember();
        
        boolean exit = false;
        byte option = 0;
        do{
            menu();
            option = sc.nextByte();
            switch(option){
                case 1: seniors = sm.addSeniorMember(seniors); //add senior
                    break;
                case 2: juniors = jm.addJuniorMember(juniors); //add junior
                    break;
                case 3: sm.displaySeniorMembers(seniors); //display seniors
                    break;
                case 4: jm.displayJuniorMembers(juniors); //display juniors
                    break;
                case 5: seniors = sm.editSeniorMember(seniors); //edit seniors
                    break;
                case 6: juniors = jm.editJuniorMember(juniors); //edit juniors
                    break;
                case 7: exit = true;
                    System.out.println("Application terminated.");
                    break;
                default: System.out.println("Try again");
            }
        }while(!exit);

    }

    private static void menu(){
        System.out.println(
            "\nEnter an option according to following menu:"+
            "\n\t1. Enter Senior Member"+
            "\n\t2. Enter Junior Member"+
            "\n\t3. Display Senior Member"+
            "\n\t4. Display Junior Member"+
            "\n\t5. Edit Senior Member"+
            "\n\t6. Edit Junior Member"+
            "\n\t7. Exit");
    }
}