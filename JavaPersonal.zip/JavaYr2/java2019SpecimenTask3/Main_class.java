package java2019SpecimenTask3;
import java.util.*;
import java.io.PrintStream;

public class Main_class{
    static Scanner sc = new Scanner(System.in); //objects initialisations
    static PrintStream out = System.out;

    static ArrayList<SeniorMember> seniors = new ArrayList();
    static ArrayList<JuniorMember> juniors = new ArrayList();
    
    static byte option = 0;
    public static void main(String args[]){
        boolean exit= false;
        do{
            out.println("Enter option from 1-7: "+
                "\n1. Enter Senior Member "+
                "\n2. Enter Junior Member "+
                "\n3. Display Senior Member "+
                "\n4. Display Senior Member "+
                "\n5. Edit Senior Member "+
                "\n6. Edit Senior Member "+
                "\n7. Exit"
            );
            option = sc.nextByte();

            switch(option){ // choosing option according to user input
                case 1: option1(); break;
                case 2: option2(); break;
                case 3: option3(); break;
                case 4: option4(); break;
                case 5: option5(); break;
                case 6: option6(); break;
                case 7: exit = true; break;
            }
        }while(!exit);
    }

    //methods for options
    private static void option1(){ //enter senior member
        SeniorMember senior = new SeniorMember();

        System.out.println("Enter Senior Member details: "+
            "\nEnter membershipNo (id): ");
        senior.setMembershipNo(sc.next());
        System.out.println("Enter name: ");
        senior.setName(sc.next());
        System.out.println("Enter surname: ");
        senior.setSurname(sc.next());
        System.out.println("Enter mobile number: ");
        senior.setMobNo(sc.nextInt());

        if(option ==1)seniors.add(senior);
        else if (option==5){} //
    }

    private static void option2(){ //enter junior member
        JuniorMember junior = new JuniorMember();

        System.out.println("Enter Junior Member details: "+
            "\nEnter membershipNo (id): ");
        junior.setMembershipNo(sc.next());
        System.out.println("Enter name: ");
        junior.setName(sc.next());
        System.out.println("Enter surname: ");
        junior.setSurname(sc.next());
        System.out.println("Enter mobile number: ");
        junior.setMobNo(sc.nextInt());

        juniors.add(junior);
    }

    private static void option3(){ //display senior members
        System.out.println("Displaying senior members:");
        String details="";
        for (int i=0; i<seniors.size(); i++){
            details += "\n"+seniors.get(i).toString();
        }
        System.out.println(details);
    }

    private static void option4(){ //display junior members
        System.out.println("Displaying junior members:\n");
        String details="";
        for (int i=0; i<juniors.size(); i++){
            details += "\n"+juniors.get(i).toString();
        }
        System.out.println(details);
    }

    private static void option5(){ //edit senior member
        System.out.print("Enter which senior member do you want to edit according to Membership Number: ");
        String membershipNo = sc.next();
        for (byte i=0; i<seniors.size(); i++){
            SeniorMember senior= seniors.get(i);
            if (senior.getMembershipNo().equals(membershipNo)){
                option1(); //enter senior member details
            }
        }
    }

    private static void option6(){ //edit junior member
        System.out.print("Enter which junior member do you want to edit according to Membership Number: ");
        String membershipNo = sc.next();
        for (byte i=0; i<juniors.size(); i++){
            JuniorMember junior= juniors.get(i);
            if (junior.getMembershipNo().equals(membershipNo)){
                option2(); //enter senior member details
            }
        }
    }
}