package java2019SpecimenTask3;

public class SeniorMember extends Member{
    public SeniorMember(){ //parameterless constructor
        super();
    }
    public SeniorMember(String membershipNo, String name, String surname, int mobNo){ // paramaterised constructor
        super(membershipNo, name, surname, mobNo);
    }
    
    //return details of senior member
    public String toString(){
        return super.toString();
    }
}