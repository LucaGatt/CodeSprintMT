package java2019SpecimenTask3;

public class JuniorMember extends Member{
    public JuniorMember(){ //parameterless constructor
        super();
    }
    public JuniorMember(String membershipNo, String name, String surname, int mobNo){ // paramaterised constructor
        super(membershipNo, name, surname, mobNo);
    }
    
    //return details of junior member
    public String toString(){
        return super.toString();
    }
}
