import java.util.Scanner;
class Factorial{
    public static void main(String args[]){
        print("Enter number to find its factorial");
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        System.out.println(recursion(num));//output factorial
    }
    static int recursion(int a){
        if (a!=0) return a*recursion(a-1);
        else return 1;
    }
    static void print(String a){
        System.out.println(a);
    }
}