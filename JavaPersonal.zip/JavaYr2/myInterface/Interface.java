package myInterface;
public interface Interface{
    byte x =0;
    public void prin();
    
    public void Interface();
}