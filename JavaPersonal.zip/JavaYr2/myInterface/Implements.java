package myInterface;

abstract public class Implements implements Interface{
    public void print(){
        System.out.println("a");
    }
    public Implements(){
        
    }
}