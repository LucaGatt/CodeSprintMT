package AccountsHW;
import java.util.Scanner;
class IO{

//input
static Scanner in = new Scanner(System.in);
static String next(){
    in.useDelimiter("\n");//for sentence or phrase
    return in.next();
}
static int nextInt(){
    return in.nextInt();
}
static byte nextByte(){
    return in.nextByte();
}
static short nextShort(){
    return in.nextShort();
}
static double nextDouble(){
    return in.nextDouble();
}

//output
static void print(){
    System.out.println();
}
static void print(String a){
    System.out.println(a);
}
}
