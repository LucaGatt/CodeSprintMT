package AccountsHW;
import javax.swing.*;
import java.awt.event.*;

class Frame{
    static void setFrame(){
        JFrame frame = new JFrame();
        frame.setSize(800,600);
        JButton button = new JButton("test");
        JTextField t= new JTextField();
        frame.add(button);
        frame.setVisible(true);
        
        JComboBox c = new JComboBox();
        c.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            t.setText("index: " + c.getSelectedIndex() + "   "
                + ((JComboBox) e.getSource()).getSelectedItem());
          }
        });
    }
}