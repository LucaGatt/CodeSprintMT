package AccountsHW;

class Looping extends IO{
    static String loop(String askUser){
        boolean a= false;
        String input;
        do{
            a=false;
            print(askUser);
            input = next();
            if(!input.equals("yes") && !input.equals("no")) a = true;
        }while(a);
        return input;
    }
    static String validInput(String askUser){
        return loop(askUser);
    }
    static String enterMore(){
        return loop("Do you want to enter more entries?");
    }
}