package AccountsHW;

//import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.event.*;
import java.util.Iterator;

class Accounts extends IO{
    static ArrayList<Byte> accCodes=new ArrayList();
    static ArrayList<String> accNames=new ArrayList();
    static ArrayList<Integer> values=new ArrayList();
    static ArrayList<String> stat=new ArrayList();//pl or sofp
    static byte accCodeCounter = 0;
    
    //class a extends Looping{

    static void main(){
        initialiseAccounts();
    }
    static void initialiseAccounts(){
        print("From trial balance:");
        boolean enterMore=false;
        boolean firstLoop=true;
        do{
            String input;
            enterMore=false;
            if(firstLoop){ input = "yes"; enterMore = true;}
            else input = Looping.validInput("Enter more entries?"); // input = yes/no
            
            if (input.equals("yes")){
                newAccountEntry();
                enterMore= true;
            }
            
            firstLoop = false;
        }while(enterMore);
        output();// to show acc balances in Trial Balance
        
        boolean more = false;
        do{
            enterAdjustment();
            print("Do you want to enter another adjustment?");
            more = in.next().equals("yes");
        }while(more);
        
        output(); //final output
    }
    static void output(){
        Iterator<Byte> code= accCodes.iterator();
            Iterator<String> name= accNames.iterator();
            Iterator<Integer> value= values.iterator();
            Iterator<String> statIter= stat.iterator();
        while(code.hasNext()){
            print("Code: "+code.next()+"\tName: "+name.next()+
                "\tValue: "+value.next()+"\tStatment to input in: "+statIter.next());
        }
    }
    
    static void enterAdjustment(){
        print("Enter option number from:");
        print("0.Manual, 1.Depreciation, 2.Accruals and Prepayments");
        byte option = in.nextByte();
        switch(option){
            case 1: 
                print("Choose by option number:\n"+
                "1. Depreciation on Cost for Year"+
                "2. Depreciation on NBV for Year"+
                "3. Depreciation on Cost for disposal"+
                "4. Depreciation on NBV for disposal");
                switch(in.nextByte()){
                    case 1: Depreciation.costForYear(values); break;
                    case 2: Depreciation.NBVforYear(values); break;
                    case 3: Depreciation.costDisposal(values); break;
                    case 4: Depreciation.NBVdisposal(values); break;
                }
                break;
            
            case 2: //accruals and prepayments
        }
        if (option==0){
            print("Adjust value by how much?");
            int change = in.nextInt();
            for (byte i=0; i<2; i++){ // double-entry
                print("New account?");
                String newAcc = in.next();
                if (newAcc.equals("no")){
                    print("Select by accCode. Which acc do you want to adjust?");
                    byte codeIn = in.nextByte();
                    print("value add or subtract(sub) the change?");
                    String sign = in.next();
                    values.set(codeIn, values.get(codeIn)+change* (sign.equals("sub")? -1 : 1));//.set(index,value); .get(index);
                }else{
                    accCodes.add(accCodeCounter);
                    print("Enter Account name");
                    accNames.add(next());
                    values.add(change);
                    print("pl or sofp?");
                    stat.add(next());
                    accCodeCounter++;
                }
            }
        }
    }
    static void newAccountEntry(){
        accCodes.add(accCodeCounter);
        print("Enter Account name");
        accNames.add(next());
        print("Enter value");
        values.add(nextInt());
        print("pl or sofp?");
        stat.add(next());
        accCodeCounter++;
    }
    
    //}
}