package AccountsHW;
import java.util.ArrayList;

abstract class Depreciation extends IO{ // needs implementation in main class
    static int NBVforYear(ArrayList<Integer> values){
        print("What is the accCode of asset acc?");
        int assetValue = values.get(in.nextByte());
        print("What is the accCode of depreciation acc?");
        int depreciationValue = values.get(in.nextByte());
        print("percentage");
        byte percent = in.nextByte();
        
        return (int)((assetValue-depreciationValue)*percent/100);
    }
    static int costForYear(ArrayList<Integer> values){
        print("What is the accCode of asset acc?");
        int assetValue = values.get(in.nextByte());
        print("percentage");
        byte percent = in.nextByte();
        
        return (int)(assetValue*percent/100);
    }
    static int NBVdisposal(ArrayList<Integer> values){
        print("Intial cost of asset?");
        int cost = in.nextInt();
        print("Enter percent:");
        double rate = in.nextByte()/100;
        print("No of yrs?");
        int total= 0;
        for(byte q=0; q<in.nextByte();q++){ //ar*q
            total+= cost*rate*Math.pow(1-rate,q);
        }
        return total;
    }
    static int costDisposal(ArrayList<Integer> values){
        print("No of yrs?");
        return costForYear(values)*in.nextByte();
    }
}