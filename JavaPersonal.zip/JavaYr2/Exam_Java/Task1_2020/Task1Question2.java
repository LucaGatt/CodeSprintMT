package Exam_Java.Task1_2020;

//Luca Gatt 355004L
import java.util.Scanner;
class Task1Question2{
    public static void main(String args[]){
        //a)
        print("Enter 2 decimal numbers: ");
        Scanner in= new Scanner(System.in); //declare, intialise
        int[] num = new int [2];
        for (int i=0; i<2; i++){
            num[i] = in.nextInt();
        }
        //b)
        int addition = num[0] + num[1];
        int difference = num[0] - num[1];
        if(difference<0) difference = num[1] - num[0];
        int multiplication = num[0]*num[1];
        double average = (num[0]+num[1])/2;
        int max;
        if (num[0]>num[1]) max = num[0];
        else max= num[1];
        
        //output
        print("Addition is: "+addition+"\nDifference is: "+difference+
            "\nMultiplication: "+multiplication+"\nAverage: "+average+"\nMaximum: "+max);
        
        //c)
        int input = 1; //init for loop
        int c;
        print("");//new line
        for (c=-1; input!=0; c++){ // c= counter
            print("Enter number (when 0, count of non-zero numbers is output):");
            input = in.nextInt();
        }
        print("Counter of non-zero numbers inputted: "+c);
    }
    public static void print(String a){
        System.out.println(a);
    }
}