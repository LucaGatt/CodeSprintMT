package Exam_Java.Task1_2020;

//Luca Gatt 355004L
import java.util.Scanner;
class Task1Question1{
    public static void main(String args[]){
        //a)
        print("Enter a non-negative integer:");
        Scanner in = new Scanner(System.in);
        int num = in.nextInt(); // to find its factorial
        
        int factorial = 1; //intialise variable with factorial of 0 or 1
        for(int i=num; i>1; i--){
            factorial*=i;
        }
        print("Factorial of "+num+" is: "+factorial);
        
        //b)
        if (factorial>1000) print("Greater than");
        else print("Less than");
        
        //c)
        //average between factorial and 1000
        
        double average= (double) (factorial+1000)/(double) 2;
        int difference = factorial-1000;
        if(difference<0) difference = 1000-factorial; //if difference is negative with 1st calculation, change signs
        
        //output
        print("Average is "+average+" and Difference is "+difference);
    }
    public static void print(String a){
        System.out.println(a);
    }
}