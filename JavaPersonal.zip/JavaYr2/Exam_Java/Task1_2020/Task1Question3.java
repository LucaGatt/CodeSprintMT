package Exam_Java.Task1_2020;

//Luca Gatt 355004L
import java.util.Scanner;

class Task1Question3{
    public static void main(String args[]){
        //a)
        print("Enter number from 0-9:");
        Scanner in = new Scanner (System.in);//declare, initialise Scanner
        int digit = in.nextInt();
        //0 and 1 are not prime
        switch(digit){
            case 2: case 3: case 5: case 7: print("Prime"); break;
            default: print("Not Prime");
        }
        
        //b)
        int r=digit;
        double pi=3.1425; //since Math.PI cannot be used in this paper
        double area = pi*r*r;
        double circumference = 2*pi*r;
        print(area+"\t"+circumference);
        
        //c)
        //swap
        double tmp = area;
        area = circumference;
        circumference = tmp;
    }
    public static void print(String a){
        System.out.println(a);
    }
}