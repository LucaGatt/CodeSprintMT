package Exam_Java.Task2_2020;

//Luca Gatt 355004L
public class BubbleSort{
    //declare, initialise for testing
    private static int[] intArray = {9,4,7,1,3};
    private static float[] floatArray = {3.2f,1.7f,44.3f,22.9f,17.4f};
    //

    public static void main(String args[]){ //output for testing
        int[] intA = bubbleSort(intArray);
        print("Sorted array:\ninteger ->");
        for (int i=0; i<intA.length; i++){
            System.out.print(intA[i]+ " ");
        }
        float[] floatA = bubbleSort(floatArray);
        print("\nfloat ->");
        for (int i=0 ; i<floatA.length; i++){    
            System.out.print(floatA[i]+" ");
        }
    }

    private static int[] bubbleSort(int[] array){// bubble sort for int array
        boolean isSwapped = false;
        do{
            isSwapped = false;

            for (int i =0; i< array.length-1 ; i++){
                if (array[i] > array[i+1]){
                    int tmp = array[i];
                    array[i] = array[i+1];
                    array[i+1] = tmp;
                    isSwapped =true;
                }
            }
        }while (isSwapped);
        return array;
    }

    private static float[] bubbleSort(float[] array){// bubble sort for float array
        boolean isSwapped = false;
        do{
            isSwapped = false;

            for (int i =0; i< array.length-1 ; i++){
                if (array[i] > array[i+1]){
                    float tmp = array[i];
                    array[i] = array[i+1];
                    array[i+1] = tmp;
                    isSwapped = true;
                }
            }
        }while (isSwapped);
        return array;
    }

    public static void print(String a){// output method
        System.out.println(a);
    }
}