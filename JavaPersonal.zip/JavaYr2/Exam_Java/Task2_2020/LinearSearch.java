package Exam_Java.Task2_2020;

//Luca Gatt 355004L
public class LinearSearch{
    private static int[] array = {3,8,9,2,1};
    private static int value = 9;
    
    private static int linearSearch(int[] array, int value){ // linear search method needing the array to search in and the value to find in it
        int index=-1;
        for (int i=0; i<array.length; i++){
            if (array[i] == value){
                index = i;
            }
        }
        return index;
    }

    public static void main (String args[]){// test results
        int index = linearSearch(array,value);
        
        if(index==-1) System.out.println("Number not found.");
        else System.out.println("Number was found in element "+index);
    }
}