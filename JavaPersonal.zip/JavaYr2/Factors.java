import java.util.Scanner;
import java.util.ArrayList;
class Factors{
    static Scanner in = new Scanner (System.in);
    static int num;
    static ArrayList<Integer> factors = new ArrayList();
    //static boolean isFactor = false;
    
    public static void main(String[] args){
        System.out.println("Enter number to find its factors:");
        num = in.nextInt();
        for(int i=1; i<=num; i++){
            if (num%i==0) {factors.add(i);}
        }
        print("Factors of "+num+ " are: "+ factors);
    }
    static void print(String a){
        System.out.println(a);
    }
}