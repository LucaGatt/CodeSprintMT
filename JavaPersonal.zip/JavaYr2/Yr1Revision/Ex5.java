package Yr1Revision;
class Ex5{
    public static void main(String args[]){
        for(byte i=1,j=9; i<10; i++,j--){
            System.out.println("first number "+i+", second number "+j);
        }
    }
}