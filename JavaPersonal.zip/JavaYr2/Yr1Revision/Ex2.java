package Yr1Revision;
import java.util.Scanner;
class Ex2{
    public static void main(String args[]){
        System.out.println("Enter 3 integers:");
        Scanner in= new Scanner(System.in);
        short[] num = new short [3];
        for (byte i=0;i<3;i++) num[i] = in.nextShort();
        
        //total
        short total = 0;
        for (byte i=0; i<3;i++) total+=num[i];
        
        float average = (float)total/3;
        
        short max = 0;
        for (byte i=0;i<3;i++){
            if(num[i]>max)max= num[i];
        }
        short min = num[0];
        for (byte i=1;i<3;i++){
            if(num[i]<min)min = num[i];
        }
        
        //output
        System.out.println(
            "Total: "+total+"\tAverage: "+average
            +"\nMinimum: "+min+"\tMaximum: "+max);
    }
}