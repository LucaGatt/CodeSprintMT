package Yr1Revision;

import java.util.Scanner;
class Ex6{
    public static void main(String args[]){
        Scanner in=  new Scanner (System.in);
        System.out.print("Enter integer to be used as multiplier: ");
        int multiplier = in.nextInt();
        for (byte i=1;i<16;i++){
            System.out.println(i+" x "+multiplier+ " = "+(i*multiplier));
        }
    }
}