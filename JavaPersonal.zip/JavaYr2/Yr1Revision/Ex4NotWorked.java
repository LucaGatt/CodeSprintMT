package Yr1Revision;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
class Ex4NotWorked{
    public static void main(String args[]){
        ArrayList<Byte> mark = new ArrayList<>(1);
        Scanner in = new Scanner (System.in);
        byte num;
        do{
            do{
                System.out.println("Enter mark or enter -1 if ready:");
                num= in.nextByte();
            }while(num>100 || num<-1);
            if(num!=-1)mark.add(num);
        }while (num!=-1);
        
        //total
        Iterator iter = mark.iterator();
        short i=-1;
        short total =0;
        while(iter.hasNext()){
            total+=mark.get(i+1);
        }
        float average= (float)total/i;
        
        //output
        System.out.println("Total of marks: "+total+"\tAverage: "+average);
    }
}