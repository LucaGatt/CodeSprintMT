package Yr1Revision;
import java.util.Scanner;
class Ex7{
    public static void main(String args[]){
        int num = askInt();
        
        //A.square output
        System.out.println("A.\n");
        for (byte i=0; i<num; i++){
            for (byte j=0; j<num; j++){
                System.out.print("x");
            }
            System.out.println();
        }
        System.out.println("\nB.\n");
        for(byte i=0;i<num;i++){
            for (byte j=0; j<=i; j++){
                System.out.print("x");
            }
            System.out.println();
        }
        System.out.println("\nC.\n");
        for (byte i=0; i<num;i++){
            for (byte j=0; j<num; j++){
                if (i==0 || i==num-1 || j==0 || j==num-1)
                    System.out.print("x");
            }
            System.out.println();
        }
    }
    public static int askInt(){
        System.out.println("Enter an integer: ");
        Scanner in= new Scanner (System.in);
        return in.nextInt();
    }
}