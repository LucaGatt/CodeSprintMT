import java.util.Scanner;
import java.util.ArrayList;
class PrimeNum{
    static int num =0;
    static boolean prime = true;
    static Scanner in = new Scanner(System.in);
    static ArrayList<Integer> primeNums;
    public static void main(String args[]){
        primeNums = new ArrayList();
        System.out.println(
            "This program will output the list of prime numbers until"
            +"the number input.\nPlease enter a number.");
        num = in.nextInt();
        for (int i=2; i<=num; i++){// incrementing num till num inputted by user
            for (int divider=2; divider<i; divider++){// incrementing divider till num
                if(i%divider==0 && i/divider!=1) prime=false;
            }
            if(prime) primeNums.add(i);
            prime = true; //intialise for next run
        }
        System.out.println("Prime Numbers till "+num+" are: "+primeNums);
        //if (num<2) prime=false;
    }
}