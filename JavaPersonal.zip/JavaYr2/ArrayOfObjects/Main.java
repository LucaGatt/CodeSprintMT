package ArrayOfObjects;
import java.util.ArrayList;
import java.util.Scanner;

class Main{
    static Scanner in = new Scanner (System.in);
    static ArrayList<Student> students = new ArrayList();
    static void main(){
        Student tmp = new Student();
        for (byte i=0; i<2; i++){
            print("Enter id:");
            tmp.id = in.next();
            print("Enter name:");
            tmp.name = in.next();
            print("Enter surname:");
            tmp.surname = in.next();
            for (byte j=0; j<6;j++){
                print("Enter marks:");
                tmp.marks.add(in.nextInt());
            }
        }
        students.add(tmp);
        
        output();
    }
    static void output(){
        print("List of students: ");
        for(byte i=0; i<students.size();i++){
            //print(students.get(0).id); works
            Student tmp = students.get(i);
            
            
            //var for output
            String print =
                "ID:"+tmp.id+"\nName: "+tmp.name+"Surname: "+tmp.surname;
            
            //take care of marks since it is ArrayList, not a normal var
            for (byte j=0; j<tmp.marks.size();i++){
                print+= "\nMark"+i+": "+tmp.marks.get(i);
            }
            print(print);
        }
    }
    static void print(String a){
        System.out.println(a);
    }
}