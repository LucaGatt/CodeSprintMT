package ArrayOfObjects;
import java.util.ArrayList;
import java.util.Scanner;

class Student{
    static Scanner in = new Scanner (System.in);
    
    String id = new String();
    String name = new String();
    String surname = new String();
    ArrayList<Integer> marks = new ArrayList();
}