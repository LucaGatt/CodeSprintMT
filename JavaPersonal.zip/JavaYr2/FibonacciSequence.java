
/**
 * Write a description of class FibonacciSequence here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FibonacciSequence
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class FibonacciSequence
     */
    public FibonacciSequence()
    {
        // initialise instance variables
        x = 0;
    }

    int num1 =0, num2=1, print= 0;

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int acreateSequence(int n)
    { // 0,1,1,2,3,5,8,13
        //int num1 =0, num2=1, print= 0;
        for (int i = 0; i<6 ; i++){
            if(num1==0) print = 0;
            else if(num1==1) print = 1;
            else print = num1;
            //new num1,num2
            int tmp =num1;
            num1=num2;
            num2+=tmp;
            System.out.print(print);
        }
        return num1;
    }

    public int createSequence(int n){
        int num1=0,num2=1;
        for (int i=0; i<=n-1; i++){// from 0 till n
            //if (n == 0) return 0;
            //else if (n == 1) return 1;
            //else {
                int tmp = num1;
                num1 = num2;
                num2 += tmp;
            //}
        }
        return num1;
    }
}
