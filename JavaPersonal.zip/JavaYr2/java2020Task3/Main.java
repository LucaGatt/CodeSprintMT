package java2020Task3;
import java.util.*;

public class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);

        ArrayList<Property> properties = new ArrayList();
        
        Apartment a = new Apartment();
        House h = new House();
        
        byte option = 0;
        do{
            System.out.println("\n\nEnter option from the main menu: "+
                "\n\t1. Enter New Apartment"+
                "\n\t2. Enter New House"+
                "\n\t3. Display Apartments and Houses"+
                "\n\t4. Edit Apartment price by ID"+
                "\n\t5. Edit House price by ID"+
                "\n\t6. Exit"
            ); // menu
            option = sc.nextByte();
            
            switch(option){
                case 1: properties = a.enterNewApartment(properties);
                    break;
                case 2: properties = h.enterNewHouse(properties);
                    break;
                case 3: properties.get(0).displayProperties(properties);
                    break;
                case 4: properties = a.editApartmentPrice(properties);
                    break;
                case 5: properties = h.editHousePrice(properties);
                    break;
            }
        }while(option != 6);
        System.out.println("Application terminated.");
    }
}