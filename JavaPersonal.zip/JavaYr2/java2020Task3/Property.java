package java2020Task3;
import java.util.ArrayList;


public class Property
{
    // instance variables - replace the example below with your own
    private int id;
    private String location;
    private int price;
    

    /**
     * Default Constructor for objects of class Property
     */
    public Property()
    {
        // initialise instance variables
        id = 0;
        location = null;
        price = 0;
    }
    
    /**
     * Parameterised Constructor for objects of class Property
     */
    public Property(int id, String location, int price){
        this.id = id;
        this.location = location;
        this.price = price;
    }
    
    //Getters and Setters
    public int getId(){
        return this.id;
    }
    public String getLocation(){
        return this.location;
    }
    public int getPrice(){
        return this.price;
    }
    
    public void setId(int id){
        this.id = id;
    }
    public void setLocation(String location){
        this.location = location;
    }
    public void setPrice(int price){
        this.price = price;
    }
    
    //toString() method to return details of property
    public String toString(){
        return "\nID: "+id + "\tLocation: "+location + "\tPrice:"+price;
    }
    
    /*
    method to display properties
    return - void .. since the scope of method is to output properties' data
    */
    public void displayProperties(ArrayList<Property> properties){
        System.out.println("\nDisplaying properties:"); // make space between 2 sets of operations
        for (int i=0; i<properties.size(); i++){
            System.out.print(properties.get(i).toString());
        }
    }
}
