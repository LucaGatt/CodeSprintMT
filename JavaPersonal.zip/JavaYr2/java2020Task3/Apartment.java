package java2020Task3;
import java.util.*;

/**
 * Write a description of class Apartment here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Apartment extends Property
{
    //default constructor
    public Apartment(){
        super();
    }
    //paramaterised consturctor
    public Apartment(int id, String location, int price){
        super(id,location, price);
    }
    
    //method overriding for customisation
    public String toString(){
        return super.toString() + "\tType: Apartment";
    }

    static Scanner sc = new Scanner(System.in);

    public ArrayList<Property> enterNewApartment(ArrayList<Property> properties){
        System.out.println("\nEnter ID: ");
        int id = sc.nextInt();
        System.out.println("Enter location: ");
        String location = sc.next();
        System.out.println("Enter price");
        int price = sc.nextInt();

        //check if id is unique
        boolean unique = true;
        do{
            unique = true;
            for (int i =0; i< properties.size() && !unique; i++){
                if(properties.get(i).getId() == id){ // if id is not unique
                    unique = false;
                    System.out.println("ID must be unique. Input an unused ID: ");
                    id = sc.nextInt(); // ask user to re-enter ID
                }// entering if branch will make the for loop stop and the checking of Id is started again
            }
        }while(!unique); // loop until ID is unique
        
        properties.add(new Apartment(id,location,price)); // add new apartment to array
        return properties; // return updated array
    }
    
    public ArrayList<Property> editApartmentPrice(ArrayList<Property> properties){
        System.out.print("Enter ID of apartment to edit: ");
        int idEdit= sc.nextInt();
        System.out.print("Enter new price: ");
        int price = sc.nextInt();
        properties.get(idEdit).setPrice(price); // change price
        
        return properties; // return updated array
    }
}
