import java.awt.Robot;
import java.awt.event.KeyEvent;
class fbaddfriend_v2{
public static void main(String args[]) throws Exception{

Robot robot = new Robot();
while(true){
for(byte i=0;i<2;i++){
robot.keyPress(KeyEvent.VK_TAB);
robot.keyRelease(KeyEvent.VK_TAB);
}
robot.keyPress(KeyEvent.VK_ENTER);
robot.keyRelease(KeyEvent.VK_ENTER);
}

}}