from pyinput.keyboard import Key, Controller
import time
keyborad = Controller()
time.sleep(2)
while true:
	keyboard.press(Key.tab)
	keyboard.release(Key.tab)
	time.sleep(0.2)
	keyboard.press(Key.tab)
	keyboard.release(Key.tab)
	keyboard.press(Key.enter)
	keyboard.release(Key.enter)
	time.sleep(.5)