class fbaddfriend{
public static void main(String args[])throws Exception{

for(short i=0;i<=820-194;i+=87){

Runtime.getRuntime().exec("timeout /t 2");
Runtime.getRuntime().exec("mouse moveto 924x"+(194+i));
Runtime.getRuntime().exec("mouse click");

}

}}