import java.awt.Window;
class activewindow{public static void main(String args[]){
Window activeWindow = javax.swing.FocusManager.getCurrentManager().getGlobalActiveWindow();
System.out.println(activeWindow);
}}