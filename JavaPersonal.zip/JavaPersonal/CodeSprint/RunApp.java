import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;

public class RunApp{
    public static void main (String[] args) {
        System.out.print("\f");//clear console window
        ArrayList<String> playerNames = new ArrayList();
        Scanner in = new Scanner(System.in);
        byte boxesNo = 22;
        
        // prizes and randimisation
        int[] prizes = {
            1,5,10,20,30,40,50,75,100,200,500,750,1000,2500,5000,
            7500,10000,15000,20000,25000,37500,50000
        }; //ordered
        ArrayList<Integer> boxes = new ArrayList(boxesNo);
        byte min = 1-1, max=(byte)(boxesNo-1);
        for (byte i=0;i<boxesNo;i++){
            boolean equal = false;
            byte a;
            do{
                a = (byte)(Math.random()*(max-min+1) +min);
                
                Iterator<Integer> it = boxes.iterator();
                while (it.hasNext()){
                    Integer x=it.next();
                    if (x==prizes[a]) equal = true;
                }
                /*
                for (byte j=i;j>=0;j--){ //check if prize already settled
                    //if (prizes[a] == boxes.get(j)) equal = true;
                    //boxes.search(prizes[a]);
                }*/
                
                System.out.println("Prizes: "+prizes);
                /*
                while(it
                    System.out.println(boxes.get(j));
                }*/
                System.out.println();
            }while (equal); // loop if number already settled
            boxes.add(prizes[a]);// randimisation secure so prize is added
        }
        
        //player name
        System.out.print("Enter player name:");
        playerNames.add(in.next());
        
        //menu
        byte option;
        boolean optionInvalid=false;
        do{
            
            option = 0;
            try{
                System.out.println("Choose option from the following menu:");
                System.out.println(
                    "1) View Hall of Fame\n2) Start Game\n3) Quit Game");
                option = in.nextByte(); //input
            } catch(Exception e){
                System.out.println("Invalid input");
                optionInvalid=true;
                option=0;
            }
            if (!optionInvalid) //decision made if option is still valid
                optionInvalid = ((option<1)||(option>3));
            
        } while (optionInvalid); //loop until option is from 1-3
        
        
        switch (option){
            case 1://view hall of fame
                break;
            
            case 2: gameStart(); //start game
                break;
                
            case 3: System.exit(0);
                
        }
    }
    
    public static void gameStart() {
        /* code */
    }
}