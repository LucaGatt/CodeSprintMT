class Linked{
    public static void main(String args[]){
        Node node = new Node("test",null);
        Node node1 = new Node("1",null);
        node1.addNodeAfter(node);
    }
}