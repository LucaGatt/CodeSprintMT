class Nod{
    //node = (data, next)
    String data;
    int next;
    
    public void set(String data, int next){
        this.data = data;
        this.next = next;
    }
    int print(){
        GUI.print(data);
        return next;
    }
}