public class LinkedList{
    /*nodes linked together
     class Node()
     */
    
    static int next;
    
    static void main(){
        Nod[] a = new Nod [2];
        for(byte i=0;i<2;i++){
            a[0] = new Nod();
        }
        int start = 0;
        try{
            a[0].set("Mary", 1); //pos, data, next
            a[1].set("Bob", -1);
        } catch(Exception e){
            GUI.error("Error");
        }
        
        next = start;
        while (next>-1){
            next = a[next].print();
        }
    }
}