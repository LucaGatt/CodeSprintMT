import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
class Ttv{
 static Scanner in = new Scanner(System.in);
 static FileWriter fw;
 //static FileReader fr;
 static StringBuilder sb= new StringBuilder();
 
 public static void main(String[] args) throws Exception{
  
  while(true){
	
	System.out.println("To calculate no of days needed to attain 100,000..");
	System.out.println("Enter current coins:");
	int x= in.nextInt();
	double ans = ((double)(100000-x)/(double)(500));
	System.out.println(ans+" days");

	System.out.println("Enter battery percentage:");
	int percent = in.nextInt();
	
	sb= new StringBuilder();
	//try{
	 try(FileReader fr=new FileReader("DaysRemaining.txt")){  
         	int i;    
         	while((i=fr.read())!=-1)    
         		sb.append(((char)i+"").toString());//previous inputs stored   
         //fr.close();  
	 }
	 
	 String c = ("Coins: "+x);
	 String a = (ans+" days").toString();
	 String b = ("\nBattery: "+(percent+" %\n\n")).toString();
	 sb.append(c+a+b);
	 fw= new FileWriter("DaysRemaining.txt");
	 //fw.open();
	 fw.write(sb.toString());
	 fw.close();
	/*}catch(Exception e){
	 System.out.println("Error!");
	}*/
	
  }
 }
}