class test{
    
    private int x;
    
}