package probabilityMaths;
import java.util.Scanner;

class m{
    static Scanner in = new Scanner(System.in);
    static void main(){
        //print("Range of die:");
        byte times = 3; //in.nextByte();
        byte range = 12;//in.nextByte();
        int[][][] a = new int[range][range][range];

        int c = 0;
        for (byte i=1; i<=range; i++){
            for (byte j=1; j<=range; j++){
                for (byte k=1; k<=range; k++){
                    //System.out.println(i+" "+j+" "+k);
                    c++;
                    if(i==j && j==k) System.out.print(true);// 12.. means no repetition of 1,1,1
                }
            }
        }
        print(c);
    }

    static void print(int a){
        System.out.print(a);
    }
}