import java.util.ArrayList;

class RandomArray{
    static ArrayList<Integer> a = new ArrayList();

    static void init(){
        flushArr();
        
        //genRanNum
        boolean identical;
        boolean arr1Ele;
        for(byte elements=0;elements<5;elements++){
            identical=false; //reset flag for each element
            a.add(genRanNum(0,10));
            do{
                
                arr1Ele= (a.size()!=1); // no comparison since made up of 1 element
                if(!arr1Ele){
                    for (int i=0; i<a.size()-1; i++){ // check all elements with last element
                        if (!identical){ //if identity between 2 elements not already found
                            identical= (a.get(a.size()-1)==a.get(i)); //last element==another element
                        }
                    }
                }
                if (identical) a.set(a.size()-1, genRanNum(0,10)); // then refresh genRanNum()
                identical=false;//reset for every genRanNum() refresh
            }
            while(identical);
        }

        print(a.toString());
    }

    private static int genRanNum(int min, int max){
        return (int)Math.random()*(max-min+1)+min;
    }

    private static void flushArr(){
        byte iter= (byte)(a.size());
        for (byte i=0; i<iter;i++) a.remove(0);
    }
    
    private static void print(String a){
        System.out.print(a);
    }
    private static void println(String a){
        System.out.println(a);
    }
}