import javax.swing.JOptionPane;

abstract class GUI extends JOptionPane{
    public static void error(String message){
        showMessageDialog(null, message, null, JOptionPane.ERROR_MESSAGE);
    }
    public static void printFloat(float a){
        showMessageDialog(null,a);
    }
    public static void printChar(char a){
        showMessageDialog(null,a);
    }
    public static String in(String m){
        return showInputDialog("Write");
    }
}