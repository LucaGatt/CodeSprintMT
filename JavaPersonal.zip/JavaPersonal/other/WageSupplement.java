import java.util.Scanner;

class WageSupplement{
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        
        print("Enter 4 monthly payments: ");
        float payments = in.nextFloat()+in.nextFloat()+in.nextFloat()+in.nextFloat();
        //print("Enter weeks: ");
        double ni = (31.29*17 -payments/9);
        float niF = (float) ni;
        print("NI to be paid: "+ni+"\n"+niF);
    }
    private static void print(String a){
        System.out.print(a);
    }
}