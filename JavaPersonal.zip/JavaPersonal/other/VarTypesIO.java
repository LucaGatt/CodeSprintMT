import java.io.PrintStream;
import java.io.InputStream;

class VarTypesIO{
    
    public static void main(){
        PrintStream out= System.out;
        out.println("");
        InputStream in= System.in;
    }
}