 
import java.util.Scanner;

class bolol{
    public static void main(String args[]){
        Scanner in = new Scanner (System.in);
        print("Enter number of weeks:");
        double rate = 31.03;
        double grossBolol = rate*in.nextInt();
        
        double reduction = wageSupplement();
    }
    static double wageSupplement(){
        int ans=0;
        return ans;
    }
    static void print(String a){
        System.out.println(a);
    }
}