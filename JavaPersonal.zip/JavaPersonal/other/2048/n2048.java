import java.util.Scanner;

public class n2048{
    static byte rows=8,cols=8;
    static int[][] grid = new int[rows][cols];
    public static void main(String[] args) {
    	System.out.print("\f"); //clear output
	
    	
    	//input rows,cols
    	Scanner in= new Scanner(System.in);
    	System.out.println("Enter rows");
	rows=in.nextByte();
    	System.out.println("Enter cols");
	cols=in.nextByte();
        
    	
    	int[][] tmp = new int[rows][cols];
        //generate(grid);
        System.out.print("Input pass no. : ");
        int pass=in.nextInt();
        boolean cont;// used for game loop
        do{
            cont=false;
	    System.out.println("Pass "+pass+" :");
            //tmp=grid;
            for (byte i=0;i<rows;i++){
                for (byte j=0;j<cols;j++){
                    tmp[i][j]=grid[i][j];
                }
            }
            
            //algorithm
            grid= leftShift(grid);
            grid= downShift(grid);
            grid= rightShift(grid);
            grid= downShift(grid);
            //out: if (grid==tmp) grid= upShift(grid);
            //rows 3-8: grid == tmp
            boolean gettingStuck=true;
            for (byte i=2-1;i<rows;i++){
                for (byte j=0;j<cols;j++){
                    if (grid[i][j]!=tmp[i][j]) gettingStuck=false;
                }
            }
            if (gettingStuck){
                //for (byte i=0;i<2;i++){//do twice
                    grid= upShift(grid);
                    grid= leftShift(grid);
                    grid= downShift(grid);
                    grid= rightShift(grid);
                //}
            }
            
            printGrid();//output
            
            /*
            for (byte i=0;i<l;i++){
                for (byte j=0;j<w;j++){
                    System.out.print(tmp[i][j]+"\t");
                }
                System.out.println();
            }
            System.out.println("\n\n\n");
            */
            try{Thread.sleep(10);}catch(Exception e){
                System.out.println("Sleep Error");}
            pass++;
            
            //grid!=tmp; check if continue looping
            for (byte i=0;i<rows-1;i++){
                for (byte j=0;j<cols-1;j++){
                    if (grid[i][j]!=tmp[i][j]) cont=true;
                }
            }
        }while(cont); // cont=continue game
    	
    	
    	printResults(pass);
    }
    
    public static void printGrid(){
        for (byte i=0;i<rows;i++){
                for (byte j=0;j<cols;j++){
                    System.out.print(grid[i][j]+"\t");
                }
                System.out.println();
            }
            System.out.println("\n\n");
    }
    
    public static void printResults(int pass){
        //find big value
    	int a=0;
    	for (byte i=0; i<rows; i++){
    	    for (byte j=0; j<cols; j++){
    	        if (grid[i][j]>a) a=grid[i][j];
    	    }
    	}
    	//conversion to base 2
    	short x= (short)(Math.log(a)/Math.log(2));// ln()
    	System.out.println(a+"= 2^"+x+ "Passes= "+pass);
    }
    
    
    public static void generate(int[][] grid){
        int lPos,wPos;
	byte c=0;
    	do{
            byte min=1-1,max=(byte)(rows-1); //max: rows
            lPos= (int)(Math.random()*(max-min+1)+min);
	    max=(byte)(cols-1); //max: cols
            wPos= (int)(Math.random()*(max-min+1)+min);
	    
	    c++; //counter till 100 to catch loop error
	    
            //check empty
    	}while((grid[lPos][wPos]!=0)&&(c<100));
    	if (c!=100) grid[lPos][wPos]=2;
    }
    
    public static int[][] leftShift(int[][] grid){
        for(int i=1-1;i<=rows-1;i++){ //row
            for (int j=2-1;j<=cols-1;j++){ //col
                if (grid[i][j-1]==0){
                    grid[i][j-1]=grid[i][j];
                    grid[i][j]=0;
                }
                if (grid[i][j-1]==grid[i][j]){
                    grid[i][j-1]=grid[i][j]*2;
                    grid[i][j]=0;
                }
            }
        }
        generate(grid);
        return grid;
    }
    
    public static int[][] rightShift(int[][] grid){
        for(int i=1-1;i<=rows-1;i++){ //row
            for (int j=cols-1-1;j>=1-1;j--){ //col
                if (grid[i][j+1]==0){
                    grid[i][j+1]=grid[i][j];
                    grid[i][j]=0;
                }
                if (grid[i][j+1]==grid[i][j]){
                    grid[i][j+1]=grid[i][j]*2;
                    grid[i][j]=0;
                }
            }
        }
        generate(grid);
        return grid;
    }
    
    public static int[][] downShift(int[][] grid){
        for(int j=1-1;j<=cols-1;j++){ //col
            for (int i=rows-1-1;i>=1-1;i--){ //row
                if (grid[i+1][j]==0){
                    grid[i+1][j]=grid[i][j];
                    grid[i][j]=0;
                }
                if (grid[i+1][j]==grid[i][j]){
                    grid[i+1][j]=grid[i][j]*2;
                    grid[i][j]=0;
                }
            }
        }
        generate(grid);
        return grid;
    }
    
    public static int[][] upShift(int[][] grid){
        for(int j=1-1;j<=cols-1;j++){ //col
            for (int i=2-1;i<=rows-1;i++){ //row
                if (grid[i-1][j]==0){
                    grid[i-1][j]=grid[i][j];
                    grid[i][j]=0;
                }
                if (grid[i-1][j]==grid[i][j]){
                    grid[i-1][j]=grid[i][j]*2;
                    grid[i][j]=0;
                }
            }
        }
        generate(grid);
        return grid;
    }
}