class QuickSort_Failed{ //asc
    static int a[] = {3,2,4,7,5};

    static void partition(int pivotInd, int i,int j){
        if (pivotInd!=i || pivotInd!=j){// base case
            int pivot= a[pivotInd], left, right;
            int iConst = i, jConst = j;
            int tmp; //used for swaps
            while(i<j){
                left =a[i]; right=a[j]; // update of numbers since index update
                
                if (pivot<left) i++;
                else if (pivot>right) j--;
                else{ //swap a[i] and a[j]
                    tmp = a[i];
                    a[i] = a[j];
                    a[j] = tmp;
                }
                printList(); //debugging
            }
            tmp=a[0];
            a[0]=a[i];
            a[i] =tmp; //swap pivot (a[0]) and a[i], so that a[i]= pivot
            
            try{
            Thread.sleep(10);}catch(Exception e){}
            
            partition(iConst,iConst+1,pivotInd-1); // left part
            partition(pivotInd+1,pivotInd+2,jConst-1); // right part
        }
    }

    private static void printList(){
        for (int k=0; k<a.length; k++)
            System.out.print(a[k]);
        System.out.println();
    }
    
    static void sort(){
        int pivotInd = 0, // pivot index
        i=1,j=a.length-1; //indices of left,right pointers
        partition(pivotInd,i,j);
        printList();
    }
}