import java.io.PrintStream;
import java.io.FileNotFoundException;

class d{
    public static void a(){
        try{
            PrintStream out= new PrintStream("3"); 
        }catch(FileNotFoundException fnfe){

        }
    }

}