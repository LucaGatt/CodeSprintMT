import java.util.Scanner;
import java.io.File;
class ReadAddr{
 public static void main(String args[]){
     File file = new File("filedir.txt");
    
     try{
        Scanner in = new Scanner(file);
        in.useDelimiter("\\");
        String a = in.next();
    }catch (Exception e){System.out.print("Error");}
    
 }
}