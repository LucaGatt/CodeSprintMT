class Parse_WrongProgram{
    static String a;
    static int c;
    static float d;
    static double k;
    static short l;
    public static void main(){
        a= GUI.in("Write");
    }
    public static void p(){
        //char[] b = a.toCharArray();
        try{
            Byte.parseByte(a);
        }catch(Exception e){
            try{
                Short.parseShort(a);
            } catch(Exception f){
                try{
                    Integer.parseInt(a);
                }catch(Exception h){goFloat();}
            }
        }
    }
    private static void goFloat(){ //continues parse
        try{
            Float.parseFloat(a);
        } catch(Exception o){
            try{Double.parseDouble(a);}catch(Exception b){
                Boolean.parseBoolean(a);
            }
        }
    }
}