import javax.swing.JTree;
class tree{
    static void main(){
        JTree tree = new JTree();
        
    }
}