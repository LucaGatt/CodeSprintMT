class DepRunBal{
    static float cost,accDep;
    static byte percent, yrs;
    
    public static void cal(){
        float nbv= cost-accDep;
        float ans = percent/100 * nbv;
        GUI.printFloat(ans);
    }
    public static void repeat(){
        for(int i=0; i<yrs;i++){
            cal();
        }
    }
    static void main(){
        cost = Float.parseFloat(GUI.in("Cost"));
        accDep = Float.parseFloat(GUI.in("Acc Dep"));
        percent = Byte.parseByte(GUI.in("Percent"));
        yrs = Byte.parseByte(GUI.in("Yrs"));
        repeat();
    }
}