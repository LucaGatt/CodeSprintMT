function checkPass() {
    var u = document.getElementById("user").innerHTML;
    var p = document.getElementById("pass").innerHTML;
    var users = 100;
    
    for (var i = 0; i<users; i++){
        if(user[i] == u){
            if(pass[i] == p){
                document.write(Login.html) //"Access granted"
            }
        }
        if(i == users-1){
            document.getElementById("access").innerHTML = "Invalid. Try again.";
        }
    }
}