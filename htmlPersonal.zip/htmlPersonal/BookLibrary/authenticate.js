function authenticate() {
    var userInput, passInput;
    
    do {
        
        userInput = document.getElementById("2").innerHTML;
        passInput = document.getElementById("4").innerHTML;
        
    } while ((userInput !== "user") || (passInput !== "pass"));
    
    if ((userInput === "user") && (passInput === "pass")) {
        document.write("Correct");
    }

}