class c{
    static void main(){
        System.out.println((byte)('a'));
    }
}