import java.util.Scanner;
import java.util.ArrayList;

class RunningApp{
    static Scanner in = new Scanner(System.in);
    static ArrayList<String> x=new ArrayList<String>();
    
    static byte length = 6;
    static byte wordsNo = 4;
    static String words[] = new String [wordsNo];
    static boolean wordsFound[] = new boolean [length];
    static char board[][] = new char [length][length];
    
    static byte row,col;
    
    public static void main(String args[]){
        System.out.println("\f");
        listOfWords();
        boolean notFound=true;
        while(notFound){
            enterCoordinates();
            if (wordFound()){}
            for(byte i=0;i<words.length;i++){
                if (!wordsFound[i]) notFound=true;
            }
        }
        
    }
    public static void listOfWords(){
        words[0] = "apple";
        words[1] = "banana";
        words[2] = "sea";
        words[3] = "orange";//6 letters
    }
    public static void genRandomLetters(){
        short letter = M.random(97,97+26);
    }
    public static void enterCoordinates(){
        //Scanner sc = new Scanner(System.in);
        //sc.useDelimiter(",");
        boolean invalid= true;
        while(invalid){
            System.out.println("Enter coordinates or E[x]it:");
            String coordinates = in.next(); // l,w
            if(coordinates=="x"){
                System.out.println("Existing...");
                System.exit(0);
            }
            
            String a[]= coordinates.split(",");
            //M.checkNum(1,length, l,w);
            //byte l,w;
            for (byte j=0; j<a.length; j++){//a[]
                //for (byte i=1; i<=length; i++){//checkNum
                if (((a[j]=="0")||(a[j]==" 0"))&&(j==0)) start=0;
                else if (((a[j]=="1")||(a[j]==" 1"))&&(j==0)) start=1;
                else if (((a[j]=="2")||(a[j]==" 2"))&&(j==0)) start=2;
                else if (((a[j]=="3")||(a[j]==" 3"))&&(j==0)) start=3;
                else if (((a[j]=="4")||(a[j]==" 4"))&&(j==0)) start=4;
                else if (((a[j]=="5")||(a[j]==" 5"))&&(j==0)) start=5;
                else invalid = true;
                /*
                if (((a[j]=="6")||(a[j]==" 6"))&&(j==0)) l=6;
                if (((a[j]=="7")||(a[j]==" 7"))&&(j==0)) l=7;
                if (((a[j]=="8")||(a[j]==" 8"))&&(j==0)) l=8;
                if (((a[j]=="9")||(a[j]==" 9"))&&(j==0)) l=9;
                */
                
                if (((a[j]=="0")||(a[j]==" 0"))&&(j==1)) end=0;
                else if (((a[j]=="1")||(a[j]==" 1"))&&(j==1)) end=1;
                else if (((a[j]=="2")||(a[j]==" 2"))&&(j==1)) end=2;
                else if (((a[j]=="3")||(a[j]==" 3"))&&(j==1)) end=3;
                else if (((a[j]=="4")||(a[j]==" 4"))&&(j==1)) end=4;
                else if (((a[j]=="5")||(a[j]==" 5"))&&(j==1)) end=5;
                else if (!invalid) invalid = true;
                else invalid= false;
                
                if (invalid)
                    System.out.println(
                        "Input must be from 0-"+(length-1)+". Try again.");
            }
        }
    }
}