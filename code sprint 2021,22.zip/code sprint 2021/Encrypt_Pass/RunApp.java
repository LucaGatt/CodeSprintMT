//https://www.onlinegdb.com/online_java_compiler
//This is the website that got non-responsive after approx. 1hr of code

import java.util.Scanner;
import java.util.ArrayList;

public class RunApp{
    static byte pack = 3;
    
    static String name;
    static String password;
    
    //lower97
    static char[] lowerLetters = new char [26];
    static char[] upperLetters = new char [26];
    static char[] numbers = new char [10];
    static char[] specChars = {'!','@','#','$','%','&','*'};
    
    static Scanner in = new Scanner(System.in);
    static Credentials[] credential = new Credentials[pack];
    static ArrayList<Credentials> x=new ArrayList<Credentials>();
    public static void main(String args[]){
        //array init
        for (byte i=0; i<credential.length; i++){
            credential[i] = new Credentials();
        }
        
        //lowerLetters
        for (byte i=0,j=97; i<=26; i++,j++){
            lowerLetters[i] = (char)(j);
        }
        //upperLetters
        for (byte i=0,j=65; i<=26; i++,j++){
            upperLetters[i] = (char)(j);
        }
        //numbers
        for (byte i=0,j=48; i<=26; i++,j++){
            upperLetters[i] = (char)(j);
        }
        
    }
    
    public static void menu(){
        byte option= M.validateByte();
        boolean invalid = true;
        while(invalid){
            invalid= false;
            switch(option){
                case 1: login();
                    break;
                case 2: register();
                    break;
                case 3: System.exit(0);
                    break;
                default:
                    System.out.println("Wrong option. Input from 1-3.");
                    invalid= true;
                    break;
            }
        }
    }
    
    public static void login(){
        System.out.println("Enter name:");
        name = in.next();
        
        
        System.out.println("Enter password:");
        password = in.next();
        
    }
    public static void register(){
        boolean invalid = true;
        while(invalid){
            invalid = false;
            System.out.println("Enter name:");
            name = in.next();
            char[] a= name.toCharArray();
            if (a.length>4){
                invalid= true;
                System.out.println("input must be 4 characters long");
            }
            if(!checkUnique()){
                invalid= true;
                System.out.println("name is not unique");
            }
            for (byte i=0; i<a.length; i++){
                //if(a[i].isEqual(' ')) invalid= true;
                if (invalid)System.out.println("name is not unique");
            }
        }
        
        System.out.println("Enter password:");
        password = in.next();
        try{
            Encrypt.getEncKey(password);
        }catch (Exception e){System.out.println("Error");}
    }
    public static boolean checkUnique(){
        boolean unique =true;
        //code
        return unique;
    }
}