class n{
    static void m(){
        System.out.println((short)('0'));
    }
}