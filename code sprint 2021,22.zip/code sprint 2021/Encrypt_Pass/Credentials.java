class Credentials{
    String name;
    String password;
    
    public Credentials(){
    }
}