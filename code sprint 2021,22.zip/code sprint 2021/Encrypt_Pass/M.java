
import java.util.Scanner;
public class M{
    static Scanner in = new Scanner (System.in);
    public static byte validateByte(){
        byte num=0;
        boolean loop = false;
        do{
            loop = false;
            try {
                num= in.nextByte();
            } catch(Exception e) {
                System.out.println("Invalid. Try again!");
                loop = true;
            }
        }while(loop);
        return num;
    }
}