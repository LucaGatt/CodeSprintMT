import java.util.Scanner;
import javax.swing.JOptionPane;

class A{
    static void a(){
        Scanner in = new Scanner(System.in);
        System.out.print(in.nextLine());//'Enter' works with nextLine()
    }
    
    static void GUIprintError(String message, String title, String messageType){
        JOptionPane.showMessageDialog(null, "You have an error.","Input Error",JOptionPane.ERROR_MESSAGE);
    }
    static void GUIprintError(String message, String title){
        //JOptionPane.showMessageDialog(null, "You have an error.","Input Error", JOptionPane.WARNING_MESSAGE);
    }
    static void GUIprintError(String message){
        JOptionPane.showMessageDialog(null, "You have an error.");
    }
}