import java.util.ArrayList;

//uses Substitution Cipher algorithm
public class PasswordEncryption
{
    static ArrayList<Character> charSet = new ArrayList(); // array of characters
    static ArrayList<Character> encSet = new ArrayList(); // encrypted set of characters
    
    /*
    public PasswordEncryption()
    {
        // initialise instance variables
        
    }*/
    //since methods are all static
    
    protected static void init(){// initialise charSet
        for(byte i=0;i<26;i++){
            charSet.add((char)(97+i));
        }
        for(byte i=0;i<26;i++){
            charSet.add((char)(65+i));
        }
        for(byte i=0;i<10;i++){
            charSet.add((char)(48+i)); //logical error - numbers
        }
    }
    
    protected static String encrypt(String password,char[] key){ // returns encrypted password
        //String encryptedPass = null;
        for (byte i=0; i<8; i++){
            encSet.add(key[i]); // first characters are those of the key
        }
        for (byte i=8; i<26*2+10+7; i++){ // continue encSet
            boolean unique = true;
            for (byte j=0; j<8 && unique; j++){ // check for characters that make part of key
                if( encSet.get(j).equals(charSet.get(i)) )
                    unique = false;
            }
            if (unique) encSet.add(charSet.get(i));
        }
        // characters are assigned to encSet
        
        // get encrypted characters
        char[] passChar = password.toCharArray();
        char[] encCharPass = new char[passChar.length];
        for (byte i=0; i<passChar.length; i++){
            encCharPass[i] = passChar[i];
        }
        return String.valueOf(passChar);
         //encryptedPass;
    }
}
