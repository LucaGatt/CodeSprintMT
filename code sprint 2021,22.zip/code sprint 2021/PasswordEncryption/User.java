import java.util.ArrayList;
import java.util.Scanner;

class User{
    String username;
    String password; // encrypted password
    char[] encryptionKey = new char [8];
    // variables containing user login info

    static Scanner in = new Scanner(System.in); // initialising objects from external packages
    protected User(){
        do{
            System.out.print(">> Username: ");
            this.username = in.nextLine(); // input username
        }while(!validateUsername()); // loop until username is valid
        do{
            System.out.print(">> Password: ");//asks user to input his login info
            this.password = in.next(); // initialising instance variables
        }while(!validatePassword()); // loop until password is valid
        genEncryptionKey(); // generate and store encryption key
        PasswordEncryption.encrypt(password,encryptionKey);
        
        //output details stored
        System.out.println("\n\nDetails saved on server:\n>> Username:\t"+username+"Encryption Key:\t"+encryptionKey+"\n>> Encrypted Password:\t"+password);
        
        System.out.println("..press Enter to continue");
        in.nextLine();
    }

    protected User(String username, String password){//unused
        this.username = username;
        genEncryptionKey(); // generate and store encryption key
        this.password = PasswordEncryption.encrypt(password, encryptionKey); // assigning to and initialising instance variables
    }
    
    protected static void preregister(){
        Options.users.add(new User("johnBorg","Joe!King"));
        Options.users.add(new User("mariaCalleja","*callejaMarie*3"));
    }
    
    private boolean validateUsername(){
        boolean valid = true; // intialised .. if invalid in any condition, it turns to false
        ArrayList<User> users = Options.users;

        if (username.length()<4) valid = false; // check length is greater than 4 characters
        if(username.contains(" ")) valid = false;
        for(int i=0;i<users.size() && valid;i++){ // looping efficiency in halting when username is invalid
            if(users.get(i).username.equals(username)) valid = false;
        }// check that username is unique
        return valid;
    }

    private boolean validatePassword(){
        boolean valid= true;

        boolean validLower = false;
        boolean validUpper = false;
        boolean validNum = false;
        boolean validSpecial = false;

        char[] passwordChar = this.password.toCharArray();
        if(password.length()<8) valid = false;
        for (byte j=0; j<password.length() && valid; j++){
            for(byte i=0; i<26 && validUpper; i++){ // halt when uppercase letter found to prevent redundant looping
                if (65+i==(byte)(passwordChar[j])) validUpper = true;
            }
            for(byte i=0; i<26 && validLower && validUpper; i++){ // halt when lowercase letter found and if character is uppercase letter to prevent redundant looping
                if (97+i==(byte)(passwordChar[j])) validLower = true;
            }
            for(byte i=0; i<10 && validNum && validLower && validUpper; i++){ // halt - same procedure as above
                if (48+i==(byte)(passwordChar[j])) validNum = true;
            }
            if (passwordChar[j]=='!' ||
                passwordChar[j]=='@' ||
                passwordChar[j]=='#' ||
                passwordChar[j]=='$' ||
                passwordChar[j]=='%' ||
                passwordChar[j]=='&' ||
                passwordChar[j]=='*'
            ) validSpecial = true;
            
            if(!validLower||!validUpper||!validNum||!validSpecial) valid = false;
        }
        return valid;
    }

    private void genEncryptionKey(){ // generate random encryption key
        this.encryptionKey[0]=genLowLetter();
        this.encryptionKey[1]=genNum();
        this.encryptionKey[2]=genUpLetter();
        this.encryptionKey[3]=genSpecialChar();
        this.encryptionKey[4]=genLowLetter();
        this.encryptionKey[5]=genNum();
        this.encryptionKey[6]=genUpLetter();
        this.encryptionKey[7]=genSpecialChar();
    }
    private char genLowLetter(){
        //char tmp =
        return (char)genRandomNum( (byte)97, (byte)(97+25) );
        //return String.valueOf(tmp);
    }
    private char genNum(){
        return (char)genRandomNum( (byte)48, (byte)57 );
        //String.valueOf(num/char) to get String of parameter
    }
    private char genUpLetter(){
        return (char)genRandomNum( (byte)65, (byte)(65+25) );
    }
    private char genSpecialChar(){
        final char specialChar[] = {'!', '@', '#', '$', '%', '&', '*'};
        byte index = genRandomNum( (byte)0, (byte)(specialChar.length) );
        return specialChar[index];
    }
    private byte genRandomNum(byte min, byte max){
        return (byte) (Math.random()*(max-min+1) +min);
    }
    
    //Start GetterSetterExtension Source Code
    /**SET Method Propertie username*/
    public void setUsername(String username){
        this.username = username;
    }//end method setUsername

    //End GetterSetterExtension Source Code

    //Start GetterSetterExtension Source Code
    /**SET Method Propertie password*/
    public void setPassword(String password){
        this.password = password;
    }//end method setPassword

    //End GetterSetterExtension Source Code

    //Start GetterSetterExtension Source Code
    /**GET Method Propertie username*/
    public String getUsername(){
        return this.username;
    }//end method getUsername

    //End GetterSetterExtension Source Code

    //Start GetterSetterExtension Source Code
    /**GET Method Propertie password*/
    public String getPassword(){
        return this.password;
    }//end method getPassword

    //End GetterSetterExtension Source Code

    public String toString(){
        return "Username: "+username+"\tPassword (encrypted): "+password; 
    }
}//End class