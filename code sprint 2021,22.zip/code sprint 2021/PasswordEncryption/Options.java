import java.util.Scanner;
import java.util.ArrayList;

class Options{
    protected static ArrayList<User> users = new ArrayList(); // array containing login info of each user

    public static void login(){
        //ask login details
        Scanner in = new Scanner(System.in);

        //entering and accepting username
        boolean found=false; // found= username found
        int usernameIndex=-1;
        do{
            System.out.print(">> Username: ");
            String username = in.next(); // input username

            for (int i=0; i< users.size() && !found; i++){ // stop iterations when username is found
                if (username.equals(users.get(i).username)){
                    usernameIndex = i;
                    found = true;
                }
            }
        }while(!found);

        //entering and accepting password
        boolean correct = true; // flag shows that correct as default .. if not, it is changed to false
        do{
            System.out.print(">> Password: ");
            String pass = in.next(); // input password
            if((PasswordEncryption.encrypt(pass,users.get(usernameIndex).encryptionKey))
            .equals(users.get(usernameIndex).password))
            {
                //success
            }else{
                System.out.println("Login failed. Try again.");
                correct = false; // flag changed to false
            }
        }while(!correct);
        
        //success print
        System.out.println(
            "------------------------------"+
            "|   Logged In Successfully   |"+
            "------------------------------");
        
        System.out.println("...press Enter to continue"); // pause before continue with key press
        in.nextLine(); // lets user press key .. no need to be stored
    }

    public static void register(){
        System.out.println("********** REGISTER ACCOUNT **********");
        users.add(new User()); // adds User object
        System.out.println(
            "---------------------------------------"+
            "|   Account registered successfully   |"+
            "---------------------------------------");
    }

    /* test
    public static void printAllDetails(){
    //test
    User user = new User();
    for (int i=0; i<5;i++){

    register();
    }
    //test

    //for (int i=0; i< users.size();i++){
    System.out.println(users.toString());
    //}
    } test */
}