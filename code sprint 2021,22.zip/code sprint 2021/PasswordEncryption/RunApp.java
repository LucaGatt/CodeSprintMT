import java.util.Scanner;
import java.util.InputMismatchException;
import javax.swing.JOptionPane;

class RunApp{
    static Scanner in = new Scanner(System.in);
    
    public static void main(String args[]){
        //initialisation
        PasswordEncryption.init();
        User.preregister();
        do{
            menu();
        }while(true);
    }

    private static void menu(){
        //JOptionPane menuGUI = new JOptionPane();
        JOptionPane.showMessageDialog(null,"Choose option from the following:"+
            "\n1. Login"+
            "\n2. Register"+
            "\n3. Exit");
        byte option=0;
        boolean error=false; // signifies error which makes "choosing option" event happen again
        do{
            try{
                option = in.nextByte();
            }catch (InputMismatchException ime){
                System.out.println("Only numbers are allowed. Try again.");
                error = true;
                in.next();// in order to clear buffer
            }
            switch(option){
                case 1: Options.login(); break;
                case 2: Options.register(); break;
                case 3: System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default: System.out.println("Option number must be 1-3");
                    error = true;
            }
        }while(error);
    }
}