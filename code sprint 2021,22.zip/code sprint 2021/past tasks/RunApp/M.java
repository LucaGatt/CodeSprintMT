public class M{
    Scanner in = new Scanner (System.in);
    public static byte validateByte(){
        boolean loop = false;
        do{
            loop = false;
            try {
                return in.nextByte();
            } catch(Exception e) {
                System.out.println("Invalid. Try again!");
                loop = true;
            }
        }while(loop);
    }
}