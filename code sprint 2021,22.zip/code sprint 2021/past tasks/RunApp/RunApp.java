import java.util.Scanner;

public class RunApp
{
    Scanner in = new Scanner (System.in);
    
    String[][] players = new String [100][2];//[players][name,prize]
    byte boxesNo=22;//numbered
	short[] prizes = {
	    1,5,10,20,30,40,50,75,100,200,500,750,1000,2500,5000,7500,
	    10000,15000,20000,25000,37500,50000
	};//ordered
    short[][] contents = new short [boxesNo][2];//randomised prizes [boxNo,prize]
    byte indexCurrentPlayer;
    byte boxChosen;//menu 2)
    short prizeWon;
    
	public static void main(String[] args) {
		
		
	
		//random{
		
		byte[] indicesChosen = new byte [boxesNo];
		boolean indexAlreadyChosen = false; //init
		for (byte i=0;i<boxesNo;i++){
		    do{
    		    indexAlreadyChosen=false;
    		    byte min=1-1, max=(boxesNo-1);
    		    byte index= (byte)(Math.random()*(max-min+1)+min);
    		    
    		    
    		    for (byte j=0;j<boxesNo;j++){
    		        if (index==indicesChosen[j]) indexAlreadyChosen=true;
    		    }
		    }while (indexAlreadyChosen);
		}
		
		//put index in array
		byte i=0;
		for (i=0; ((i<boxesNo)||(indicesChosen[i]!=0)); i++){}
		indicesChosen[i] = index;
		
		//put prize in 'contents'
		byte j=0;
		for (j=0; ((j<boxesNo)||(contents[j][1]!=0)); j++){}
		contents[j][1] = prize[index];
		
		//random}
		
		
		menu();
		
	}
	
	public static void playerName(){
	    //player name{
		System.out.println("Enter player name:");
		String playerName = in.next();
	    
	    byte i=0;
	    for (i=0;((i<players.length) || (!nullFound));i++){
	        if (players[i]==null) nullFound=true;
	    }
	    indexCurrentPlayer = i-1;
	    players[indexCurrentPlayer][0]= playerName; //insert name in array
	    //}
	    
	    menu();
	}
	
	public static void storeprizeWon(){
	    players[indexCurrentPlayer][1] = prizeWon;
	    
	    menu();
	}
	
	public static void hallOfFame(){
	    System.out.println("HALL OF FAME");
	    System.out.println("Player Name\tPrizeWon");
	    for (short i=0; i<players.length(); i++){
	        System.out.println(players[i][0]+"\t"+players[i][1]);
	    }
	}
	
	public static void menu() {
	    
	    //menu
	    boolean again = false;
	    byte option;
	    do{
    	    again = false;
    	    try{
        	    System.out.println("Enter option:");
        	    System.out.println(
        	        "1) View Hall of Fame, 2) Start Game, 3) Quit Game."
	            );
        	    option = in.nextByte();
        	    
        	    //check option
    	        if ((option<1)||(option>3)) again = true;
    	    catch(Exception e){
    	        System.out.println("Error. Try again!\n");
    	        again =true;
    	    }
    	    
    	    
    	}while(again);
    	//option =valid
    	//menu
    	switch(option){
    	    case 1: hallOfFame();
    	        break;
    	        
    	    case 2: playerName();
    	            boolean invalid = false;
    	            do{
    	                invalid = false;
        	            System.out.println("Choose box from 1 to 22: ");
        	            boxChosen = M.validateByte();
        	            if ((boxChosen<1)&&(boxChosen>22)){
        	                again = true;
        	                System.out.println("Choose from 1 to 22");
        	            }
    	            }while(invalid);
    	            
    	            round1();
    	            
    	            menu();
    	        break;
    	        
    	    case 3: System.exit(0);
    	        break;
    	        
    	}
	}
	
	public static void availableBoxesPrizes(){
	    //show available boxes and prices
	    System.out.println("Available boxes:");
	    for (byte i=0; ((i<boxesNo)&&(i!=boxChosen-1)); i++){
	        if (contents[i][1] != 0) //if box is not eliminated
	            System.out.print(i+1+ " ");
	    }
	    System.out.println("\nPrizes available:");
	    for (byte i=0; i<boxesNo; i++){
	        System.out.println("€"+prizes[i] + " ");
	    }
	}
	
	public static byte averageBox(){
	    byte remBoxes=0; //remaining
	    for (byte i=0; i<boxesNo; i++){
	        if (contents[i][1] != 0) remBoxes++;
	    }
	    short remPrizes[] = new short [remBoxes];
	    byte j=0;
	    for (byte i=0; i<boxesNo; i++){//contents[][1]
	        if (contents[i][1]!=0){
	            remPrizes[j]=contents[i][1];
	            j++;
	        }
	    }//remPrizes}
	    
	    //calc averageBox
	    short total=0;
	    for (byte i=0; i<remBoxes; i++){
	        total+=remPrizes[i];
	    }
	    return (byte)(total/remBoxes);
	}
	public static void chooseBoxes(byte noBoxesChosen){
	    availableBoxesPrizes();
	    System.out.println("Choose "+noBoxesChosen+" boxes:");
	    byte boxesChosen[] = new byte [noBoxesChosen]; 
	    for (byte i=0; i<noBoxesChosen; i++){
	        boxesChosen[i] = in.nextByte();
	    }//8 boxesChosen stored
	    
	    System.out.println("Prizes of the "+noBoxesChosen+" boxes chosen:");
	    for (byte i=0; i<noBoxesChosen; i++){
	        System.out.print("Box "+boxesChosen[i]+": €"+contents[boxesChosen[i]-1][1]+" ");
	        contents[boxesChosen[i]-1][1]=0;
	    }
	}
	public static void dealOrNoDeal(byte nxtRound){
	    //deal or no deal
        byte averageBox = averageBox();
        System.out.println("Box "+averageBox+ "\tDeal or No Deal? (Y/N)");
        char deal = in.nextChar();
        if ((deal =='y')||(deal =='Y')){
            System.out.println(
                "Your box: "+averageBox + "\tPrize: €"+contents[averageBox-1][1]
            );
            prizeWon=contents[boxChosen-1][1];
            System.out.println(
                "Your previous box: "+boxChosen+ "\tAmount Won: €"+prizeWon
            );
            
        } else if ((deal =='n')||(deal =='N')){
            switch (nxtRound){
                case 2: round2();
                    break;
                case 3: round3();
                    break;
                case 4: round4();
                    break;
                case 5: finalRound();
                    break;
                case 6: System.out.println(
                            "Box not chosen: "+boxChosen+ "\tAmount Won: €"+prizeWon
                        );
                        prizeWon=contents[boxChosen-1][1];
                        System.out.println(
                            "Your box: "+averageBox + "\tPrize: €"+contents[averageBox-1][1]
                        );
            }
            round2();
        }
	}
	public static void round1(){
	    chooseBoxes(8);
	    dealOrNoDeal(2);
	}
	public static void round2(){
	    chooseBoxes(6); //param noBoxesChosen
	    dealOrNoDeal(3); // param nxtRound
	}
	public static void round3(){
	    chooseBoxes(4); //param noBoxesChosen
	    dealOrNoDeal(4); // param nxtRound
	}
	public static void round4(){
	    chooseBoxes(2); //param noBoxesChosen
	    dealOrNoDeal(5); // param nxtRound
	}
	public static void finalRound(){
	    
	    dealOrNoDeal(6); // param nxtRound
	}
}
