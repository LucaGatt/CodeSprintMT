import java.util.ArrayList;

class Bomb{
    protected static ArrayList<Position> bombs = new ArrayList();
    protected static Position pos; // reduce parameters
    
    //generate bombs
    protected static void genBombs(){
        for (byte i=0;i<10;i++){ //generate 10 bombs
            genBomb();
        }
    }

    private static void genBomb(){
        bombs.add(genPosition());
    }

    private static Position genPosition(){
        return new Position(genRandom(),genRandom());
    }

    private static int genRandom(){ //random number 0-9
        int max=9,min=0;
        return (int)(Math.random()*max-min+1)+min;
    }
    //generate bombs

    protected static boolean detectBomb(Position pos){
        Bomb.pos = pos; // update position
        boolean bombDetected = false;
        for (byte i=0;i<bombs.size();i++){
            if(bombs.get(i).getX()==pos.getX()&&bombs.get(i).getY()==pos.getY())
                bombDetected=true;
        }
        return bombDetected;
    }

    protected static byte countBombs(){//Position pos){
        byte c=0;
        byte x=(byte)pos.getX(); byte y=(byte)pos.getY();
        //byte xCheck=(byte)(x-1); byte yCheck=(byte)(y-1);
        for (byte i=-1;i<2;i++){
            for (byte j=-1;j<2;j++){
                if(linearSearchBombs(x+i, y+j)) c++; // bomb found
            }
        }
        
        
        //if(c>8) throw new Exception(); //error in counting
        
        return c;
    }

    private static boolean linearSearchBombs(int xCheck, int yCheck){//Position pos){
        for (byte i=0;i<bombs.size();i++){
            if(bombs.get(i).getX()==xCheck&&bombs.get(i).getY()==yCheck)
                return true;
        }
        return false;
    }

    //Start GetterSetterExtension Source Code

    /**GET Method Propertie bombs*/
    public java.util.ArrayList<Position> getBombs(){
        return this.bombs;
    }//end method getBombs

    /**SET Method Propertie bombs*/
    public void setBombs(java.util.ArrayList<Position> bombs){
        this.bombs = bombs;
    }//end method setBombs

    //End GetterSetterExtension Source Code

}//End class