import java.util.ArrayList;

class ArrayList2D{
    static ArrayList<ArrayList> array = new ArrayList();
    static void addRow(){//ArrayList<ArrayList<String>> array){
        array.add(new ArrayList());
    }
    static void addElement(byte i, Object element){//, ArrayList<ArrayList> array){
        
        //ArrayList tmp = array.get(i); //call row
        array.get(i).add(element); // add element in row i (with new col)
        //array.set(i,tmp); //update row
        
    }
    static void setElement(byte i, byte j, Object element){//, ArrayList<ArrayList> array){
        //ArrayList tmp = array.get(i); //call row
        array.get(i).set(j,element);// update element in row i, col j
        //array.set(i,tmp); //update row
    }
    static Object getElement(byte i, byte j){//, ArrayList<ArrayList<String>> array){
        return (array.get(i).get(j));
    }
    
    private static void printElement(byte i, byte j){//, ArrayList<ArrayList<String>> array){
        System.out.print(getElement(i, j));//, array));
    }
}