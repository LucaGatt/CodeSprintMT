import java.util.ArrayList;

public class Grid{
    //static ArrayList<ArrayList<String>> grid = new ArrayList();
    static String[][] grid = new String[10][10]; // no instances - only blueprint of 'grid'

    static void init(){
        for (byte i=0;i<10;i++){
            for (byte j=0;j<10;j++){
                grid[i][j] = " ";
            }
        }

        Bomb.genBombs();
    }

    static void display(){
        System.out.println("\f");
        // top part
        byte spacesBegin = 5;
        for (byte i=0;i<spacesBegin;i++){
            System.out.print(" ");
        }
        for (byte i=0;i<10;i++){
            System.out.print(i+"   ");
        }
        System.out.println();
        for (byte i=0;i<spacesBegin-2;i++){
            System.out.print(" ");
        }
        for (byte i=0;i<10;i++){
            System.out.print("----");
        }
        System.out.println("-");

        // rest
        for (byte i=0;i<10;i++){
            System.out.print(i+"  | ");
            for (byte j=0;j<10;j++){
                System.out.print(grid[i][j]+" | ");
            }
            System.out.println();
        }
    }
    
    
    //Start GetterSetterExtension Source Code

    /**GET Method Propertie grid*/
    public static String[][] getGrid(){
        return grid;
    }//end method getGrid

    /**SET Method Propertie grid*/
    public static void setGrid(String[][] grid){
        Grid.grid = grid;
    }//end method setGrid

    //End GetterSetterExtension Source Code

}//End class