import java.util.Scanner;

class a{
    static void enterDetect(){
        Scanner in = new Scanner(System.in);
        //System.out.print(in.nextLine());
        if(in.nextLine().length() == 0) System.out.println("Enter detected."); 
        System.out.print("end");
    }
    static void line1Condition(){
                     //boolean? true:false
        System.out.print(false? 8   :93);
    }
}