import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.InputMismatchException;

class Options{
    static Scanner in = new Scanner (System.in);
    static String input;
    static boolean valid; // declarations and/or initialisations of variables

    protected static void askUser(){

        Position pos=new Position();
        do{
            valid=true; //reset variable
            System.out.print("\nEnter location [Row,Column] or E[x]it");
            input = in.next().toLowerCase();

            if(input.equals("x")){ //exit
                System.out.print("Exiting...");
                System.exit(0);
            }
            else if(input.contains(",")){ //accepted
                String[] a = input.split(",");
                try{
                    
                    byte x=Byte.parseByte(a[0]);
                    pos.setX(x);
                    byte y=Byte.parseByte(a[1]);
                    pos.setY(y);
                    //boolean validNum=true;
                    if(x<0||x>9||y<0||y>9){
                        valid=false;
                        System.out.println("Number entered is not 0-9. Try again.");
                    }
                    /*}catch(ArrayIndexOutOfBoundsException e){
                    throw new InputMismatchException();
                    }catch(NumberFormatException nfe){
                    throw new InputMismatchException();
                    }catch(InputMismatchException ime){
                     */
                }catch(Exception e){
                    valid=false;
                    JOptionPane.showMessageDialog(null, "Incorrect format. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }

                if(valid){ //to bypass if invalid
                    if(checkRevealed(pos)){
                        valid = false;
                        System.out.println("Location already revealed. Please choose another location.");
                    }
                }
            }else{ //error
                System.out.println("Wrong input. Try again.");
                valid= false;
            }
        }while(!valid);    

        if(checkFlagged(pos)) unflag(pos);
        else{

            do{
                valid=true; //reset variable
                System.out.print("[R]eveal or [F]lag the location: ");
                input = in.next().toLowerCase();
                if(input.equals("r")) reveal(pos);
                else if (input.equals("f")) flag(pos);
                else{
                    valid=false;
                    System.out.println("Press 'r' or 'f'. Try again.");
                }
            }while(!valid);
        }
    }

    private static boolean checkFlagged(Position pos){
        return Grid.getGrid()[pos.getX()][pos.getY()].equals("F");
    }

    private static void unflag(Position pos){

        do{
            valid=true;//reset variable
            System.out.print("Unflag?[Y/N]");
            input = in.next().toLowerCase();
            if(input.equals("y")) Grid.getGrid()[pos.getX()][pos.getY()] = " ";
            else if(input.equals("n")) ;
            else{
                valid=false;
                System.out.println("Error. Enter y or n . Try again.");
            }
        }while(!valid);
    }

    private static void flag(Position pos){
        Grid.getGrid()[pos.getX()][pos.getY()] = "F";
    }

    private static void reveal(Position pos){

        if(Bomb.detectBomb(pos)){
            RunApp.displayGameOver();
        }else{
            byte cBombs = Bomb.countBombs();
            Grid.getGrid()[pos.getX()][pos.getY()] = String.valueOf(cBombs);
        }
    }

    private static boolean checkRevealedOrFlagged(Position pos){
        /*
        boolean alreadyRevealed = false;
        if(Grid.getGrid()[pos.getX()][pos.getY()].equals("F")){
        alreadyRevealed=true;
        }else if(checkRevealed(pos)){
        alreadyRevealed=true;
        }
        return alreadyRevealed;
         */
        return Grid.getGrid()[pos.getX()][pos.getY()].equals("F")||checkRevealed(pos);
    }

    private static boolean checkRevealed(Position pos){
        //boolean alreadyRevealed=false;
        for (byte i=0;i<8;i++){
            if(Grid.getGrid()[pos.getX()][pos.getY()].equals(String.valueOf(i)))
                return true; //alreadyRevealed=true;

        }
        return false; //alreadyRevealed;
    }
}