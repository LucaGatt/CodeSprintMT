import java.util.Scanner;

public class RunApp{
    private static void init(){
        Grid.init();
    }

    public static void main(String args[]){
        init();
        do{
            Grid.display();
            Options.askUser();
        }while(true);
    }

    protected static void displayGameOver(){
        byte dashes=30;
        //row1
        for (byte i=0;i<dashes;i++){
            System.out.print("-");
        }
        System.out.println();

        //row2
        System.out.print("|");
        for (byte i=0;i<5;i++){
            System.out.print(" ");
        }
        System.out.print("G A M E");
        for (byte i=0;i<4;i++){
            System.out.print(" ");
        }
        System.out.print("O V E R");
        for (byte i=0;i<5;i++){
            System.out.print(" ");
        }
        System.out.println("|");

        //row3
        System.out.print("|");
        for (byte i=0;i<7;i++){
            System.out.print(" ");
        }
        System.out.print("YOU HIT A BOMB");
        for (byte i=0;i<7;i++){
            System.out.print(" ");
        }
        System.out.println("|");

        //row4 - last row
        for (byte i=0;i<dashes;i++){
            System.out.print("-");
        }
        
        GameOver.showBombs();// display grid with bombs
        
        //restart or exit
        System.out.println("\n\n...[R]estart or press Enter to exit");
        Scanner in = new Scanner(System.in);
        String input= in.nextLine();
        boolean valid= true;
        do{
            if(input.equals("R")||input.equals("r")) main(null);
            else if(input.length() == 0){
                System.out.println("Exiting...");
                System.exit(0);
            }else{
                valid = false;
                System.out.println("Error. Press [r] or Enter");
            }
        }while(!valid);
    }
}