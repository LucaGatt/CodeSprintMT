class Position{
    private int x,y;

    protected Position(){
        
    }
    protected Position(int x, int y){
        this.x = x;
        this.y = y;
    }


    //Start GetterSetterExtension Source Code

    /**GET Method Propertie x*/
    public int getX(){
        return this.x;
    }//end method getX

    /**SET Method Propertie x*/
    public void setX(int x){
        this.x = x;
    }//end method setX

    /**GET Method Propertie y*/
    public int getY(){
        return this.y;
    }//end method getY

    /**SET Method Propertie y*/
    public void setY(int y){
        this.y = y;
    }//end method setY

    //End GetterSetterExtension Source Code

}//End class