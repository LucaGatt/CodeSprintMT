import java.util.ArrayList;

class GameOver{ // helps with displayGameOver() method in RunApp
    protected static ArrayList<Position> bombs = Bomb.bombs;
    protected static Position pos; // reduce parameters
    
    protected static void showBombs(){
        //if bomb was flagged, #
        //
        for (byte i=0; i<bombs.size();i++){
            int x= bombs.get(i).getX();
            int y= bombs.get(i).getY();
            /*
            if(Grid.getGrid()[x][y].equals("F")){
                Grid.getGrid()[x][y] = "#";
            }else{
                Grid.getGrid()[x][y] = "B";
            }*/
            Grid.getGrid()[x][y] = (Grid.getGrid()[x][y].equals("F"))? "#" : "B";
        }
        Grid.display(); // display bombs and correct flags
        
        flushArrayList(); //continue to next method
    }
    protected static void flushArrayList(){
        Bomb.bombs = new ArrayList();
    }
}