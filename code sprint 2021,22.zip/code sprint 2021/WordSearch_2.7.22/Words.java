import java.util.ArrayList;

class Words{
    private static final String[] words = {"algorithm","turing","memory","java","code"};
    private static ArrayList<String> wordsNotFound = new ArrayList();
    private static Location[] wordLocations = new Location[5];
    
    public static void init(){
        for (byte i=0;i<words.length;i++){
            wordsNotFound.add(words[i]);
        }
    }
//Start GetterSetterExtension Source Code

    /**GET Method Propertie words*/
    public static String[] getWords(){
        return Words.words;
    }//end method getWords

    /**GET Method Propertie wordLocations*/
    public static Location[] getWordLocations(){
        return Words.wordLocations;
    }//end method getWordLocations

    /**SET Method Propertie wordLocations*/
    public void setWordLocations(Location[] wordLocations){
        this.wordLocations = wordLocations;
    }//end method setWordLocations

//End GetterSetterExtension Source Code



//Start GetterSetterExtension Source Code

    /**GET Method Propertie wordsNotFound*/
    public static java.util.ArrayList<java.lang.String> getWordsNotFound(){
        return Words.wordsNotFound;
    }//end method getWordsNotFound

    /**SET Method Propertie wordsNotFound*/
    public static void setWordsNotFound(java.util.ArrayList<java.lang.String> wordsNotFound){
        Words.wordsNotFound = wordsNotFound;
    }//end method setWordsNotFound

//End GetterSetterExtension Source Code


}//End class