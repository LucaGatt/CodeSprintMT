 
import java.util.Scanner;

public class IO extends GUI{
    //simple
    //input
    static Scanner in = new Scanner(System.in);
    
    //output
    static void print(String a){
        System.out.print(a);
    }
    static void println(String a){
        System.out.println(a);
    }
    //simple
}