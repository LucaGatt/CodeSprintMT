class Grid{
    private static byte rows=18,cols=24;
    protected static char[][] grid = new char[rows][cols]; //letter
    

    protected static void init(){
        for (byte i=0;i<Words.getWords().length;i++){
            Words.getWordLocations()[i] = Location.genRanLocation(i);
            Location tmp = Words.getWordLocations()[i];
            byte startRow = tmp.getStartRow();
            byte startCol = tmp.getStartCol();
            byte endRow = tmp.getEndRow();
            byte endCol = tmp.getEndCol();// tmp variables
            
            //separate word into characters
            char[] wordChars = Words.getWords()[i].toCharArray();
            if(startRow==endRow){//horizontal
                for (byte letter=0;letter<wordChars.length;letter++){
                    assignGridElement(wordChars[letter], startRow, (byte)(startCol+letter));
                }
            } else{ //vertical
                for (byte letter=0;letter<wordChars.length;letter++){
                    assignGridElement(wordChars[letter], (byte)(startRow+letter), startCol);
                }
            }//words assigned in grid
            
            for (byte row=0;row<grid.length;row++){
                for (byte col=0;col<grid[0].length;col++){
                    if((byte)grid[row][col]==0) grid[row][col] = genRanChar();
                }
            }
        }
    }
    private static void assignGridElement(char element, byte x, byte y){
        grid[x][y] = element;
    }
    protected static char genRanChar(){
        return (char)Location.genRan(97,122);
    }
    protected static void display(){
        //top
        IO.print("    ");
        for (byte i=0;i<cols;i++){
            IO.print(i+ (i<10?"  ":" "));
        }
        IO.println("");
        IO.print("    ");
        for (byte i=0;i<10;i++){
            IO.print("--");
        }
        for (byte i=10;i<cols+3;i++){
            IO.print("---");
        }

        //rest
        for (byte i=0;i<rows;i++){
            IO.println("");
            IO.print(i<10 ? i+" | " : i+"| ");
            for (byte j=0;j<cols;j++){
                IO.print(String.valueOf(grid[i][j])+"  ");
            }
            
        }
    }

//Start GetterSetterExtension Source Code

    /**GET Method Propertie grid*/
    public char[][] getGrid(){
        return this.grid;
    }//end method getGrid

//End GetterSetterExtension Source Code


}//End class