 
import javax.swing.JOptionPane;
import javax.swing.JFrame;

class GUI extends JOptionPane{
    static void print(String message){
        //              JFrame
        showMessageDialog(null, message);
    }
    static void printError(String message){
        //JFrame f = new JFrame();
        showMessageDialog(null, message, null, JOptionPane.ERROR_MESSAGE);
    }
    
    static String in(String prompt){
        return showInputDialog(prompt);
    }
}