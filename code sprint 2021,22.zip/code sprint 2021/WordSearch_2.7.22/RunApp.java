class RunApp{
    private static void init(){
        GUI.print("Welcome to WordSearch.");
        Grid.init();
        Words.init();
    }

    
    private static Words words =new Words();
    public static void main(String args[]){
        init();
        do{
            Grid.display();
            IO.println("\nFind the following words:");
            for (byte i=0;i<words.getWordsNotFound().size()-1;i++){
                IO.print(String.valueOf(words.getWordsNotFound().get(i))+", ");
            }
            IO.println(words.getWordsNotFound().get(words.getWordsNotFound().size()-1));
            //printed words still to be found
            
            askUser();
        }while(true);
    }

    protected static String startLoc;
    protected static String endLoc;
    protected static String wordFound;
    public static void askUser(){
        boolean valid;
        do{
            IO.print("Enter start location [Row,Column] or E[x]it: ");
            startLoc= IO.in.next();
            IO.print("Enter end location [Row,Column] or E[x]it: ");
            endLoc= IO.in.next();
            
            valid= checkFormat(startLoc);
            if (valid) valid= checkFormat(endLoc);
            if(!valid) GUI.printError("Incorrect Format. Try again.");
        }while(!valid);
        //after found that locations are valid
        if(checkCorrect()){
            IO.print("You have found word: "+wordFound);
            
        }else{
            IO.println("Incorrect coordinates. Please try again.");
        }
    }
    private static void checkExit(String a){
        if(a.equals("x")){
            IO.print("Exiting...");
            System.exit(0);
        }
    }
    public static boolean checkFormat(String location){
        if(location.contains(",")){
            try{
                String[] a= location.split(",");
                if(a.length!=2) new Exception();
                return true;
            }catch(Exception e) {return false;}
        }else return false;
    }
    
    public static boolean checkCorrect(){
        Location.location = new Location();
        String[] startCoor = startLoc.split(",");
        String[] endCoor = endLoc.split(",");
        for(byte i=0;i<startCoor.length;i++){
            startCoor[i] = startCoor[i].trim();
            endCoor[i] = endCoor[i].trim();
        }// coordinate data is ready for use
        for(byte i=0;i<Words.getWords().length;i++){
            if(Byte.parseByte(startCoor[0])==Words.getWordLocations()[i].getStartRow()
                &&Byte.parseByte(startCoor[1])==Words.getWordLocations()[i].getStartCol()
                &&Byte.parseByte(endCoor[0])==Words.getWordLocations()[i].getEndRow()
                &&Byte.parseByte(endCoor[1])==Words.getWordLocations()[i].getEndCol()){
                    wordFound=Words.getWords()[i];
                    removeWord();
                    return true;
            }
        }
        return false;
    }
    public static void removeWord(){
        for (byte i=0;i<Words.getWordsNotFound().size();i++){
            if(Words.getWordsNotFound().get(i).equals(wordFound))
                Words.getWordsNotFound().remove(i);
        }
    }
}