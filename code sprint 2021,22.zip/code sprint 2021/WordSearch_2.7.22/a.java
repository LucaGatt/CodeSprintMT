class a{
    static void a(){
        char[] a =new char [2];
        for (byte i=0;i <a.length;i++){
            IO.println(String.valueOf(a));
        }
        //if(a[0].equals('a')) IO.println("yes");
        System.out.println((byte)a[0]);
    }
}