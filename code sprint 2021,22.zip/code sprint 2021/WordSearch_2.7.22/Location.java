class Location{ //contains properties of location and creates locations

    private byte startRow,startCol; // where first letter is found
    private byte endRow,endCol;
    protected static Location location;
    protected Location(){

    }

    protected Location(byte startRow,byte startCol, byte endRow, byte endCol){
        this.startRow = startRow;
        this.startCol = startCol;
        this.endRow = endRow;
        this.endCol = endCol;
    }

    protected static Location genRanLocation(int index){
        
        byte startRow ;
            byte startCol ;
            byte length;
            byte direction;
            byte endRow;
            byte endCol;
        do{
            startRow = genRanRow();
            startCol = genRanCol();
            length = (byte)Words.getWords()[index].length();
            direction = genRanDir();
            endRow = (direction==0)? (byte)startRow       :(byte)(startRow+length);
            endCol = (direction==0)? (byte)(startCol+length):(byte)startCol;
            
            location = new Location(startRow, startCol, endRow, endCol);
        }while(checkOutOfBounds());//||checkClash());
        
        return location;
    }

    protected static byte genRanRow(){
        return (byte)genRan(0,Grid.grid.length);
    }

    protected static byte genRanCol(){
        return (byte)genRan(0,Grid.grid[0].length);
    }

    protected static byte genRanDir(){
        return (byte)genRan(0,1);
    }

    protected static boolean checkOutOfBounds(){
        if(location.endRow>Grid.grid.length-1||location.endCol>Grid.grid[0].length-1)
            return true;
        else return false;
    }
    private static boolean checkClash(){
        return false; // complicated
    }

    protected static byte genRan(int min, int max){
        return (byte)(Math.random()*(max-min+1)+min);
    }

//Start GetterSetterExtension Source Code

    /**GET Method Propertie startRow*/
    public byte getStartRow(){
        return this.startRow;
    }//end method getStartRow

    /**SET Method Propertie startRow*/
    public void setStartRow(byte startRow){
        this.startRow = startRow;
    }//end method setStartRow

    /**GET Method Propertie startCol*/
    public byte getStartCol(){
        return this.startCol;
    }//end method getStartCol

    /**SET Method Propertie startCol*/
    public void setStartCol(byte startCol){
        this.startCol = startCol;
    }//end method setStartCol

    /**GET Method Propertie endRow*/
    public byte getEndRow(){
        return this.endRow;
    }//end method getEndRow

    /**SET Method Propertie endRow*/
    public void setEndRow(byte endRow){
        this.endRow = endRow;
    }//end method setEndRow

    /**GET Method Propertie endCol*/
    public byte getEndCol(){
        return this.endCol;
    }//end method getEndCol

    /**SET Method Propertie endCol*/
    public void setEndCol(byte endCol){
        this.endCol = endCol;
    }//end method setEndCol

    /**GET Method Propertie location*/
    public Location getLocation(){
        return this.location;
    }//end method getLocation

    /**SET Method Propertie location*/
    public void setLocation(Location location){
        this.location = location;
    }//end method setLocation

//End GetterSetterExtension Source Code


}//End class