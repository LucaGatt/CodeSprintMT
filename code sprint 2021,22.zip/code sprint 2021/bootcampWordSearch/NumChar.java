class NumChar{
    public static char byteToChar(byte x){
        return (char)(x+48);
        //System.out.println((byte)('0'));
    }
    public static byte charToByte(char x){
        byte a=48;
        return (byte)(x);
        //System.out.println((byte)('0'));
    }
}