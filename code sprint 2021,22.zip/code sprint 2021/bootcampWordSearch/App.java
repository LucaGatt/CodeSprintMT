import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class App {

    private static final String[] WORDS = {"algorithm", "turing", "memory", "java", "code"};

    private static ArrayList<String> wordList = new ArrayList<>();
    private ArrayList<String> wordsLeftList;
    private ArrayList<String> wordsFoundList = new ArrayList<>();
    private String board;
    private Scanner sc = new Scanner(System.in);
    private WordSearch ws;

    public static void main(String[] args) {
        wordList.addAll(Arrays.asList(WORDS));
        new App().run();
    }

    private void run() {
        System.out.println("Welcome to the WordSearch");
        System.out.println("-------------------------\n\n");

        ws = new WordSearch();
        board = (ws.generateBoard(wordList)).toString();
        wordsLeftList = wordList;

        searchLoop();
    }

    private void searchLoop() {
        for (;;) {
            System.out.print(board);
            System.out.println("\nFind the following words:");
            printList(wordsLeftList);

            if (wordsFoundList.size() > 0) {
                System.out.println("\nWords found:");
                printList(wordsFoundList);
            }
    
            try {
                System.out.print("Enter start coordinate [Row,Column] or E[x]it: ");
                String startInput = sc.nextLine();
                if (startInput.equalsIgnoreCase("x")) break;
                int[] startCoor = parseCoor(startInput);
        
                System.out.print("Enter end coordinate [Row,Column] or E[x]it: ");
                String endInput = sc.nextLine();
                if (endInput.equalsIgnoreCase("x")) break;
                int[] endCoor = parseCoor(endInput);

                List<Object> result = ws.isWord(startCoor[0], startCoor[1], endCoor[0], endCoor[1]);
                System.out.println("You marked the word: " + result.get(0));
                if ((boolean) result.get(1)) {
                    System.out.println("You found it!\n");
                    wordsLeftList.remove(result.get(0));
                    wordsFoundList.add(result.get(0).toString());
                    if (wordsLeftList.size() == 0) break;
                    pause();
                } else {
                    System.out.println("This is not a correct word.\n");
                    pause();
                }
            } catch (InputMismatchException ime) {
                System.out.println("Invalid input - please try again.\n");
                pause();
                continue;
            }
        }

        endGame();
    }

    private int[] parseCoor(String input) throws InputMismatchException {
        if (!input.contains(",")) throw new InputMismatchException();
        String[] tokens = input.split(",");
        String x = tokens[0].trim();
        String y = tokens[1].trim();
        
        int[] result = new int[2];
        try {
            result[0] = Integer.parseInt(x);
            result[1] = Integer.parseInt(y);
        } catch (NumberFormatException nfe) {
            throw new InputMismatchException();
        }

        if (result[0] < 0 || result[0] > ws.getWidth() -1 || result[1] < 0 || result[1] > ws.getLength() - 1) {
            throw new InputMismatchException();
        }

        return result;
    }

    private void pause() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void printList(ArrayList<String> listToPrint) {
        for (String word : listToPrint) {
            System.out.print(word + (word.equals(listToPrint.get(listToPrint.size() - 1)) ? "\n\n" : ", "));
        }
    }

    private void endGame() {
        System.out.println("GAME ENDED");
        System.out.println("----------");

        if (wordsLeftList.size() == 0) {
            System.out.println("Congratulations, you found all the words!");
        } else {
            if (wordsFoundList.size() > 0) {
                System.out.println("You found the following words:");
                printList(wordsFoundList);
            }
            System.out.println("You did not find the following words:");
            printList(wordsLeftList);
        }

        pause();
    }
}