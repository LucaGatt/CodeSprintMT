import java.util.*;

public class WordSearch {

  private int width;
  private int length;
  private List<String> words;
  private int[] positions;
  private char[][] board;


  public StringBuilder generateBoard(List<String> words) {
    this.words = words;
    calculateMeasurements();
    fill();
    return printBoard();
  }

  /*
   * @param void;
   * 
   * @return void; Prints the finished wordsearch and related information.
   */
  public StringBuilder printBoard() {
    StringBuilder result = new StringBuilder();

    int y = 0;

    // X Axis
    result.append("    ");
    for (int x = 0; x < length; x++) {
      result.append(x + (x >= 10 ? " " : "  "));
    }
    result.append("\n");
    result.append("    ");
    for (int x = 0; x < length; x++) {
      result.append("---");
    }
    result.append("\n");

    // Board
    for (int i = 0; i < width; i++) {
      result.append(y++ + (y > 10 ? "| " : " | "));
      for (int ind = 0; ind < length; ind++) {
        result.append(board[i][ind] + "  ");
      }
      result.append("\n");
    }

    return result;
  }

  public List<Object> isWord(int startX, int startY, int endX, int endY) {
    StringBuilder chosenWord = new StringBuilder();
    Boolean correct = false;

    if (endX > startX) {
      // Vertical search
      for (int x = startX; x <= endX; x++) {
        chosenWord.append(board[x][startY]);
      }
    } else {
      // Horizontal search
      for (int y = startY; y<= endY; y++) {
        chosenWord.append(board[startX][y]);
      }
    }

    if (words.contains(chosenWord.toString())) {
      correct = true;
    }

    List<Object> result = new ArrayList<>();
    result.add(chosenWord.toString());
    result.add(correct);

    return result;
  }

  public int getWidth() {
    return width;
  }

  public int getLength() {
    return length;
  }

  /*
   * @param void;
   * 
   * @return void; Fills up the search array, applies the inputted words, and
   * randomly generates the rest of the characters.
   */
  private void fill() {
    int between, strlen;
    int x, y;
    int wordCount = words.size();

    positions = new int[wordCount];
    for (int i = 0; i < wordCount; i++) { // for each word in list
      strlen = words.get(i).length();
      between = width - strlen;
      x = randomRange(0, between); // make sure it isnt a y coord anyone else is using.
      y = randomRange(0, length - 5);
      if (search(positions, y)) {
        y++;
      }
      positions[i] = y;
      for (int ind = 0; ind < strlen; ind++) { // for each letter in the word,
        board[x][y] = words.get(i).charAt(ind); // put char into search array
        x++;
      }
    }
    // fill empty slots.
    for (int i = 0; i < length; i++) {
      for (int ind = 0; ind < width; ind++) {
        if (board[ind][i] == 0) {
          char t = (char) randomRange(97, 122);
          //char t = '-';
          board[ind][i] = t;
        }
      }
    }

  }

  /*
   * @param int array, int key.
   * 
   * @return boolean : searches array for the key. returns true if key is in array.
   */
  private boolean search(int[] numbers, int key) {
    for (int index = 0; index < numbers.length; index++) {
      if (numbers[index] == key) {
        return true; // We found it!!!
      }
    }
    return false;
  }

  /**
   * @param int low, int high : the bounding values for the range within which the
   *            generated number should fall.
   * @return int : the random number generated. random number genertator for
   *          values
   */
  private int randomRange(int low, int high) {
    Random generator = new Random();
    return generator.nextInt(high - low + 1) + low;
  }

  /*
   * @param void;
   * 
   * @return void; Calculates size of the char array the word search uses.
   */
  private void calculateMeasurements() {
    for (int i = 0; i < words.size(); i++) {
      if (words.get(i).length() > width) {
        width = words.get(i).length();
      }
    }
    width = width * 2;
    length = width + (width / 3);
    board = new char[width][length];
  }

}