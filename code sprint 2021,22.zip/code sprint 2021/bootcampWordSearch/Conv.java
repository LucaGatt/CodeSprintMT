public class Conv{
    public static char charFromShort(short x){
        System.out.println((char)(x));
        return (char)(x);
    }
    public static void main(short y){
        System.out.println("s : "+(char)(y));
        //return (char)(x);
    }
    
    public static void a_z(){
        System.out.println((char)(97));
        //return (char)(x);
    }
    public static void A_Z(){
        System.out.println((char)(65));
        //return (char)(x);
    }
    public static void toByte(){
        System.out.println((byte)('A'));
        //return (char)(x);
    }
    
    public static void numByteToChar(byte x){
        System.out.println((char)(x));
        //return (char)(x);
    }
    public static void numCharToByte(char x){
        System.out.println((byte)(x));
        //return (char)(x);
    }
}