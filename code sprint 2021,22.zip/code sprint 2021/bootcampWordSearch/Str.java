class Str{
    public static void toInt(String x){
        Integer.parseInt(x);
    }
    public static void toShort(String x){
        Short.parseShort(x);
    }
    public static void toByte(String x){
        Byte.parseByte(x);
    }
    public static String fromChar(char[] x){
        return String.valueOf(x);
    }
}