class Display{
    static BombSweeper bs = new BombSweeper();
    public static void hitBomb(){
        System.out.println("--------------------------------");
        System.out.println("|      GAME        OVER        |");
        System.out.println("|       YOU HIT A BOMB         |");
        System.out.println("--------------------------------");
    }
    public static void buildBoard(){
        StringBuilder sb = new StringBuilder();
        sb.append("0  ");
    }
    public static void endGame(){
        System.out.println("--------------------------------");
        System.out.println("|        YOU       WON         |");
        System.out.println("--------------------------------");
        bs.revealBombs();
    }
}