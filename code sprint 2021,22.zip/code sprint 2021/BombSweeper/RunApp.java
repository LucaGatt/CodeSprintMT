    //file from bootcamp program
import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

class RunApp{
    static byte noBombs =10;
    public static Bombs[] bombs = new Bombs [10];
    public static BombSweeper bs = new BombSweeper();
    public static Scanner sc = new Scanner (System.in);
    static String board;
    public static void main(String args[]){
        for (byte i=0;i<bombs.length;i++){
            bombs[i]=new Bombs(M.random(0,9),M.random(0,9));
        }
        run();
    }
    
    public static void run() {
        System.out.println("Welcome to the BombSweeper");
        System.out.println("--------------------------\n\n");

        board = (bs.printBoard()).toString();
        //wordsLeftList = wordList;

        sweeperLoop();
    }
    
    private static void sweeperLoop() {
        for (;;) {
            System.out.print(board);
            
    
            try {
                System.out.print("Enter location [Row,Column] or E[x]it: ");
                String input = sc.nextLine();
                if (input.equalsIgnoreCase("x")||input.equalsIgnoreCase("X"))
                    break;
                int[] coor = parseCoor(input);
                
                System.out.print("[R]eveal or [F]lag the location: ");
                char action = sc.nextLine().charAt(0);
                if (action=='r'||action=='R'){
                    bs.checkFlag(coor);
                    bs.actReveal(coor[0],coor[1]);
                }
                else if (action=='f'||action=='F') bs.actFlag(coor[0],coor[1]);
                else throw new InputMismatchException();
                /*
                System.out.print("Enter end coordinate [Row,Column] or E[x]it: ");
                String endInput = sc.nextLine();
                if (endInput.equalsIgnoreCase("x")) break;
                int[] endCoor = parseCoor(endInput);
                */
                
                List<Object> result = bs.isBomb(coor[0], coor[1]);
                if ((boolean) result.get(0)) {
                    bs.revealBombs();
                    /*wordsLeftList.remove(result.get(0));
                    wordsFoundList.add(result.get(0).toString());
                    if (wordsLeftList.size() == 0) break;*/
                    //pause();
                } else {
                    System.out.println("You did not hit a bomb.\n");
                    //pause();
                }
                pause();
            } catch (InputMismatchException ime) {
                System.out.println("Invalid input - please try again.\n");
                pause();
                continue;
            }
        }
        Display.endGame();
        bs.revealBombs();
    }
    
    
    private static int[] parseCoor(String input) throws InputMismatchException {
        if (!input.contains(",")) throw new InputMismatchException();
        String[] tokens = input.split(",");
        String x = tokens[0].trim();
        String y = tokens[1].trim();
        
        int[] result = new int[2];
        try {
            result[0] = Integer.parseInt(x);
            result[1] = Integer.parseInt(y);
        } catch (NumberFormatException nfe) {
            throw new InputMismatchException();
        }

        if (result[0] < 0 || result[0] > bs.getWidth() -1 || result[1] < 0 || result[1] > bs.getLength() - 1) {
            throw new InputMismatchException();
        }

        return result;
    }

    private static void pause() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void printList(ArrayList<String> listToPrint) {
        for (String word : listToPrint) {
            System.out.print(word + (word.equals(listToPrint.get(listToPrint.size() - 1)) ? "\n\n" : ", "));
        }
    }
}