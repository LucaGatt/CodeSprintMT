//used bootcamp's program
import java.util.*;
class BombSweeper{
    private static byte length=10,width=10;
    
    private List<Integer> bombCoorX = new ArrayList<>();
    private List<Integer> bombCoorY = new ArrayList<>();
    public static Bombs[] bombs = RunApp.bombs;
    private int[] positions;
    private static char[][] board=new char [length][width];
    
    static int coorX;
    static int coorY;
    
    public static Scanner sc = new Scanner (System.in);
    
    
    /*
   * @param void;
   * 
   * @return void; Prints the finished bomb sweeper and related information.
   */
  public StringBuilder printBoard() {
    StringBuilder result = new StringBuilder();

    int y = 0;

    // X Axis
    result.append("    ");
    for (int x = 0; x < length; x++) {
      result.append(x + "   ");
    }
    result.append("\n");
    result.append("  -");
    for (int x = 0; x < length; x++) {
      result.append("----");
    }
    result.append("\n");

    // Board
    for (int i = 0; i < width; i++) {
      result.append(y++ + "  | ");
      for (int ind = 0; ind < length; ind++) {
        result.append(board[i][ind] + " | ");
      }
      result.append("\n");
    }

    return result;
  }
  
  public List<Object> isBomb(int coorX, int coorY) {
    this.coorX = coorX;
    this.coorY = coorY;
      //StringBuilder chosenWord = new StringBuilder();
    boolean bombFound = false;
    
    for (byte i=0; i<bombCoorX.size();i++){
        if (bombCoorX.get(i)==coorX && bombCoorY.get(i)==coorY) {
          bombFound = true; break;
        }
    }

    List<Object> result = new ArrayList<>();
    result.add(bombFound);
    

    return result;
  }
  
  public static byte getNoSurrBombs(int coorX, int coorY){//x=col,y=row
      byte bombCounter=0;
      for (byte i=0; i<bombs.length;i++){
        if (bombs[i].x==coorX-1 && bombs[i].y==coorY-1) {//top left
          bombCounter++;
        }
        if (bombs[i].x==coorX && bombs[i].y==coorY-1) {//top middle
          bombCounter++;
        }
        if (bombs[i].x==coorX+1 && bombs[i].y==coorY-1) {//top right
          bombCounter++;
        }
        
        if (bombs[i].x==coorX-1 && bombs[i].y==coorY) {//mid left
          bombCounter++;
        }
        if (bombs[i].x==coorX+1 && bombs[i].y==coorY) {//mid right
          bombCounter++;
        }
        
        if (bombs[i].x==coorX-1 && bombs[i].y==coorY+1) {//bottom left
          bombCounter++;
        }
        if (bombs[i].x==coorX && bombs[i].y==coorY+1) {//bottom middle
          bombCounter++;
        }
        if (bombs[i].x==coorX+1 && bombs[i].y==coorY+1) {//bottom right
          bombCounter++;
        }
      }
      return bombCounter;
  }

  public void actReveal(int coorX, int coorY){
      int[] coor = new int [2];
      coor[0] = coorX;
      coor[1] = coorY;
      if(checkTouchable(coor)){
          int bombCounter= getNoSurrBombs(coorX, coorY);
          StringBuilder sb = new StringBuilder();
          sb.append(bombCounter);
          char a = (sb.toString()).charAt(0);
          board[coorX][coorY] = a;
      }
  }
  public void actFlag(int coorX, int coorY){
      int[] coor = new int [2];
      coor[0] = coorX;
      coor[1] = coorY;
      if(checkTouchable(coor))board[coor[0]][coor[1]]='F';
  }
  
  public static boolean checkTouchable(int[] coor){//revealed=notTouchable
      if (board[coor[0]][coor[1]]!=0 && board[coor[0]][coor[1]]!='F'){
          System.out.println("Already revealed. Try another input.");
          return false;
      }
      return true;
  }
    public static boolean checkFlag(int[] coor){
        if (board[coor[0]][coor[1]]=='F'){
            char input;
            while(true){
                System.out.println("Location already flagged...[U]nflag or [F]lag");
                input = sc.nextLine().charAt(0);
                if(input=='U' || input=='F') break;
            }
            if (input=='U') board[coor[0]][coor[1]]=0;
            return true;
        }
        return false;
    }
  
  public byte getWidth() {
    return width;
  }

  public byte getLength() {
    return length;
  }

  public void revealBombs(){//when game is lost
      for (byte i=0; i<bombs.length; i++){
          if(board[bombs[i].x][bombs[i].y]==('F'))
            board[bombs[i].x][bombs[i].y] = '#';
          else board[bombs[i].x][bombs[i].y] = 'B';
      }
  }

  /**
   * @param int low, int high : the bounding values for the range within which the
   *            generated number should fall.
   * @return int : the random number generated. random number genertator for
   *          values
   */
  private int randomRange(int low, int high) {
    Random generator = new Random();
    return generator.nextInt(high - low + 1) + low;
  }
}