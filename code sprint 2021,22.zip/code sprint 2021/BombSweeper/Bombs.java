class Bombs{
    short x,y;
    public Bombs(short x,short y){
        this.x= x;
        this.y= y;
    }
}