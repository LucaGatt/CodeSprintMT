import java.util.*;
class RunApp{
    public static final String[] WORDS = {"algorithm", "turing", "memory", "java", "code"};//9letters
    static Scanner in = new Scanner (System.in);
    
    private static byte length;
    private static byte width;
    
    public static void main(String args[]){
        System.out.println("Welcome to the WordSearch\n-------------------------\n\n\n");
        WordSearch.run();
    }
    
    //private static void 
}