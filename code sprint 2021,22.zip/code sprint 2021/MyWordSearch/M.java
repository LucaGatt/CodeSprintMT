class M{
    public static byte random(byte min,byte max){
        return (byte)(Math.random()*(max-min+1)+min);
    }
}