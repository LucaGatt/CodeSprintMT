import java.util.*;
class WordSearch{
    private static byte length;
    private static byte width;
    static StringBuilder board = new StringBuilder();
    static char[][] grid = new char [length][width];
    static String[] words = RunApp.WORDS;
    static Scanner in = new Scanner(System.in);
    
    private static byte[] startCoor = new byte [2];
    private static byte[] endCoor = new byte [2];
    
    public static void run(){
        calculateSize();
        fillBoard();
        for (;;){
            printBoard();
            enterStartCoor();
            enterEndCoor();
        }
    }
    public static void enterStartCoor(){
        boolean invalid = true;
        byte[] coor = new byte [2];
        while(invalid){
            invalid= false;
            System.out.print("Enter start coordinate [Row,Column] or E[x]it: ");
            String a = in.nextLine();
            if (a.contains(",")){
                String[] b= a.split(",");
                b[0].trim();
                b[1].trim();
                
                for (byte i=0; i<coor.length&&!invalid; i++){
                    try{
                        coor[i] = Byte.parseByte(b[i]);
                        if(coor[0]>length||coor[0]<0||coor[1]>width||coor[1]<0) throw new Exception();
                    }catch (Exception e){
                        System.out.println("Incorrect input. Try again");
                        invalid= true;
                    }
                }
            }else{
                System.out.println("Incorrect input. Try again");
                invalid= true;
            }
        }
        for (byte i=0;i<2;i++){
            startCoor[i] = coor[i];
        }
    }
    public static void enterEndCoor(){
        boolean invalid = true;
        byte[] coor = new byte [2];
        while(invalid){
            invalid= false;
            System.out.print("Enter end coordinate [Row,Column] or E[x]it: ");
            String a = in.nextLine();
            if (a.contains(",")){
                String[] b= a.split(",");
                b[0].trim();
                b[1].trim();
                
                for (byte i=0; i<coor.length&&!invalid; i++){
                    try{
                        coor[i] = Byte.parseByte(b[i]);
                        if(coor[0]>length||coor[0]<0||coor[1]>width||coor[1]<0) throw new Exception();
                    }catch (Exception e){
                        System.out.println("Incorrect input. Try again");
                        invalid= true;
                    }
                }
            }else{
                System.out.println("Incorrect input. Try again");
                invalid= true;
            }
        }
        for (byte i=0;i<2;i++){
            endCoor[i] = coor[i];
        }
    }
    public static void printBoard(){
        System.out.print(board.toString());
        //return board;
    }
    private static void fillBoard(){
        printXAxis();
        conBoard();
    }
    private static void printXAxis(){
        //x-axis
        board.append("    ");
        for (byte i=0; i<length; i++){
            board.append(i+ (i>9?" ":"  "));
        }
        board.append("\n    ");
        for (byte i=0; i<length; i++){
            board.append("---");
        }
    }
    private static void conBoard(){
        for (byte i=0;i<width;i++){
            board.append(i+(i>9?"| ":" | "));
            for (byte j=0;j<length;j++){
                board.append(grid[j][i]+(j==length-1?"\n":" "));
            }
        }
    }
    //complete grid{
    private static void storeWords(){
        for (byte i=0; i<words.length;i++){//for each word
            //chooseColumn
            byte x= M.random((byte)0,length);//col randomised; col =x
            byte y= M.random((byte)0,(byte)(width - words[i].length()));//row=y
            for (byte j=0; j<words[i].length();j++){//for each letter
                grid[x][y]=words[i].charAt(j);
                y++;
            }
        }
    }
    private static void fillEmpty(){
        for (byte i=0;i<grid.length;i++){
            for (byte j=0;j<grid[0].length;j++){
                if (grid[i][j]==0){
                    grid[i][j] = (char)M.random((byte)97,(byte)122);
                }
            }
        }
    }
    //}
    public static byte getLength(){
        return length;
    }
    public static byte getWidth(){
        return width;
    }
    private static void calculateSize(){
        byte width = 9;
        width *= 2;
        byte length = (byte)(width *4/3);
    }
}