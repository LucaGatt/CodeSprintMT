/**
 * Main program entry point.
 *
 * AirCargo
 *
 * @author Keith Vassallo <keith@icemalta.com>
 * @version 1.0
 *
 */

import com.icemalta.aircargo.controller.SystemController;

public class RunApp {
    public static void main(String[] args) throws InterruptedException {
        SystemController controller = new SystemController("CLI");
        controller.start();
    }
}
