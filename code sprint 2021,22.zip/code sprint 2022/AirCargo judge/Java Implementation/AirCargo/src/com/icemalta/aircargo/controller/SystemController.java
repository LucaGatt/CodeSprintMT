package com.icemalta.aircargo.controller;

import com.icemalta.aircargo.model.Aircraft;
import com.icemalta.aircargo.model.Booking;
import com.icemalta.aircargo.model.Cargo;
import com.icemalta.aircargo.view.MenuCLI;

import java.util.ArrayList;

/**
 * Controller class which loads an appropriate view and proxies functionality to the model classes.
 */
public class SystemController {

    private final ArrayList<Aircraft> fleet = new ArrayList<>(); // List of aircraft
    private final ArrayList<Booking> bookings = new ArrayList<>(); // List of bookings
    private String mode = "CLI";

    /**
     * Initialises the controller with CLI or GUI modes.
     * Currently, only CLI mode is supported.
     * @param mode CLI|GUI
     */
    public SystemController(String mode) {
        this.mode = mode;
        this.seed();
    }

    /**
     * Calls a view depending on the current mode
     * @throws InterruptedException
     */
    public void start() throws InterruptedException {
        if (this.mode.equals("CLI")) {
            MenuCLI menu = new MenuCLI(this);
            menu.show();
        }
    }

    /**
     * @return the list of aircraft
     */
    public ArrayList<Aircraft> getFleet() {
        return this.fleet;
    }

    /**
     * Adds an aircraft to the fleet
     * @param callSign Call sign
     * @param manufacturer Aircraft manufacturer
     * @param model Aircraft model
     * @param capacityVolume Aircraft volume capacity in meters cubed
     * @param capacityWeight Aircraft weight capacity in kilograms
     */
    public void addAircraft(String callSign, String manufacturer, String model, double capacityVolume, double capacityWeight) {
        this.fleet.add(new Aircraft(callSign, manufacturer, model, capacityVolume, capacityWeight));
    }

    /**
     * Removes an aircraft from the fleet, including all associated bookings
     * @param craftNum id of aircraft to remove
     */
    public void removeAircraft(int craftNum) {
        Aircraft aircraft = this.fleet.get(craftNum);
        this.bookings.removeIf(b -> b.getAircraft() == aircraft);
        this.fleet.remove(craftNum);
    }

    /**
     * @return the list of bookings
     */
    public ArrayList<Booking> getBookings() {
        return this.bookings;
    }

    /**
     * Retrieves a booking
     * @param no booking id
     * @return the booking specified
     */
    public Booking getBooking(int no) {
        return this.bookings.get(no);
    }

    /**
     * Adds a booking
     * @param year Year of booking
     * @param week Week of booking
     * @param portFrom Departure airport
     * @param portTo Arrival airport
     * @param aircraftId id of the aircraft for this booking
     */
    public void addBooking(int year, int week, String portFrom, String portTo, int aircraftId) {
        this.bookings.add(new Booking(year, week, portFrom, portTo, this.fleet.get(aircraftId)));
    }

    /**
     * Deletes a booking
     * @param bookingNum id of booking to delete
     */
    public void deleteBooking(int bookingNum) {
        this.bookings.remove(bookingNum);
    }

    /**
     * Adds cargo to a booking if there is enough volume and weight capacity left
     * @param bookingNum id of booking to add cargo to
     * @param description cargo manifest
     * @param volume cargo volume in M3
     * @param weight cargo weight in Kg
     * @return true if cargo is added to booking
     */
    public boolean addCargo(int bookingNum, String description, double volume, double weight) {
        if (volume <= this.getAvailableVolume(bookingNum) && weight <= this.getAvailableWeight(bookingNum)) {
            this.bookings.get(bookingNum).addCargo(new Cargo(description, volume, weight));
            return true;
        }
        return false;
    }

    /**
     * Removes cargo from a booking
     * @param bookingNum id of booking to remove cargo from
     * @param cargoNum id of cargo to remove from booking
     */
    public void removeCargo(int bookingNum, int cargoNum) {
        this.getBooking(bookingNum).getCargo().remove(cargoNum);
    }

    /**
     * Check if a booking is full by weight
     * @param bookingNum id of booking
     * @return true if booking is full (weight)
     */
    public boolean bookingWeightFull(int bookingNum) {
        return this.bookings.get(bookingNum).getAvailableWeight() == 0;
    }

    /**
     * Check if a booking is full by volume
     * @param bookingNum id of booking
     * @return true if booking is full (volume)
     */
    public boolean bookingVolumeFull(int bookingNum) {
        return this.bookings.get(bookingNum).getAvailableVolume() == 0;
    }

    /**
     * Gets available booking weight
     * @param bookingNum id of a booking
     * @return available weight (max - current) of this booking in kg
     */
    public double getAvailableWeight(int bookingNum) {
        return this.bookings.get(bookingNum).getAvailableWeight();
    }

    /**
     * Gets available booking volume
     * @param bookingNum id of a booking
     * @return available volume (max - current) of this booking in m3
     */
    public double getAvailableVolume(int bookingNum) {
        return this.bookings.get(bookingNum).getAvailableVolume();
    }

    /**
     * Get the current weight of a booking
     * @param bookingNum id of a booking
     * @return total current weight of this booking
     */
    public double getBookingWeight(int bookingNum) {
        return this.bookings.get(bookingNum).getWeight();
    }

    /**
     * Get the current volume of a booking
     * @param bookingNum id of a booking
     * @return total current volume of this booking
     */
    public double getBookingVolume(int bookingNum) {
        return this.bookings.get(bookingNum).getVolume();
    }

    /**
     * Get the maximum weight of a booking
     * @param bookingNum id of a booking
     * @return maximum weight of this booking
     */
    public double getMaxWeight(int bookingNum) {
        return this.bookings.get(bookingNum).getMaxWeight();
    }

    /**
     * Get the maximum volume of a booking
     * @param bookingNum id of a booking
     * @return maximum volume of this booking
     */
    public double getMaxVolume(int bookingNum) {
        return this.bookings.get(bookingNum).getMaxVolume();
    }

    /**
     * Checks whether a booking can be made for a given year, week and aircraft
     * @param year Booking year
     * @param week Booking Week
     * @param aircraftId Aircraft Id
     * @return true if aircraft is available this year and week
     */
    public boolean bookingDateAvailable(int year, int week, int aircraftId) {
        Aircraft aircraft = this.fleet.get(aircraftId);
        for(Booking b : this.getBookings()) {
            if (b.getYear() == year && b.getWeek() == week && b.getAircraft() == aircraft) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return the number of aircraft in the fleet
     */
    public int getFleetSize() {
        return this.fleet.size();
    }

    /**
     * Get the number of cargo items in a booking
     * @param bookingNum id of a booking
     * @return the number of cargo items in this booking
     */
    public int getCargoSize(int bookingNum) {
        return this.bookings.get(bookingNum).getCargo().size();
    }

    /**
     * @return the total number of bookins
     */
    public int getBookingsSize() {
        return this.bookings.size();
    }

    /**
     * Adds some initial aircraft to the fleet for testing purposes
     */
    public void seed() {
        this.fleet.add(new Aircraft("MCS2341", "Boeing", "737-400BCF", 141, 20870));
        this.fleet.add(new Aircraft("MCS2342", "Airbus", "A320-200EFW", 141, 20870));
        this.fleet.add(new Aircraft("MCS3000", "Antonov", "AN-124", 1040, 150000));
        this.fleet.add(new Aircraft("MCS2343", "Boeing", "737-400BCF", 141, 20870));
    }

}
