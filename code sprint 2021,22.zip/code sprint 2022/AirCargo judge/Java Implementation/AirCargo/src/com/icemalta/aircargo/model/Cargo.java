package com.icemalta.aircargo.model;

/**
 * Simple storage class for cargo items
 */
public class Cargo {

    private String description;
    private double volume;
    private double weight;

    /**
     * Initialises a cargo item
     * @param description textual description of cargo
     * @param volume volume of cargo in M3
     * @param weight volume of cargo in Kg
     */
    public Cargo(String description, double volume, double weight) {
        this.description = description;
        this.volume = volume;
        this.weight = weight;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
