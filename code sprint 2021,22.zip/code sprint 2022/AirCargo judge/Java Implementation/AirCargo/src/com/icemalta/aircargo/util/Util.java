package com.icemalta.aircargo.util;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Simple utilities for retrieving int and float values
 */
public class Util {

    private static final Scanner sc = new Scanner(System.in);
    private static final Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

    /**
     * Checks if a value is numeric using a regular expression
     * @param strNum string to check
     * @return true of the value is numeric
     */
    private static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        return pattern.matcher(strNum).matches();
    }

    /**
     * Retrieve an integer value
     * @param message prompt to display to user
     * @return the retrieved int
     */
    public static int getInt(String message) {
        for (;;) {
            System.out.print(message);
            String value = sc.nextLine();

            if (!Util.isNumeric(value)) {
                System.out.println("Please enter a digit!");
                continue;
            }

            return Integer.parseInt(value);
        }
    }

    /**
     * Retrieve an integer value
     * @param message prompt to display to user
     * @param convertToZeroBased whether to subtract 1 from final value (for zero-based selections)
     * @return the retrieved int
     */
    public static int getInt(String message, boolean convertToZeroBased) {
        int intVal = Util.getInt(message);

        if (convertToZeroBased) {
            intVal -= 1;
        }

        return intVal;
    }

    /**
     * Retrieve an integer value
     * @param message prompt to display to user
     * @param maxVal maximum acceptable value
     * @param minVal minimum acceptable value
     * @param convertToZeroBased whether to subtract 1 from final value (for zero-based selections)
     * @return the retrieved int
     */
    public static int getInt(String message, int maxVal, int minVal, boolean convertToZeroBased) {
        for (;;) {
            int intVal = Util.getInt(message);

            if (intVal > maxVal || intVal < minVal) {
                System.out.printf("Value must be between %d and %d\n", minVal, maxVal);
                continue;
            }

            if (convertToZeroBased) {
                intVal -= 1;
            }

            return intVal;
        }
    }

    /**
     * Retrieve a float value
     * @param message prompt to display to the user
     * @return the retrieved float value
     */
    public static float getFloat(String message) {
        for (;;) {
            try {
                System.out.print(message);
                String value = sc.nextLine();
                return Float.parseFloat(value);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a digit!");
            }
        }
    }
}
