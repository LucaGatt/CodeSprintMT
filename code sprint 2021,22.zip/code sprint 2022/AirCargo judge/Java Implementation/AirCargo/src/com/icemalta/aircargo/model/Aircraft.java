package com.icemalta.aircargo.model;

/**
 * Simple storage class for Aircraft
 */
public class Aircraft {

    private String callSign;
    private String manufacturer;
    private String model;
    private double capacityVolume;
    private double capacityWeight;


    /**
     * Initialises a new Aircraft
     * @param callSign The aircraft call sign assigned by MAA
     * @param manufacturer Aircraft manufacturer
     * @param model Aircraft model
     * @param capacityVolume Volume capacity in meters cubed
     * @param capacityWeight Weight capacity in kilograms
     */
    public Aircraft(String callSign, String manufacturer, String model, double capacityVolume, double capacityWeight) {
        this.callSign = callSign;
        this.manufacturer = manufacturer;
        this.model = model;
        this.capacityVolume = capacityVolume;
        this.capacityWeight = capacityWeight;
    }

    /**
     * Prints Aircraft call sign
     * @return Aircraft call sign
     */
    public String toString() {
        return this.callSign;
    }

    public String getCallSign() {
        return callSign;
    }

    public void setCallSign(String callSign) {
        this.callSign = callSign;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getCapacityVolume() {
        return capacityVolume;
    }

    public void setCapacityVolume(double capacityVolume) {
        this.capacityVolume = capacityVolume;
    }

    public double getCapacityWeight() {
        return capacityWeight;
    }

    public void setCapacityWeight(double capacityWeight) {
        this.capacityWeight = capacityWeight;
    }
}
