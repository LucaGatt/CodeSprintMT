package com.icemalta.aircargo.view;

import com.icemalta.aircargo.controller.SystemController;
import com.icemalta.aircargo.model.Aircraft;
import com.icemalta.aircargo.model.Booking;
import com.icemalta.aircargo.model.Cargo;
import com.icemalta.aircargo.util.Util;

import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;

/**
 * Command line interface view
 */
public class MenuCLI {

    private SystemController systemController;
    private final Scanner sc = new Scanner(System.in);

    /**
     * Initialises the CLI view
     * @param systemController the controller which initialised the view
     */
    public MenuCLI(SystemController systemController) {
        this.systemController = systemController;
    }

    /**
     * Shows the main menu
     * @throws InterruptedException
     */
    public void showMain() throws InterruptedException {
        for(;;) {
            System.out.println("Malta Cargo Services");
            System.out.println("--------------------");
            System.out.println("1. Manage Fleet");
            System.out.println("2. Manage Bookings");
            System.out.println("3. Exit");
            System.out.print("\nChoice> ");
            String choice = sc.nextLine();

            if (choice.equals("1")) {
                showFleetMenu();
            } else if (choice.equals("2")) {
                showBookingsMenu();
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("\nInvalid option chosen. Valid: 1/2/3.");
                Thread.sleep(2000);
            }
        }
    }

    /**
     * Shows the fleet management menu
     * @throws InterruptedException
     */
    public void showFleetMenu() throws InterruptedException {
        for (;;) {
            System.out.println("\nMain > Fleet Management\n");

            showFleet();

            System.out.println("1. Add new Aircraft");
            System.out.println("2. Remove Aircraft");
            System.out.println("3. Back to Main Menu");
            System.out.print("\nChoice> ");
            String choice = sc.nextLine();

            if (choice.equals("1")) {
                addAircraft();
            } else if (choice.equals("2")) {
                removeAircraft();
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("\nInvalid option chosen. Valid: 1/2/3.");
                Thread.sleep(2000);
            }
        }
    }

    /**
     * Shows the booking management menu
     * @throws InterruptedException
     */
    public void showBookingsMenu() throws InterruptedException {
        for (;;) {
            System.out.println("\nMain > Booking Management\n");

            if (systemController.getBookingsSize() == 0) {
                System.out.println("There are currently no bookings.\n");
            } else {
                int no = 1;
                System.out.printf("%-3s\t%-4s\t%-4s\t%-12s\t%-12s\t%-12s\n", "No", "Year", "Week", "From", "To", "Aircraft");
                for (Booking b : systemController.getBookings()) {
                    System.out.printf("%-3s\t%-4s\t%-4s\t%-12s\t%-12s\t%-12s\n", no, b.getYear(), b.getWeek(), b.getPortFrom(), b.getPortTo(), b.getAircraft());
                    no++;
                }
            }

            System.out.println();
            System.out.println("1. Add new Booking");
            System.out.println("2. Delete Booking");
            System.out.println("3. Manage Booking");
            System.out.println("4. Back to Main Menu");
            System.out.print("\nChoice> ");
            String choice = sc.nextLine();

            if (choice.equals("1")) {
                addBooking();
            } else if (choice.equals("2")) {
                deleteBooking();
            } else if (choice.equals("3")) {
                showBookingMenu();
            } else if (choice.equals("4")) {
                break;
            } else {
                System.out.println("\nInvalid option chosen. Valid: 1/2/3/4.");
                Thread.sleep(2000);
            }
        }
    }

    /**
     * Shows the booking detail menu
     * @throws InterruptedException
     */
    public void showBookingMenu() throws InterruptedException {
        int bookingNum = Util.getInt("Booking Number> ", systemController.getBookingsSize(), 1, true);
        Booking booking = systemController.getBooking(bookingNum);

        for (;;) {
            System.out.println("\nMain > Booking Management > Booking\n");
            System.out.printf("Booking for week %s of %s\n", booking.getWeek(), booking.getYear());
            System.out.printf("From %s to %s\n", booking.getPortFrom(), booking.getPortTo());
            System.out.printf("Volume: %sM3 of %sM3 capacity\n", systemController.getBookingVolume(bookingNum), systemController.getMaxVolume(bookingNum));
            System.out.printf("Weight: %sKg of %skg capacity\n", systemController.getBookingWeight(bookingNum), systemController.getMaxWeight(bookingNum));
            System.out.println("--");

            if (systemController.getCargoSize(bookingNum) == 0) {
                System.out.println("This booking is currently empty.\n");
            } else {
                System.out.println("\nCargo:");
                int no = 1;
                System.out.printf("%-3s\t%-20s\t%-11s\t%-11s\n", "No", "Description", "Volume (M3)", "Weight (Kg)");
                for (Cargo cargo : booking.getCargo()) {
                    System.out.printf("%-3s\t%-20s\t%-11s\t%-11s\n", no, cargo.getDescription(), cargo.getVolume(), cargo.getWeight());
                    no++;
                }
            }

            System.out.println();
            System.out.println("1. Add Cargo");
            System.out.println("2. Remove Cargo");
            System.out.println("3. Back to Main Menu");
            System.out.print("\nChoice> ");
            String choice = sc.nextLine();

            if (choice.equals("1")) {
                addCargo(bookingNum);
            } else if (choice.equals("2")) {
                removeCargo(bookingNum);
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("\nInvalid option chosen. Valid: 1/2/3.");
                Thread.sleep(2000);
            }
        }
    }

    /**
     * Utility function which shows the fleet
     */
    private void showFleet() {
        int no = 1;
        System.out.printf("%-3s\t%-9s\t%-12s\t%-12s\t%-12s\t%-12s\n", "ID", "Call Sign", "Manufacturer", "Model", "Payload (Kg)", "Payload (M3)");
        for (Aircraft aircraft : systemController.getFleet()) {
            System.out.printf("%-3s\t%-9s\t%-12s\t%-12s\t%-12s\t%-12s\n", no, aircraft.getCallSign(), aircraft.getManufacturer(), aircraft.getModel(), aircraft.getCapacityWeight(), aircraft.getCapacityVolume());
            no++;
        }
        System.out.println();
    }

    /**
     * Input for adding an aircraft
     */
    private void addAircraft() {
        System.out.println("\nMain > Fleet Management > Add Aircraft\n");
        System.out.print("Call Sign> ");
        String callSign = sc.nextLine();
        System.out.print("Manufacturer> ");
        String manufacturer = sc.nextLine();
        System.out.print("Model> ");
        String model = sc.nextLine();
        double capacityVolume = Util.getFloat("Volume Capacity (M3)> ");
        double capacityWeight = Util.getFloat("Weight Capacity (Kg)> ");
        systemController.addAircraft(callSign, manufacturer, model, capacityVolume, capacityWeight);
    }

    /**
     * Input for removing an aircraft
     */
    private void removeAircraft() {
        System.out.println("\nMain > Fleet Management > Remove Aircraft\n");
        int num = Util.getInt("Aircraft to remove> ", systemController.getFleetSize(), 1, true);
        System.out.print("Are you sure you want to delete this aircraft? This will delete all bookings!!! [y/N]> ");
        String confirm = sc.nextLine();
        if (confirm.equalsIgnoreCase("y")) {
            systemController.removeAircraft(num);
        }
    }

    /**
     * Input for adding a booking
     * @throws InterruptedException
     */
    private void addBooking() throws InterruptedException {
        System.out.println("\nMain > Booking Management > Add Booking\n");
        int year = Util.getInt("Year> ", 9999, Calendar.getInstance().get(Calendar.YEAR), false);
        int week = Util.getInt("Week> ", 52, year == Calendar.getInstance().get(Calendar.YEAR) ? LocalDate.now().get(WeekFields.of(new Locale("en")).weekOfYear()) : 1, false);
        System.out.print("Departing From> ");
        String portFrom = sc.nextLine();
        System.out.print("Arrving At> ");
        String portTo = sc.nextLine();
        showFleet();
        int aircraft = Util.getInt("Aircraft> ", systemController.getFleetSize(), 1, true);

        if (systemController.bookingDateAvailable(year, week, aircraft)) {
            systemController.addBooking(year, week, portFrom, portTo, aircraft);
        } else {
            System.out.printf("\nThis aircraft is already booked for week %s %s\n", week, year);
            Thread.sleep(2000);
        }
    }

    /**
     * Input for deleting a booking
     */
    private void deleteBooking() {
        System.out.println("\nMain > Booking Management > Delete Booking\n");
        int num = Util.getInt("Booking to delete> ", systemController.getBookingsSize(), 1, true);
        System.out.print("Are you sure you want to delete this booking? [y/N]> ");
        String confirm = sc.nextLine();
        if (confirm.equalsIgnoreCase("y")) {
            systemController.deleteBooking(num);
        }
    }

    /**
     * Input for adding cargo to a booking
     * @param booking id of booking to add cargo to
     * @throws InterruptedException
     */
    private void addCargo(int booking) throws InterruptedException {
        System.out.println("\nMain > Booking Management > Add Cargo\n");
        if (systemController.bookingVolumeFull(booking) || systemController.bookingWeightFull(booking)) {
            System.out.println("This booking is full!");
            Thread.sleep(2000);
            return;
        }

        System.out.print("Description> ");
        String description = sc.nextLine();
        double volume = Util.getFloat("Volume (M3)> ");
        double weight = Util.getFloat("Weight (Kg)> ");

        if (!systemController.addCargo(booking, description, volume, weight)) {
            System.out.println("\nCargo could not be added. Please check weight and volume limits.");
            Thread.sleep(2000);
        }
    }

    /**
     * Input for removing cargo from a booking
     * @param booking id of booking to remove cargo from
     */
    private void removeCargo(int booking) {
        System.out.println("\nMain > Booking Management > Remove Cargo\n");
        int num = Util.getInt("Cargo to remove> ", systemController.getCargoSize(booking), 1, true);
        System.out.print("Are you sure you want to delete this cargo? [y/N]> ");
        String confirm = sc.nextLine();
        if (confirm.equalsIgnoreCase("y")) {
            systemController.removeCargo(booking, num);
        }
    }

    /**
     * Genetic method for showing the main menu
     * @throws InterruptedException
     */
    public void show() throws InterruptedException {
        this.showMain();
    }

}
