package com.icemalta.aircargo.model;

import java.util.ArrayList;

/**
 * Storage class for bookings with some methods to get available weight and volume
 */
public class Booking {

    private int year;
    private int week;
    private String portFrom;
    private String portTo;
    private Aircraft aircraft;
    private final ArrayList<Cargo> cargo;

    /**
     * Initialises a new booking
     * @param year Year of booking
     * @param week Week of booking
     * @param portFrom Airport cargo is departing from,
     * @param portTo Airport cargo is arriving to
     * @param aircraft Aircraft used for this booking
     */
    public Booking(int year, int week, String portFrom, String portTo, Aircraft aircraft) {
        this.year = year;
        this.week = week;
        this.portFrom = portFrom;
        this.portTo = portTo;
        this.aircraft = aircraft;
        this.cargo = new ArrayList<>();
    }

    /**
     * Adds a new cargo item to this booking
     * @param cargo the cargo to add
     * @return true if cargo added successfully
     */
    public boolean addCargo(Cargo cargo) {
        this.cargo.add(cargo);
        return true;
    }

    /**
     * @return the list of cargo in this booking
     */
    public ArrayList<Cargo> getCargo() {
        return this.cargo;
    }

    /**
     * @return the maximum volume capacity for this booking
     */
    public double getMaxVolume() {
        return this.aircraft.getCapacityVolume();
    }

    /**
     * @return the maximum weight capacity for this booking
     */
    public double getMaxWeight() {
        return this.aircraft.getCapacityWeight();
    }

    /**
     * @return the space left (volume) in this booking
     */
    public double getAvailableVolume() {
        double currentVolume = this.getVolume();
        return this.aircraft.getCapacityVolume() - currentVolume;
    }

    /**
     * @return the carrying capacity (weight) left in this booking
     */
    public double getAvailableWeight() {
        double currentWeight = this.getWeight();
        return this.aircraft.getCapacityWeight() - currentWeight;
    }

    /**
     * @return total volume of all cargo in this booking
     */
    public double getVolume() {
        double currentVolume = 0;
        for (Cargo cargo: this.cargo) {
            currentVolume += cargo.getVolume();
        }
        return currentVolume;
    }

    /**
     * @return total weight of all cargo in this booking
     */
    public double getWeight() {
        double currentWeight = 0;
        for (Cargo cargo: this.cargo) {
            currentWeight += cargo.getWeight();
        }
        return currentWeight;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getWeek() {
        return week;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    public String getPortFrom() {
        return portFrom;
    }

    public void setPortFrom(String portFrom) {
        this.portFrom = portFrom;
    }

    public String getPortTo() {
        return portTo;
    }

    public void setPortTo(String portTo) {
        this.portTo = portTo;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }
}
