"""
Main program entry point.

AirCargo

:Author:
    Keith Vassallo <keith@icemalta.com>

:Version: 1.0

"""

from Controller.SystemController import SystemController

controller = SystemController()
controller.start()
