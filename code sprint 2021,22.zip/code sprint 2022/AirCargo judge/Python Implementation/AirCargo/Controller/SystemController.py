from typing import List

from model.Aircraft import Aircraft
from model.Booking import Booking
from model.Cargo import Cargo

from view import MenuCLI


class SystemController:
    """
    Controller class which loads an appropriate view and proxies functionality to the model classes.
    """

    FLEET: List[Aircraft] = []  # List of aircraft
    BOOKINGS: List[Booking] = []  # List of bookings

    def __init__(self, mode: str = "CLI") -> None:
        """
        Initialises the controller with CLI or GUI modes.
        Currently, only CLI mode is supported[
        :param mode: CLI|GUI
        """
        self.mode: str = mode
        SystemController.seed()

    def start(self) -> None:
        """
        Calls a view depending on the current mode
        :return: None
        """
        if self.mode == "CLI":
            MenuCLI.show()

    @staticmethod
    def get_fleet() -> List[Aircraft]:
        """
        :return: the list of aircraft
        """
        return SystemController.FLEET

    @staticmethod
    def add_aircraft(call_sign: str, manufacturer: str, model: str, capacity_volume: float,
                     capacity_weight: float) -> None:
        """
        Adds an aircraft to the fleet
        :param call_sign: Call sign
        :param manufacturer: Aircraft manufacturer
        :param model: Aircraft model
        :param capacity_volume: Aircraft volume capacity in meters cubed
        :param capacity_weight: Aircraft weight capacity in kilograms
        :return: None
        """
        SystemController.FLEET.append(Aircraft(call_sign, manufacturer, model, capacity_volume, capacity_weight))

    @staticmethod
    def remove_aircraft(craft_num: int):
        """
        Removes an aircraft from the fleet, including all associated bookings
        :param craft_num: id of aircraft to remove
        :return: None
        """
        aircraft = SystemController.FLEET[craft_num]
        SystemController.BOOKINGS = [x for x in SystemController.BOOKINGS if x.aircraft != aircraft]
        del SystemController.FLEET[craft_num]

    @staticmethod
    def get_bookings() -> List[Booking]:
        """
        :return: the list of bookings
        """
        return SystemController.BOOKINGS

    @staticmethod
    def get_booking(no: int) -> Booking:
        """
        :param no: booking id
        :return: the booking specified
        """
        return SystemController.BOOKINGS[no]

    @staticmethod
    def add_booking(year: int, week: int, port_from: str, port_to: str, aircraft_id: int) -> None:
        """
        Adds a booking
        :param year: Year of booking
        :param week: Week of booking
        :param port_from: Departure airport
        :param port_to: Arrival airport
        :param aircraft_id: id of aircraft for this booking
        :return: None
        """
        b = Booking(year, week, port_from, port_to, SystemController.FLEET[aircraft_id])
        SystemController.BOOKINGS.append(b)

    @staticmethod
    def delete_booking(booking_num: int) -> None:
        """
        Deletes a booking
        :param booking_num: id of booking to delete
        :return: None
        """
        del SystemController.BOOKINGS[booking_num]

    @staticmethod
    def add_cargo(booking_num: int, description: str, volume: float, weight: float) -> bool:
        """
        Adds cargo to a booking if there is enough volume and weight capacity left
        :param booking_num: id of booking to add cargo to
        :param description: cargo manifest
        :param volume: cargo volume in M3
        :param weight: cargo weight in Kg
        :return: True if cargo is added to booking
        """
        if volume <= SystemController.get_available_volume(
                booking_num) and weight <= SystemController.get_available_weight(booking_num):
            c = Cargo(description, volume, weight)
            SystemController.BOOKINGS[booking_num].cargo.append(c)
            return True
        return False

    @staticmethod
    def remove_cargo(booking_num: int, cargo_num: int) -> None:
        """
        Removes cargo from a booking
        :param booking_num: id of booking to remove cargo from
        :param cargo_num: id of cargo to remove from booking
        :return: None
        """
        del SystemController.BOOKINGS[booking_num].cargo[cargo_num]

    @staticmethod
    def booking_weight_full(booking_num: int) -> bool:
        """
        :param booking_num: id of a booking
        :return: True if booking is full (weight)
        """
        return SystemController.BOOKINGS[booking_num].get_available_weight() == 0

    @staticmethod
    def booking_volume_full(booking_num: int) -> bool:
        """
        :param booking_num: id of a booking
        :return: True if booking isfull (volume)
        """
        return SystemController.BOOKINGS[booking_num].get_available_volume() == 0

    @staticmethod
    def get_available_weight(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: available weight (max - current) of this booking in kg
        """
        return SystemController.BOOKINGS[booking_num].get_available_weight()

    @staticmethod
    def get_available_volume(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: available volume (max - current) of this booking in m3
        """
        return SystemController.BOOKINGS[booking_num].get_available_volume()

    @staticmethod
    def get_booking_weight(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: total current weight of this booking
        """
        return SystemController.BOOKINGS[booking_num].get_weight()

    @staticmethod
    def get_booking_volume(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: total current volume of this booking
        """
        return SystemController.BOOKINGS[booking_num].get_volume()

    @staticmethod
    def get_max_weight(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: maximum weight of this booking
        """
        return SystemController.BOOKINGS[booking_num].get_max_weight()

    @staticmethod
    def get_max_volume(booking_num: int) -> float:
        """
        :param booking_num: id of a booking
        :return: maximum volume of this booking
        """
        return SystemController.BOOKINGS[booking_num].get_max_volume()

    @staticmethod
    def booking_date_available(year: int, week: int, aircraft_id: int) -> bool:
        """
        Checks whether a booking can be made for a given year, week and aircraft
        :param year: Booking Year
        :param week: Booking Week
        :param aircraft_id: Aircraft Id
        :return: True if aircraft is available this year and week
        """
        aircraft = SystemController.FLEET[aircraft_id]
        for booking in SystemController.BOOKINGS:
            if booking.year == year and booking.week == week and booking.aircraft == aircraft:
                return False
        return True

    @staticmethod
    def get_fleet_size() -> int:
        """
        :return: the number of aircraft in the fleet
        """
        return len(SystemController.FLEET)

    @staticmethod
    def get_cargo_size(booking_num: int) -> int:
        """
        :param booking_num: id of a booking
        :return: the number of cargo items in this booking
        """
        return len(SystemController.BOOKINGS[booking_num].cargo)

    @staticmethod
    def get_bookings_size() -> int:
        """
        :return: the total number of bookings
        """
        return len(SystemController.BOOKINGS)

    @staticmethod
    def seed() -> None:
        """
        Adds some initial aircraft to the fleet for testing purposes
        :return: None
        """
        SystemController.FLEET.append(Aircraft("MCS2341", "Boeing", "737-400BCF", 141, 20870))
        SystemController.FLEET.append(Aircraft("MCS2342", "Airbus", "A320-200EFW", 141, 20870))
        SystemController.FLEET.append(Aircraft("MCS3000", "Antonov", "AN-124", 1040, 150000))
        SystemController.FLEET.append(Aircraft("MCS2343", "Boeing", "737-400BCF", 141, 20870))
