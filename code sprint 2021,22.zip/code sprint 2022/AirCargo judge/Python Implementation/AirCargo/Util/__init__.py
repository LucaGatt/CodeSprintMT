"""
Simple utilities for retrieving int and float values
"""
from typing import Union


def get_int(message: str, max_val: Union[int, None], min_val: Union[int, None], convert_to_zero_based: bool = False) -> int:
    """
    Retrieve an integer value
    :param message: prompt to display to user
    :param max_val: maximum acceptable value
    :param min_val: minimum acceptable value
    :param convert_to_zero_based: whether to subtract 1 from final value (for zero-based selections)
    :return: the retrieved int
    """
    while True:
        value = input(message)
        if not value.isnumeric():
            print('Please enter a digit!')
            continue

        value = int(value)

        if max_val is not None and min_val is not None:
            if value > max_val or value < min_val:
                print('Value must be between {0} and {1}'.format(min_val, max_val))
                continue
        elif max_val is not None:
            if value > max_val:
                print('Maximum allowed value is {0}', max_val)
                continue
        elif min_val is not None:
            if value < min_val:
                print('Minimum allowed value is {0}', min_val)
                continue

        if convert_to_zero_based:
            value -= 1

        break

    return value


def get_float(message: str) -> float:
    """
    Retrieve a float value
    :param message: prompt to display to the user
    :return: the retrieved float value
    """
    while True:
        try:
            value = input(message)
            return float(value)
        except ValueError:
            print('Please enter a digit!')
