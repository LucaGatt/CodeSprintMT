from __future__ import annotations
from typing import List

from model import Aircraft, Cargo


class Booking:
    """
    Storage class for bookings with some methods to get available weight and volume
    """

    def __init__(self, year: int, week: int, port_from: str, port_to: str, aircraft: Aircraft) -> None:
        """
        Initialises a new booking
        :param year: Year of booking
        :param week: Week of booking
        :param port_from: Airport cargo is departing from
        :param port_to: Airport cargo is arriving to
        :param aircraft: Aircraft used for this booking
        """
        self.year: int = year
        self.week: int = week
        self.port_from: str = port_from
        self.port_to: str = port_to
        self.aircraft: Aircraft = aircraft
        self.cargo: List[Cargo] = []

    def add_cargo(self, cargo: Cargo) -> bool:
        """
        Adds a new cargo item to this booking
        :param cargo: the cargo to add
        :return: True if cargo added successfully
        """
        self.cargo.append(cargo)
        return True

    def get_cargo(self) -> List[Cargo]:
        """
        :return: the list of cargo in this booking
        """
        return self.cargo

    def get_max_volume(self) -> float:
        """
        :return: the maximum volume capacity for this booking
        """
        return self.aircraft.capacity_volume

    def get_max_weight(self) -> float:
        """
        :return: the maximum weight capacity for this booking
        """
        return self.aircraft.capacity_weight

    def get_available_volume(self) -> float:
        """
        :return: the space left (volume) in this booking
        """
        current_volume = self.get_volume()
        return self.aircraft.capacity_volume - current_volume

    def get_available_weight(self) -> float:
        """
        :return: the carrying capacity (weight) left in this booking
        """
        current_weight = self.get_weight()
        return self.aircraft.capacity_weight - current_weight

    def get_volume(self) -> float:
        """
        :return: total volume of all cargo in this booking
        """
        current_volume = 0
        for cargo in self.cargo:
            current_volume += cargo.volume
        return current_volume

    def get_weight(self) -> float:
        """
        :return: total weight of all cargo in this booking
        """
        current_weight = 0
        for cargo in self.cargo:
            current_weight += cargo.weight
        return current_weight
