class Aircraft:
    """
    Simple storage class for Aircraft
    """

    def __init__(self, call_sign: str, manufacturer: str, model: str, capacity_volume: float,
                 capacity_weight: float) -> None:
        """
        Initialises a new Aircraft
        :param call_sign: The aircraft call sign assigned by MAA
        :param manufacturer: Aircraft manufacturer
        :param model: Aircraft model
        :param capacity_volume: Volume capacity in meters cubed
        :param capacity_weight: Weight capacity in kilograms
        """
        self.call_sign: str = call_sign
        self.manufacturer: str = manufacturer
        self.model: str = model
        self.capacity_volume: float = capacity_volume
        self.capacity_weight: float = capacity_weight

    def __str__(self):
        """
        Prints Aircraft call sign
        :return: Aircraft call sign
        """
        return self.call_sign
