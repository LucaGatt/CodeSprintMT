class Cargo:
    """
    Simple storage class for cargo items
    """

    def __init__(self, description: str, volume: float, weight: float):
        """
        Initialises a cargo item
        :param description: textual description of cargo
        :param volume: volume of cargo in M3
        :param weight: weight of cargo in Kg
        """

        self.description: str = description
        self.volume: float = volume
        self.weight: float = weight


