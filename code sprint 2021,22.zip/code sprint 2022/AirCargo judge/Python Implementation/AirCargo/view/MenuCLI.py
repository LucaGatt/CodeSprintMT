import time
from datetime import date

import Controller.SystemController as Controller
from Util import get_int, get_float


def show_main() -> None:
    """
    Shows the main menu
    :return: None
    """
    while True:
        print('Malta Cargo Services')
        print('--------------------')
        print('1. Manage Fleet')
        print('2. Manage Bookings')
        print('3. Exit')
        choice = input('\nChoice> ')

        if choice == '1':
            show_fleet_menu()
        elif choice == '2':
            show_bookings_menu()
        elif choice == '3':
            break
        else:
            print('\nInvalid option chosen. Valid: 1/2/3.')
            time.sleep(2)


def show_fleet_menu() -> None:
    """
    Shows the fleet management menu
    :return: None
    """
    while True:
        print('\nMain > Fleet Management\n')

        show_fleet()

        print('1. Add new Aircraft')
        print('2. Remove Aircraft')
        print('3. Back to Main Menu')
        choice = input('\nChoice> ')
        
        if choice == '1':
            add_aircraft()
        elif choice == '2':
            remove_aircraft()
        elif choice == '3':
            break
        else:
            print('\nInvalid option chosen. Valid: 1/2/3.')
            time.sleep(2)


def show_bookings_menu() -> None:
    """
    Shows the booking management menu
    :return: None
    """

    while True:
        print('\nMain > Booking Management\n')

        if Controller.SystemController.get_bookings_size() == 0:
            print('There are currently no bookings.\n')
        else:
            no = 1
            print("{0:3}\t{1:4}\t{2:4}\t{3:12}\t{4:12}\t{5:12}"
                  .format("No", "Year", "Week", "From", "To", "Aircraft"))
            for booking in Controller.SystemController.get_bookings():
                print("{0:3}\t{1:4}\t{2:4}\t{3:12}\t{4:12}\t{5:12}"
                      .format(no, booking.year, booking.week, booking.port_from, booking.port_to, booking.aircraft.call_sign))
                no += 1
                print()

        print('1. Add new Booking')
        print('2. Delete Booking')
        print('3. Manage Booking')
        print('4. Back to Main Menu')
        choice = input('\nChoice> ')

        if choice == '1':
            add_booking()
        elif choice == '2':
            delete_booking()
        elif choice == '3':
            show_booking_menu()
        elif choice == '4':
            break
        else:
            print('\nInvalid option chosen. Valid: 1/2/3/4.')
            time.sleep(2)


def show_booking_menu() -> None:
    """
    Shows the booking detail menu
    :return: None
    """

    booking_num = get_int('Booking Number> ', Controller.SystemController.get_bookings_size(), 1, True)
    booking = Controller.SystemController.get_booking(booking_num)
    while True:
        print('\nMain > Booking Management > Booking\n')
        print('Booking for week {0} of {1}'.format(booking.week, booking.year))
        print('From {0} to {1}'.format(booking.port_from, booking.port_to))
        print('Volume: {0}M3 of {1}M3 capacity'.format(Controller.SystemController.get_booking_volume(booking_num),
                                                       Controller.SystemController.get_max_volume(booking_num)))
        print('Weight: {0}Kg of {1}Kg capacity'.format(Controller.SystemController.get_booking_weight(booking_num),
                                                       Controller.SystemController.get_max_weight(booking_num)))
        print('--'),

        if Controller.SystemController.get_cargo_size(booking_num) == 0:
            print('This booking is currently empty.\n')
        else:
            print("\nCargo:")
            no = 1
            print('{0:3}\t{1:20}\t{2:11}\t{3:11}'.format("No", "Description", "Volume (M3)", "Weight (Kg)"))
            for cargo in booking.cargo:
                print('{0:3}\t{1:20}\t{2:11}\t{3:11}'.format(no, cargo.description, cargo.volume, cargo.weight))
                no += 1

        print('1. Add Cargo')
        print('2. Remove Cargo')
        print('3. Back to Main Menu')
        choice = input('\nChoice> ')

        if choice == '1':
            add_cargo(booking_num)
        elif choice == '2':
            remove_cargo(booking_num)
        elif choice == '3':
            break
        else:
            print('\nInvalid option chosen. Valid: 1/2/3.')
            time.sleep(2)


def show_fleet() -> None:
    """
    Utility function which shows the fleet
    :return: None
    """

    no = 1
    print("{0:3}\t{1:9}\t{2:12}\t{3:12}\t{4:12}\t{5:12}"
          .format("ID", "Call Sign", "Manufacturer", "Model", "Payload (Kg)", "Payload (M3)"))
    for aircraft in Controller.SystemController.get_fleet():
        print("{0:3}\t{1:9}\t{2:12}\t{3:12}\t{4:12}\t{5:12}"
              .format(no, aircraft.call_sign, aircraft.manufacturer, aircraft.model, aircraft.capacity_weight,
                      aircraft.capacity_volume))
        no += 1
    print()


def add_aircraft() -> None:
    """
    Input for adding an aircraft
    :return: None
    """
    print('\nMain > Fleet Management > Add Aircraft\n')
    call_sign = input('Call Sign> ')
    manufacturer = input('Manufacturer> ')
    model = input('Model> ')
    capacity_volume = get_float('Volume Capacity (M3)> ')
    capacity_weight = get_float('Weight Capacity (Kg)> ')
    Controller.SystemController.add_aircraft(call_sign, manufacturer, model, capacity_volume, capacity_weight)


def remove_aircraft() -> None:
    """
    Input for removing an aircraft
    :return: None
    """

    print('\nMain > Fleet Management > Remove Aircraft\n')
    num = get_int('Aircraft to remove> ', Controller.SystemController.get_fleet_size(), 1, True)
    confirm = input("Are you sure you want to delete this aircraft? This will delete all bookings!!! [y/N]> ")
    if confirm == "y" or confirm == "Y":
        Controller.SystemController.remove_aircraft(num)


def add_booking():
    """
    Input for adding a booking
    :return: None
    """

    print('\nMain > Booking Management > Add Booking\n')
    year = get_int('Year> ', None, date.today().year, False)
    week = get_int('Week> ', 52, date.today().isocalendar().week if year == date.today().year else 1, False)
    port_from = input('Departing From> ')
    port_to = input('Arriving At> ')
    show_fleet()
    aircraft = get_int('Aircraft> ', Controller.SystemController.get_fleet_size(), 1, True)

    if Controller.SystemController.booking_date_available(year, week, aircraft):
        Controller.SystemController.add_booking(year, week, port_from, port_to, aircraft)
    else:
        print('\nThis aircraft is already booked for week {0} {1}'.format(week, year))
        time.sleep(2)


def delete_booking() -> None:
    """
    Input for deleting a booking
    :return: None
    """

    print('\nMain > Booking Management > Delete Booking\n')
    num = get_int("Booking to delete> ", Controller.SystemController.get_bookings_size(), 1, True)
    confirm = input("Are you sure you want to delete this booking? [y/N]> ")
    if confirm == "y" or confirm == "Y":
        Controller.SystemController.delete_booking(num)


def add_cargo(booking: int) -> None:
    """
    Input for adding cargo to a booking
    :param booking: id of booking to add cargo to
    :return: None
    """

    print('\nMain > Booking Management > Add Cargo\n')
    if Controller.SystemController.booking_volume_full(booking) or Controller.SystemController.booking_weight_full(booking):
        print('This booking is full!')
        time.sleep(2)
        return

    description = input('Description> ')
    volume = get_float('Volume (M3)> ')
    weight = get_float('Weight (Kg)> ')

    if not Controller.SystemController.add_cargo(booking, description, volume, weight):
        print('\nCargo could not be added. Please check weight and volume limits.')
        time.sleep(2)


def remove_cargo(booking: int) -> None:
    """
    Input for removing cargo from a booking
    :param booking: id of booking to remove cargo from
    :return: None
    """

    print('\nMain > Booking Management > Remove Cargo\n')
    num = get_int('Cargo to remove> ', Controller.SystemController.get_cargo_size(booking), 1, True)
    confirm = input("Are you sure you want to delete this cargo? [y/N]> ")
    if confirm == "y" or confirm == "Y":
        Controller.SystemController.remove_cargo(booking, num)


def show() -> None:
    """
    Generic method for showing the main menu
    :return: None
    """

    show_main()

