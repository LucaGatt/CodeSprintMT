import java.util.ArrayList;

/**
 * Song class holds instance variables of the songs for registration
 *  and other things which may be related.
 *  
 * @author (your name)
 * @version (a version number or a date)
 */
public class Song
{
    // instance variables - replace the example below with your own
    protected static ArrayList<Song> songs = new ArrayList(); // stores songs for contest
    
    private String singer;
    private String song;
    private int length;// in seconds
    private byte vote; // vote casted by judges

    /**
     * Constructor for objects of class Song
     */
    public Song()
    {
        // initialise instance variables
            //songs = new ArrayList();
        singer = "";
        song = "";
        length = 0;
    }
    public Song(String singer, String song, int length){
        this.singer = singer; // assignments of instance var.s= local var.s
        this.song = song;
        this.length = length;
        songs.add(this); // adds new instance of Song to array 'songs'
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void displaySongs()
    {
        // put your code here
        for (int i=0;i<songs.size();i++){
            System.out.println(i+". Singer: "+songs.getSinger()+"\tSong: "+song+"\t"+length+"\t"+vote);
        }
    }


    
    
    //Start GetterSetterExtension Source Code

    /**GET Method Propertie songs*/
    public java.util.ArrayList<Song> getSongs(){
        return this.songs;
    }//end method getSongs

    /**SET Method Propertie songs*/
    public void setSongs(java.util.ArrayList<Song> songs){
        this.songs = songs;
    }//end method setSongs

    /**GET Method Propertie singer*/
    public String getSinger(){
        return this.singer;
    }//end method getSinger

    /**SET Method Propertie singer*/
    public void setSinger(String singer){
        this.singer = singer;
    }//end method setSinger

    /**GET Method Propertie song*/
    public String getSong(){
        return this.song;
    }//end method getSong

    /**SET Method Propertie song*/
    public void setSong(String song){
        this.song = song;
    }//end method setSong

    /**GET Method Propertie length*/
    public int getLength(){
        return this.length;
    }//end method getLength

    /**SET Method Propertie length*/
    public void setLength(int length){
        this.length = length;
    }//end method setLength

//End GetterSetterExtension Source Code



//Start GetterSetterExtension Source Code

    /**SET Method Propertie vote*/
    public void setVote(byte vote){
        this.vote = vote;
    }//end method setVote

//End GetterSetterExtension Source Code



//Start GetterSetterExtension Source Code

    /**GET Method Propertie vote*/
    public byte getVote(){
        return this.vote;
    }//end method getVote

//End GetterSetterExtension Source Code


}//End class