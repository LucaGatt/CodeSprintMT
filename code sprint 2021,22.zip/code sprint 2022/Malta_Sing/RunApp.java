import generic.*;
class RunApp{
    private static void init(){ //let all initialisation process be done
        Judging.init();
    }
    
    public static void main(String args[]){
        //IO.
        
        init();
        
        //show menu
        menu();
    }

    private static void menu(){
        byte option=0;
        boolean valid;
        do{
            valid= true;
            System.out.print("\fChoose from 3 options:\n"
                +"1.Singer"
                +"2.Judge"
                +"3.Exit");

            try{
                option = IO.in.nextByte();
            }catch (Exception e){
                GUI.printError("Option input is not a number. Try again.");
                valid =false;
            }
            if(option<1||option>3){
                GUI.printError("Option input is not a number 1-3.");
                valid = false;
            }
        }while(!valid);
        
        //when valid
        switch(option){
            case 1: singerMenu(); break;
            case 2: judgeMenu(); break;
            case 3: IO.println("Exiting..."); System.exit(0);
            // no need for default since other inputs are already taken care of for validity of 'option'
        }
    }

    private static void singerMenu(){
        
        byte option=0;
        boolean valid;
        do{
            valid= true;
            System.out.print("\nChoose from 2 options:\n"
                +"\t1.Register for the competition\n"
                +"\t2.Check the score board");

            try{
                option = IO.in.nextByte();
            }catch (Exception e){
                GUI.printError("Option input is not a number. Try again.");
                valid =false;
            }
            if(option<1||option>2){
                GUI.printError("Option input is not a number 1-2.");
                valid = false;
            }
        }while(!valid);
        
        //when valid
        switch(option){
            case 1: Registration.register(); break;
            case 2: ScoreBoard.checkScoreBoard(); break;
            // no need for default since other inputs are already taken care of for validity of 'option'
        }
    }
    
    private static void judgeMenu(){
        Judging.login();
        
        byte option=0;
        boolean valid;
        do{
            valid= true;
            System.out.print("\nChoose from 2 options:\n"
                +"\t1.Stop registration process\n"
                +"\t2.Cast their votes.");

            try{
                option = IO.in.nextByte();
            }catch (Exception e){
                GUI.printError("Option input is not a number. Try again.");
                valid =false;
            }
            if(option<1||option>2){
                GUI.printError("Option input is not a number 1-2.");
                valid = false;
            }
        }while(!valid);
        
        //when valid
        switch(option){
            case 1: Judging.stopRegistration(); break;
            case 2: Judging.castVote(); break;
            // no need for default since other inputs are already taken care of for validity of 'option'
        }
    }
}