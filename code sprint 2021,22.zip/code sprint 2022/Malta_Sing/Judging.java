import generic.*; // my package

import java.util.ArrayList;

/**
 * Judging class holds functionality and login credentials related to judging
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Judging
{
    // instance variables - replace the example below with your own
    protected static Judging[] judges = new Judging[2];

    //login credentials
    private String username;
    private String password;

    /**
     * Constructor for objects of class Judging
     */
    public Judging()
    {
        // initialise instance variables
        username = "";
        password = "";
    }

    public Judging(String username, String password){
        this.username = username;
        this.password = password;
    }

    /**
     * Method to initialise judges
     *
     * @param   none
     * @return    none
     */
    protected static void init()
    {
        // put your code here
        judges[0].username = "kevinCassar";
        judges[0].password = "1KnowBest!";
        judges[1].username = "saraVella";
        judges[1].password = "Am@21ng";
    }

    public static void login(){
        boolean valid =true;
        do{
            String username = GUI.in("Enter username:");
            if(!checkUsername(username)){
                GUI.printError("Username entered does not exist.");
                valid=false;
            }

            String password;
            if(valid){
                password = GUI.in("Enter password:");
                if(!checkPassword(password)){
                    GUI.printError("Password entered is incorrect.");
                    valid=false;
                }
            }
        }while(!valid);//iterate until valid
    }
    private static byte indexOfUsername = -1;
    private static boolean checkUsername(String username){
        for (byte i=0;i<judges.length;i++){
            if(username.equals(judges[i].username)){
                indexOfUsername = i;
                return true;
            }
        }
        return false;
    }

    private static boolean checkPassword(String password){
        if(password.equals(judges[indexOfUsername].password))
            return true;
        else return false;
    }

    protected static void stopRegistration(){
        Registration.registrationStopped = true;
        GUI.print("You have stopped the registration process.");
    }

    protected static void castVote(){
        System.out.print("Choose song to cast vote on:");
        
        System.out.print("Set vote out of 100:");
        byte vote=-1;
        boolean valid;
        do{
            valid=true;// reset variable
            try{
                IO.in.nextByte();
            }catch(Exception e){
                valid=false;
            }
            if(vote<0||vote>100) valid = false;
            if(!valid){
                GUI.printError("Input not accepted. It must be a number between 0 and 100.");
            }
        }while(!valid);
    }
}
