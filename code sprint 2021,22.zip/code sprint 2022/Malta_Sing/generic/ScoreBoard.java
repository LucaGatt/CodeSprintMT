package generic;


/**
 * Write a description of class ScoreBoard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ScoreBoard
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class ScoreBoard
     */
    public ScoreBoard()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * displays score board
     *
     * @param  none
     * @return   none
     */
    public static void checkScoreBoard()
    {
        // put your code here
        
    }
}
