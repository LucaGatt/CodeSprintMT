import generic.*;
import java.util.InputMismatchException;

/**
 * This class takes care of the functionality related to registration from singers.
 *
 */
public class Registration
{
    // instance variables - replace the example below with your own
    protected static boolean registrationStopped;

    /*
    /**
     * Constructor for objects of class Registration

    public Registration()
    {
    // initialise instance variables

    }
     */

    /**
     * Method to register
     *
     * @param  none
     * @return  none
     */
    protected static void register()
    {
        // put your code here
        if(!registrationStopped){ //if registration not stopped
            boolean valid; //used for validity of input
            do{
                valid= true; //reset variable
                IO.print("Enter singer name: ");
                String singer = IO.in.next();
                IO.print("Enter song name: ");
                String song = IO.in.next();
                if(!checkUnique(song)){ // if not unique
                    valid=false;
                    GUI.printError("Song not unique. Try again.");
                }
                if(singer.length()<3||song.length()<3){ // checking length of characters
                    valid = false;
                    GUI.printError("Both singer and song name must be at least 3 characters long.");
                }

                int length=0;
                if(valid){// only continue process if song is unique to exclude redundant processing

                    IO.print("Enter song length:");
                    try{ // validate input for exception of input not a number
                        length = IO.in.nextInt();
                    }catch(InputMismatchException ime){
                        valid= false;
                        GUI.printError("Length is not a number.");
                    }
                    if(length<60||length>180){
                        valid= false;
                        GUI.printError("Length of song must be between 1 minute and 3 minutes. Try again.");
                    }
                }
                if(valid) new Song(singer,song,length);
            }while(!valid); // iterate until valid
        }else{ // if registration has been stopped
            GUI.printError("Registration has been stopped.");
        }
    }

    private static boolean checkUnique(String song){
        for (int i=0; i<Song.songs.size();i++){
            if(Song.songs.get(i).getSong().equals(song)){
                return false;
            }
        }
        return true;
    }
}
