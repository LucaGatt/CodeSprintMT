import generic.*; // my package
class RunApp{
    private static void init(){ //let all initialisation process be done
        new Database();
    }
    
    public static void main(String args[]){
        //IO.
        
        init();
    
        do{
        menu();}while(true);
    }
    
    private static void menu(){
        byte option = Validation.inOption(
            "1.Fleet Management\n\t"+
            "2.Booking Management\n\t"+
            "3.Cargo Management", 3);
        switch(option){
            case 1: menu1(); break;
            case 2: menu2(); break;
            case 3: menu3(); break;
        }
    }
}