
/**
 * Write a description of class Cargo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Cargo
{
    // instance variables - replace the example below with your own
    private String description; // description of cargo contents
    private short volume; // volume of cargo
    private short weight; // weight of cargo

    /**
     * Constructor for objects of class Cargo
     */
    public Cargo()
    {
        // initialise instance variables
        description = "";
        volume= 0;
        weight = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod()
    {
        // put your code here
        return 0;
    }
}
