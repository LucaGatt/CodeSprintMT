import java.util.ArrayList;

/**
 * contains information about bookings, aircrafts and cargos
 */
public class Database
{
    // instance variables - replace the example below with your own
    protected static ArrayList<Booking> bookings;// = new ArrayList();
    protected static ArrayList<Aircraft> aircrafts;// = new ArrayList();
    protected static ArrayList<Cargo> cargos;// = new ArrayList();

    /**
     * Constructor for objects of class Database
     */
    public Database()
    {
        // initialise instance variables
        bookings = new ArrayList();
        aircrafts = new ArrayList();
        cargos = new ArrayList();
        
        //pre-enter aircrafts
        aircrafts.add(new Aircraft(
            "MCS2341", "Boeing", "737-400BCF", (short)141, 20870 ));
        aircrafts.add(new Aircraft(
            "MCS2342", "Airbus", "A320-200EFW", (short)141, 20870 ));
        aircrafts.add(new Aircraft(
            "MCS3000", "Antonov", "AN-124", (short)1040, 150000 ));
        aircrafts.add(new Aircraft(
            "MCS2343", "Boeing", "737-400BCF", (short)141, 20870 ));
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void sampleMethod()
    {
        // put your code here
        
    }
}
