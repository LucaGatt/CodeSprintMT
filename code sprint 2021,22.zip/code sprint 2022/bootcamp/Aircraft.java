
/**
 * class has aircraft fields
 */
public class Aircraft
{
    // instance variables - replace the example below with your own
    private String callSign;
    private String manufacturer;
    private String model;
    private short volume;
    private int weight;
    

    /**
     * Constructor for objects of class Aircraft
     */
    public Aircraft()
    {
        // initialise instance variables
        callSign = "";
        manufacturer = "";
        model = "";
        volume = 0;
        weight = 0;
    }
    
    protected Aircraft(String callSign, String manufacturer, String model , short volume, int weight){
        this.callSign = callSign;
        this.manufacturer = manufacturer;
        this.model = model;
        this.volume = volume;
        this.weight = weight;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    if week number is valid
     */
    public boolean s()
    {
        // put your code here
        return false;
    }
}
