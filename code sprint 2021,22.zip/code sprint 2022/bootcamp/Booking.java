
/**
 * Write a description of class Booking here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Booking
{
    // instance variables - replace the example below with your own
    private short year;
    private byte week; //week of booking
    private String departing;
    private String arriving;
    private Aircraft aircraft;
    
    
    /**
     * Constructor for objects of class Booking
     */
    public Booking()
    {
        // initialise instance variables
        year = 0;
        week = 0;
        departing = "";
        arriving = "";
        aircraft = new Aircraft();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public boolean checkWeek()
    {
        // put your code here
        if (week>0&&week<=52) return true;
        else return false;
    }
}
