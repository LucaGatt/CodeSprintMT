package generic;
import java.util.Scanner;

public class IO extends GUI{
    //simple
    //input
    public static Scanner in = new Scanner(System.in); // declaration and initialsion of variable
    
    //output
    public static void print(String a){
        System.out.print(a);
    }
    public static void println(String a){
        System.out.println(a);
    }
    //simple
}