package generic;
import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class GUI extends JOptionPane{
    public static void print(String message){
        //              JFrame
        showMessageDialog(null, message);
    }
    public static void printError(String message){
        //JFrame f = new JFrame();
        showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public static String in(String prompt){
        return showInputDialog(prompt);
    }
}