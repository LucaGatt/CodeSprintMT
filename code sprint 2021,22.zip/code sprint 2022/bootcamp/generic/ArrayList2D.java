package generic;

import java.util.ArrayList;

class ArrayList2D{
    ArrayList<ArrayList> array = new ArrayList();
    void addRow(){//ArrayList<ArrayList<String>> array){
        this.array.add(new ArrayList());
    }
    void addElement(byte i, Object element){//, ArrayList<ArrayList> array){
        
        //ArrayList tmp = this.array.get(i); //call row
        this.array.get(i).add(element); // add element in row i (with new col)
        //this.array.set(i,tmp); //update row
        
    }
    void setElement(byte i, byte j, Object element){//, ArrayList<ArrayList> array){
        //ArrayList tmp = this.array.get(i); //call row
        this.array.get(i).set(j,element);// update element in row i, col j
        //this.array.set(i,tmp); //update row
    }
    Object getElement(byte i, byte j){//, ArrayList<ArrayList<String>> array){
        return (this.array.get(i).get(j));
    }
    
    private void printElement(byte i, byte j){//, ArrayList<ArrayList<String>> array){
        System.out.print(getElement(i, j));//, array));
    }
}