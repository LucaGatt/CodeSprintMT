package generic;


/**
 * Write a description of class parse here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Parse
{
    // instance variables - replace the example below with your own
    //private int x;

    /**
     * Constructor for objects of class Parse
     */
    public Parse()
    {
        // initialise instance variables
        //x = 0;
    }

    /**
     * Method to validate string as number (byte)
     *
     * @param  input  parameter to gather number from
     * @return    number
     */
    public static byte byteNum(String input)
    {
        try{
            return Byte.parseByte(input);
        }catch(Exception e){
            GUI.printError("Value input is not a number.");
            return -1; // -1 signifies error
        }
    }
}
