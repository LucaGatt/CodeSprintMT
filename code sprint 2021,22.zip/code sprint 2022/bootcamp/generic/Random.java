package generic;

class Random{// generate random numbers within range or letters
    /**
     * Method to generate random number within a specified range
     * @return int - number within range
     * @parameters: int, int - min, max - to specify range
     */
    public static int genRan(int min, int max){
        return (int)(Math.random()*(max-min+1))+min;
    }
    
    /**
     * Method to generate and return a random lowercase letter
     * @return char - lowercase letter
     * @parameters: none
     */
    public static char genRanLowLetter(){
        return (char)(genRan(97,97+25));
    }
    
    /**
     * Method to generate and return a random uppercase letter
     * @return char - uppercase letter
     * @parameters: none
     */
    public static char genRanUpLetter(){
        return (char)(genRan(65,65+25));
    }
}