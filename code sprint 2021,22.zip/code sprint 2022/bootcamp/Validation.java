import generic.*;
/**
 * This class contains generic validation methods.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Validation
{
    // instance variables - replace the example below with your own
    //private int x;

    /*
     * Constructor for objects of class Validation

    public Validation()
    {
    // initialise instance variables
    x = 0;
    }*/

    /**
     * Aim - check if input is a number
     *
     * @param  message - Message displayed to ask for user input
     * @return    number input
     */
    public static int inNum(String message)
    {
        // put your code here
        boolean valid=true;
        do{
            valid=true;// reset variable
            String input = GUI.in(message); // ask user for input and assign it to variable
            try{
                return Integer.parseInt(input); } // attempts to return number input
            catch(Exception e){
                valid=false;
                GUI.printError("Input is not a number. Try again.");
            }
        }while(!valid);
        
        return -1; // this code should never be reached
    }
    
    public static int inOption(String optionsDesc, byte noOptions){
        boolean valid; // used for loop // check validity
        byte option; //option input
        do{
            valid=true; //reset variable
            option = (byte)Validation.inNum("Choose an option:\n"+optionsDesc);
            if(option>0&& option<=noOptions) return option;
            else{
                valid= false;
                GUI.printError("Option number exceeds range. Try again.");
            }
        }while(!valid);
        
        return -1; // this code should never be reached
    }
    
    public static boolean check1Booking(){ // check that aircraft has at most one booking per week
        
        return false;
    }
    
    public static boolean checkWeightVolExceed(){ // check that weight and volume are not exceeded
        
        return false;
    }
}
