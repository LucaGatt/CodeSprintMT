import pygame

# pygame.init()
heightScreen = 600
screen = pygame.display.set_mode((800, heightScreen))

pygame.display.set_caption("Game")
# icon = pygame.image.load("")
# pygame.display.set_icon(icon)

score = 0
scoreX = 600
scoreY = 30
pygame.font.init()
textScore = pygame.font.SysFont('Arial', 30)

playerImg = pygame.image.load('alien1.jpg')
obstacleImg = pygame.image.load('obstacle.png')
# playerImg = 80 x 71 pixels
widthPlayerImg = 80
heightPlayerImg = 71
playerX = 360
playerY = 480
prePlayerX = playerX
prePlayerY = playerY
# obstacleY = []
# for obstacleY in range(1, 6):
#    obstacleY.append('10')
# for x in obstacleY:
#    x = int(x)
widthObstacle = 30
obstacleX1 = 65
obstacleX2 = obstacleX1 + 160
obstacleX3 = obstacleX1 + 160 * 2
obstacleX4 = obstacleX1 + 160 * 3
obstacleX5 = obstacleX1 + 160 * 4
obstacleY = 10
heightObstacle = heightScreen - obstacleY
obstacleY1 = obstacleY
obstacleY2 = obstacleY
obstacleY3 = obstacleY
obstacleY4 = obstacleY
obstacleY5 = obstacleY
heightClear = 1
heightClear1 = heightClear
heightClear2 = heightClear
heightClear3 = heightClear
heightClear4 = heightClear
heightClear5 = heightClear
heightChange = 1


# play = pygame.Surface.blit('alien1.jpg')


def player(x, y):
    screen.blit(playerImg, (x, y))


def obstacle(x, height):
    # screen.blit(obstacleImg, (x, y))
    pygame.draw.rect(screen, (255, 0, 0), (x, 1, widthObstacle, height))


def obstacle1():
    obstacle(obstacleX1, obstacleY1)


def obstacle2():
    obstacle(obstacleX2, obstacleY2)


def obstacle3():
    obstacle(obstacleX3, obstacleY3)


def obstacle4():
    obstacle(obstacleX4, obstacleY4)


def obstacle5():
    obstacle(obstacleX5, obstacleY5)


def clearObstacle(x, h):
    pygame.draw.rect(screen, (0, 0, 0), (x, 0, 30, h))


def clearObstacle1():
    clearObstacle(obstacleX1, heightClear1)


def clearObstacle2():
    clearObstacle(obstacleX2, heightClear2)


def clearObstacle3():
    clearObstacle(obstacleX3, heightClear3)


def clearObstacle4():
    clearObstacle(obstacleX4, heightClear4)


def clearObstacle5():
    clearObstacle(obstacleX5, heightClear5)


def clearFrame():
    screen.fill(colourScreen)


def removePreviousMove(x, y):
    pygame.draw.rect(screen, colourScreen, (x, y, widthPlayerImg, heightPlayerImg))


def gameOver(obsX, obsY):
    return (playerX == obsX - (widthPlayerImg - widthObstacle) / 2) & (playerY == obsY)


def gameOver1():
    return gameOver(obstacleX1, obstacleY1)


def gameOver2():
    return gameOver(obstacleX2, obstacleY2)


def gameOver3():
    return gameOver(obstacleX3, obstacleY3)


def gameOver4():
    return gameOver(obstacleX4, obstacleY4)


def gameOver5():
    return gameOver(obstacleX5, obstacleY5)


def showScore():
    pygame.draw.rect(screen, (255, 255, 0), (scoreX, scoreY, 100, 30))
    textScoreSurface = textScore.render(" " + str(score), False, (0, 255, 0))
    screen.blit(textScoreSurface, (scoreX, scoreY))


def freeObstacle1():
    obstacle2()
    obstacle3()
    obstacle4()
    obstacle5()
    clearObstacle2()
    clearObstacle3()
    clearObstacle4()
    clearObstacle5()
    return 1


def freeObstacle2():
    obstacle1()
    obstacle3()
    obstacle4()
    obstacle5()
    clearObstacle1()
    clearObstacle3()
    clearObstacle4()
    clearObstacle5()
    return 2


def freeObstacle3():
    obstacle1()
    obstacle2()
    obstacle4()
    obstacle5()
    clearObstacle1()
    clearObstacle2()
    clearObstacle4()
    clearObstacle5()
    return 3


def freeObstacle4():
    obstacle1()
    obstacle2()
    obstacle3()
    obstacle5()
    clearObstacle1()
    clearObstacle2()
    clearObstacle3()
    clearObstacle5()
    return 4


def freeObstacle5():
    obstacle1()
    obstacle2()
    obstacle3()
    obstacle4()
    clearObstacle1()
    clearObstacle2()
    clearObstacle3()
    clearObstacle4()
    return 5


colourScreen = (0, 255, 255)
screen.fill(colourScreen)
z = 0
rateMove = 160

running = True
winning = True
while running:
    while winning:

        pygame.display.update()
        player(playerX, playerY)
        # obstacle1()
        # obstacle2()
        # obstacle3()
        # obstacle4()
        # obstacle5()
        print(obstacleY1, obstacleY2, obstacleY3, obstacleY4, obstacleY5)

        if obstacleY1 == heightScreen:
            obstacleY1 = obstacleY
            heightClear1 = 1
            clearFrame()
            z += 1
            print(z)

        if obstacleY2 == heightScreen:
            obstacleY2 = obstacleY
            heightClear2 = heightClear

        if obstacleY3 == heightScreen:
            obstacleY3 = obstacleY
            heightClear3 = heightClear

        if obstacleY4 == heightScreen:
            obstacleY4 = obstacleY
            heightClear4 = heightClear

        if obstacleY5 == heightScreen:
            obstacleY5 = obstacleY
            heightClear5 = heightClear

        # arrange game
        if obstacleY1 == heightScreen:
            obstacleY1 = obstacleY
            heightClear1 = 1
            clearFrame()
            z += 1
            print(z)

        if obstacleY2 == heightScreen:
            obstacleY2 = obstacleY
            heightClear2 = heightClear

        if obstacleY3 == heightScreen:
            obstacleY3 = obstacleY
            heightClear3 = heightClear

        if obstacleY4 == heightScreen:
            obstacleY4 = obstacleY
            heightClear4 = heightClear

        if obstacleY5 == heightScreen:
            obstacleY5 = obstacleY
            heightClear5 = heightClear

        for x in range(50):
            if score == heightScreen * x:
                clearFrame()

        if (score > -1) & (score < heightObstacle):
            freeObs = freeObstacle3()

        if (score >= heightObstacle) & (score < heightObstacle * 2):
            freeObs = freeObstacle1()

        if (score >= heightObstacle * 2) & (score < heightObstacle * 3):
            freeObs = freeObstacle4()

        if (score >= heightObstacle * 3) & (score < heightObstacle * 4):
            freeObs = freeObstacle5()

        if (score >= heightObstacle * 4) & (score < heightObstacle * 5):
            freeObs = freeObstacle1()

        if (score >= heightObstacle * 5) & (score < heightObstacle * 6):
            freeObs = freeObstacle3()
        # pygame.display.update()
        if (score == heightObstacle * 6) & (score < heightObstacle * 7):
            freeObs = freeObstacle3()

        if (score == heightObstacle * 7) & (score < heightObstacle * 8):
            freeObs = freeObstacle1()

        if (score == heightObstacle * 8) & (score < heightObstacle * 9):
            freeObs = freeObstacle5()
        # pygame.display.update()
        if freeObs == 1:
            obstacleY1 = obstacleY
            heightClear1 = heightClear

            if (obstacleY2 == heightScreen) & (obstacleY3 == heightScreen):
                if (obstacleY4 == heightScreen) & (obstacleY5 == heightScreen):
                    obstacleY1 = obstacleY
                    obstacleY2 = obstacleY
                    obstacleY3 = obstacleY
                    obstacleY4 = obstacleY
                    obstacleY5 = obstacleY

        if freeObs == 2:
            obstacleY2 = obstacleY
            heightClear2 = heightClear

            if (obstacleY1 == heightScreen) & (obstacleY3 == heightScreen):
                if (obstacleY4 == heightScreen) & (obstacleY5 == heightScreen):
                    obstacleY1 = obstacleY
                    obstacleY3 = obstacleY
                    obstacleY4 = obstacleY
                    obstacleY5 = obstacleY

        if freeObs == 3:
            obstacleY3 = obstacleY
            heightClear3 = heightClear

            if (obstacleY1 == heightScreen) & (obstacleY2 == heightScreen):
                if (obstacleY4 == heightScreen) & (obstacleY5 == heightScreen):
                    obstacleY1 = obstacleY
                    obstacleY2 = obstacleY
                    obstacleY4 = obstacleY
                    obstacleY5 = obstacleY

        if freeObs == 4:
            obstacleY4 = obstacleY
            heightClear4 = heightClear

            if (obstacleY1 == heightScreen) & (obstacleY2 == heightScreen):
                if (obstacleY3 == heightScreen) & (obstacleY5 == heightScreen):
                    obstacleY1 = obstacleY
                    obstacleY2 = obstacleY
                    obstacleY3 = obstacleY
                    obstacleY5 = obstacleY

        if freeObs == 5:
            obstacleY5 = obstacleY
            heightClear5 = heightClear

            if (obstacleY1 == heightScreen) & (obstacleY2 == heightScreen):
                if (obstacleY3 == heightScreen) & (obstacleY4 == heightScreen):
                    obstacleY1 = obstacleY
                    obstacleY2 = obstacleY
                    obstacleY3 = obstacleY

        # print(playerY, playerX, prePlayerY, prePlayerX)

        if (playerX != prePlayerX) | (playerY != prePlayerY):
            removePreviousMove(prePlayerX, prePlayerY)
            # clearFrame()
            prePlayerX = playerX
            prePlayerY = playerY
        pygame.display.flip()
        score += 1
        showScore()

        obstacleY1 += heightChange
        obstacleY2 += heightChange
        obstacleY3 += heightChange
        obstacleY4 += heightChange
        obstacleY5 += heightChange
        heightClear1 += heightChange
        heightClear2 += heightChange
        heightClear3 += heightChange
        heightClear4 += heightChange
        heightClear5 += heightChange

        # pygame.Surface((12, 24)) .fill(co(lourScreen, rect=(12, 24))
        # clearObstacle1()
        # clearObstacle2()
        # clearObstacle3()
        # clearObstacle4()
        # clearObstacle5()
        # pygame.Surface.fill()

        # game over
        if gameOver1() | gameOver2() | gameOver3() | gameOver4() | gameOver5():
            winning = False

        # controls
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                winning = False

            if event.type == pygame.KEYDOWN:
                if (event.key == pygame.K_LEFT) & (playerX > 150):
                    playerX -= rateMove

                if (event.key == pygame.K_RIGHT) & (playerX < 531):
                    playerX += rateMove

                if event.key == pygame.K_UP:
                    playerY -= rateMove

                if event.key == pygame.K_DOWN:
                    playerY += rateMove

    # lose
    pygame.font.init()
    textLose = pygame.font.SysFont('Comic Sans MS', 50)
    textLoseSurface = textLose.render(' You lost! Better luck next time. ',
                                      False, (120, 120, 120), (100, 100, 0))
    screen.blit(textLoseSurface, (20, 200))

    pygame.font.init()
    textContinue = pygame.font.SysFont('Arial Black', 40)
    textContinueSurface = textContinue.render(' Press Up key to try again ',
                                              False, (120, 120, 120), (60, 60, 60))
    screen.blit(textContinueSurface, (20, 300))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                winning = True
                clearFrame()

    score = 0
    obstacleY1 = obstacleY
    obstacleY2 = obstacleY
    obstacleY3 = obstacleY
    obstacleY4 = obstacleY
    obstacleY5 = obstacleY
    heightClear1 = heightClear
    heightClear2 = heightClear
    heightClear3 = heightClear
    heightClear4 = heightClear
    heightClear5 = heightClear
    pygame.display.update()
