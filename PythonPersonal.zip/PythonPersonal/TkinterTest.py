import tkinter as tk

window = tk.Tk()
greet = tk.Label(text='Welcome') # write on window
greet.pack()
entry = tk.Entry() # textbox
entry.pack()
entry.get()
# entry.insert(0, 'Write')
text = tk.Text() # multi-line textbox
text.pack()

window.mainloop()