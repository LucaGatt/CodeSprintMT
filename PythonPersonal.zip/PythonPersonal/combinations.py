import math

def enterValue(prompt):
    word = True
    while(word): # false if not number
        try:
            value = input(prompt)
            value = int(value)
            word = False
            return value
        except(ValueError):
            print("Input is not a number. Try again.")
            word = True


length = enterValue('No of characters to enter')

bad = True
while(bad):
    print('1 = Alphanumeric, 2 = Numeric, 3 = Letters')
    charsA = enterValue('Type of possible charcters in a digit')
    if charsA < 4:
        bad = False
    else:
        print('Input not accepted')


# Alphanumeric = 26 letters + 0-9 = 26+10 = 36 for 1 digit
# Numeric = 10 for 1 digit
# Letters = 26 for 1 digit
chars = 1
if charsA == 1:
    chars = 36

if charsA == 2:
    chars = 10

if charsA == 3:
    chars = 26

# chars power length
outcome = pow(chars, length)
print('\nThere are ' + str(outcome) + ' possible outcomes')